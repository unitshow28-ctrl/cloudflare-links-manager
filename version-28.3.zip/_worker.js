// Redirections Cloudflare - Homelab de Bertrand (Cloudflare Pages _worker.js + KV)
// Binding KV : LINKS | Secrets : ADMIN_PASSWORD, SESSION_SECRET | Optionnel : ADMIN_USER

const enc = new TextEncoder();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
const unhex = h => new Uint8Array((h.match(/../g) || []).map(x => parseInt(x, 16)));
async function hmac(key, msg) {
  const k = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", k, enc.encode(msg)));
}
async function pbkdf2(pw, saltHex) {
  const k = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", salt: unhex(saltHex), iterations: 20000, hash: "SHA-256" }, k, 256));
}
const safeEq = (a, b) => { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; };
const json = (o, s = 200, h = {}) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store", ...h } });
const esc = t => String(t).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const newNonce = () => btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(16))));
const fmtDate = ms => new Date(ms).toLocaleString("fr-FR", { timeZone: "Europe/Paris", dateStyle: "long", timeStyle: "short" });

const TITLE = "Redirections Cloudflare - Homelab de Bertrand";
const ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%230f172a'/%3E%3Cpath d='M14 32h27M31 20l12 12-12 12' fill='none' stroke='%2360a5fa' stroke-width='5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E";
const BRAND_MARK = `<span class="mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h12"/><path d="m12 6 6 6-6 6"/><circle cx="4" cy="12" r="1.2" fill="#fff"/></svg></span>`;
const BRAND = "<!--@brand-->"; // remplacé à l’envoi par applySite()
const SLUG = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const USER = /^[a-z0-9][a-z0-9_-]{2,31}$/;
const RESERVED = ["admin", "robots.txt", "favicon.ico"];
const ownerName = env => { const n = String(env.ADMIN_USER || "bertrand").trim().toLowerCase(); return USER.test(n) ? n : "bertrand"; };

/* ---------- Droits (une case par droit) ---------- */
const RIGHTS = [
  { k: "view", sec: "Redirections", label: "Voir les redirections des autres", short: "voir celles des autres", hint: "Consultation seule." },
  { k: "create", label: "Créer des redirections", short: "créer des redirections" },
  { k: "editOwn", label: "Modifier ses propres redirections", short: "modifier les siennes" },
  { k: "delOwn", label: "Supprimer ses propres redirections", short: "supprimer les siennes" },
  { k: "editAll", label: "Modifier les redirections des autres", short: "modifier celles des autres", hint: "Inclut de les voir." },
  { k: "delAll", label: "Supprimer les redirections des autres", short: "supprimer celles des autres", hint: "Inclut de les voir." },
  { k: "usersView", sec: "Utilisateurs", label: "Voir les utilisateurs", short: "voir les utilisateurs" },
  { k: "usersCreate", label: "Créer des utilisateurs", short: "créer des utilisateurs", hint: "Seulement avec des droits qu’il possède lui-même." },
  { k: "usersEdit", label: "Modifier des utilisateurs", short: "modifier des utilisateurs", hint: "Seulement ceux qui n’ont pas plus de droits que lui." },
  { k: "usersDelete", label: "Supprimer des utilisateurs", short: "supprimer des utilisateurs", hint: "Seulement ceux qui n’ont pas plus de droits que lui." },
  { k: "profileEdit", sec: "Compte", label: "Modifier ses informations personnelles", short: "modifier son profil", hint: "Autorise la modification du prénom et du nom dans « Mon compte »." },
  { k: "tagsEdit", label: "Gérer ses propres tags", short: "gérer ses tags", hint: "Autorise l’ajout et le retrait de tags dans son profil." },
  { k: "pw", label: "Modifier son mot de passe", short: "changer son mot de passe", hint: "Depuis la page « Mon compte »." },
  { k: "analyticsView", sec: "Centre d’analyse", label: "Accéder au centre d’analyse", short: "consulter les analyses", hint: "Autorise la consultation des journaux et statistiques de requêtes." },
  { k: "groupsManage", sec: "Groupes de droits", label: "Gérer les groupes de droits", short: "gérer les groupes", hint: "Créer, modifier, dupliquer et supprimer des modèles de droits sans accorder plus de droits que ceux que vous possédez." }
];
const KEYS = RIGHTS.map(r => r.k);
const PRESETS = { standard: ["view", "create", "editOwn", "delOwn"], reader: ["view"], restricted: ["create", "editOwn", "delOwn"] };
const GROUP_ID = /^[a-z0-9][a-z0-9_-]{1,31}$/;
const BUILTIN_GROUPS = [
  { id: "super", name: "Super-Admin", description: "Tous les droits, y compris les droits ajoutés plus tard.", perms: { super: true }, builtin: true },
  { id: "standard", name: "Utilisateur Standard", description: "Créer et gérer ses propres redirections, consulter les redirections partagées.", perms: Object.fromEntries(PRESETS.standard.map(k => [k, true])), builtin: true },
  { id: "reader", name: "Lecteur", description: "Consultation des redirections partagées.", perms: Object.fromEntries(PRESETS.reader.map(k => [k, true])), builtin: true },
  { id: "restricted", name: "Utilisateur Restreint", description: "Créer et gérer ses propres redirections.", perms: Object.fromEntries(PRESETS.restricted.map(k => [k, true])), builtin: true },
  { id: "custom", name: "Personnalisé", description: "Choisir les droits un par un.", perms: {}, builtin: true }
];
async function listGroups(env) {
  const groups = BUILTIN_GROUPS.map(g => ({ ...g, perms: normPerms(g.perms) }));
  let cursor;
  do {
    const r = await env.LINKS.list({ prefix: "g:", cursor });
    for (const k of r.keys || []) {
      const rec = await env.LINKS.get(k.name, "json");
      if (!rec || !GROUP_ID.test(String(rec.id || ""))) continue;
      groups.push({ id: rec.id, name: cleanText(rec.name, 60) || rec.id, description: cleanText(rec.description, 240), perms: normPerms(rec.perms || {}), builtin: false, created: rec.created || "", updated: rec.updated || "", by: rec.by || "" });
    }
    cursor = r.list_complete ? undefined : r.cursor;
  } while (cursor);
  return groups.sort((a, b) => a.builtin === b.builtin ? a.name.localeCompare(b.name, "fr") : (a.builtin ? -1 : 1));
}
function normPerms(x) {
  const p = { super: false }; KEYS.forEach(k => p[k] = false);
  if (!x) return p;
  if (x.perms) x = x.perms; else if (x.role) x = x.role === "super" ? { super: true } : { view: true, own: true };
  if (x.own === true) x = { ...x, create: true, editOwn: true, delOwn: true }; // anciens comptes
  if (x.super === true) { p.super = true; KEYS.forEach(k => p[k] = true); return p; }
  KEYS.forEach(k => p[k] = x[k] === true);
  if (p.editAll || p.delAll) p.view = true;
  if (p.usersCreate || p.usersEdit || p.usersDelete) p.usersView = true;
  return p;
}
const compactPerms = p => p.super ? { super: true } : Object.fromEntries(KEYS.filter(k => p[k]).map(k => [k, true]));
const groupKey = p => { if (p.super) return "super"; const on = KEYS.filter(k => k !== "pw" && p[k]).sort().join(); if (!on) return ""; for (const g in PRESETS) if ([...PRESETS[g]].sort().join() === on) return g; return "custom"; };
const GROUP_LABEL = { super: "Super-Admin", standard: "Utilisateur Standard", reader: "Lecteur", restricted: "Utilisateur Restreint", custom: "Personnalisé", "": "Sans accès" };
const labelOf = p => GROUP_LABEL[groupKey(p)];
const within = (t, a) => (!t.super || a.super) && KEYS.every(k => !t[k] || a[k]);
const hasAccess = p => p.super || KEYS.some(k => k !== "pw" && p[k]);
function mkMe(username, perms, owner = false, rec = {}, theme = "light") {
  const first = rec.first || "", last = rec.last || "";
  return { username, perms, owner, label: labelOf(perms), first, last, tags: Array.isArray(rec.tags) ? rec.tags : [], active: rec.active !== false, display: [first, last].filter(Boolean).join(" ") || username, theme, forcePwChange: !!rec.forcePwChange, from: rec.from || null, until: rec.until || null };
}

function cleanUrl(v) {
  v = String(v || "").trim();
  if (!v || v.length > 700) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) v = "https://" + v;
  try { const u = new URL(v); return /^https?:$/.test(u.protocol) ? u.href : null; } catch { return null; }
}
const cleanText = (v, n) => String(v || "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/\s+/g, " ").trim().slice(0, n);
function readTags(v) {
  const out = [];
  (Array.isArray(v) ? v : []).forEach(t => { t = cleanText(t, 20); if (t && !out.some(o => o.toLowerCase() === t.toLowerCase())) out.push(t); });
  return out.slice(0, 8);
}
function readPerms(b) {
  const x = b && b.perms ? b.perms : {};
  const raw = { super: x.super === true }; KEYS.forEach(k => raw[k] = x[k] === true);
  return normPerms(raw);
}

/* ---------- Sessions ---------- */
async function makeSession(env, name) { const exp = Date.now() + 8 * 3600e3; return `${exp}.${name}.` + await hmac(env.SESSION_SECRET, `session:${exp}:${name}`); }
async function getSession(req, env, wantTheme = false) {
  if (!env.LINKS || !env.SESSION_SECRET || !env.ADMIN_PASSWORD) return null;
  const m = (req.headers.get("Cookie") || "").match(/(?:^|; )hl_session=([^;]+)/);
  if (!m) return null;
  const [exp, name, sig] = m[1].split(".");
  if (!exp || !name || !sig || Number(exp) < Date.now()) return null;
  if (!safeEq(sig, await hmac(env.SESSION_SECRET, `session:${exp}:${name}`))) return null;
  const owner = name === ownerName(env);
  const rec = owner ? (await env.LINKS.get("profile:owner", "json") || {}) : await env.LINKS.get("u:" + name, "json");
  if (!owner && !rec) return null;
  if (!owner && rec.active === false) return null;
  if (!owner && ((rec.from && Date.now() < rec.from) || (rec.until && Date.now() > rec.until))) return null;
  const savedTheme = wantTheme ? await env.LINKS.get("t:" + name) : null;
  const theme = savedTheme === "dark" ? "dark" : "light";
  return mkMe(name, owner ? normPerms({ super: true }) : normPerms(rec), owner, rec, theme);
}

/* ---------- Thèmes et mise en page ---------- */
const CSS = `
@property --bg { syntax: "<color>"; inherits: true; initial-value: #070914; }
@property --bg1 { syntax: "<color>"; inherits: true; initial-value: rgba(79,140,255,.25); }
@property --bg2 { syntax: "<color>"; inherits: true; initial-value: rgba(139,92,246,.22); }
@property --bg3 { syntax: "<color>"; inherits: true; initial-value: rgba(34,211,238,.10); }
@property --text { syntax: "<color>"; inherits: true; initial-value: #eef1ff; }
@property --muted { syntax: "<color>"; inherits: true; initial-value: #9aa3c7; }
@property --dim { syntax: "<color>"; inherits: true; initial-value: #6a7399; }
@property --link { syntax: "<color>"; inherits: true; initial-value: #8fd9ea; }
@property --danger { syntax: "<color>"; inherits: true; initial-value: #fca5a5; }
@property --focus { syntax: "<color>"; inherits: true; initial-value: #22d3ee; }
@property --glass { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.06); }
@property --btn { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.08); }
@property --btnh { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.15); }
@property --item { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.05); }
@property --line { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.14); }
@property --line2 { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.1); }
@property --hi { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.28); }
@property --sh { syntax: "<color>"; inherits: true; initial-value: rgba(0,0,0,.7); }
@property --field { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.06); }
@property --fieldln { syntax: "<color>"; inherits: true; initial-value: rgba(255,255,255,.15); }
@property --sheet { syntax: "<color>"; inherits: true; initial-value: rgba(18,22,44,.84); }
@property --back { syntax: "<color>"; inherits: true; initial-value: rgba(4,6,16,.65); }
@property --grp-bg { syntax: "<color>"; inherits: true; initial-value: rgba(30,58,138,.8); }
@property --grp-bd { syntax: "<color>"; inherits: true; initial-value: rgba(96,130,255,.55); }
@property --grp-tx { syntax: "<color>"; inherits: true; initial-value: #dbe7ff; }
@property --tag-bg { syntax: "<color>"; inherits: true; initial-value: rgba(52,211,153,.14); }
@property --tag-bd { syntax: "<color>"; inherits: true; initial-value: rgba(52,211,153,.42); }
@property --tag-tx { syntax: "<color>"; inherits: true; initial-value: #a7f3d0; }
@property --ok { syntax: "<color>"; inherits: true; initial-value: #a7f3d0; }
@property --okb { syntax: "<color>"; inherits: true; initial-value: rgba(52,211,153,.12); }
@property --okl { syntax: "<color>"; inherits: true; initial-value: rgba(52,211,153,.35); }
@property --wn { syntax: "<color>"; inherits: true; initial-value: #fde68a; }
@property --wnb { syntax: "<color>"; inherits: true; initial-value: rgba(251,191,36,.12); }
@property --wnl { syntax: "<color>"; inherits: true; initial-value: rgba(251,191,36,.35); }
@property --bd { syntax: "<color>"; inherits: true; initial-value: #fca5a5; }
@property --bdb { syntax: "<color>"; inherits: true; initial-value: rgba(248,113,113,.12); }
@property --bdl { syntax: "<color>"; inherits: true; initial-value: rgba(248,113,113,.35); }
:root,html[data-theme="dark"]{color-scheme:dark;--g:linear-gradient(135deg,#22d3ee,#4f8cff 50%,#8b5cf6);
 --bg:#070914;--bg1:rgba(79,140,255,.25);--bg2:rgba(139,92,246,.22);--bg3:rgba(34,211,238,.10);
 --text:#eef1ff;--muted:#9aa3c7;--dim:#6a7399;--link:#8fd9ea;--danger:#fca5a5;--focus:#22d3ee;
 --glass:rgba(255,255,255,.06);--btn:rgba(255,255,255,.08);--btnh:rgba(255,255,255,.15);--item:rgba(255,255,255,.05);
 --line:rgba(255,255,255,.14);--line2:rgba(255,255,255,.1);--hi:rgba(255,255,255,.28);--sh:rgba(0,0,0,.7);
 --field:rgba(255,255,255,.06);--fieldln:rgba(255,255,255,.15);--sheet:rgba(18,22,44,.84);--back:rgba(4,6,16,.65);
 --t1:linear-gradient(100deg,#fff 0%,#9be9f7 35%,#a5b4ff 65%,#fff 100%);
 --grp-bg:rgba(30,58,138,.8);--grp-bd:rgba(96,130,255,.55);--grp-tx:#dbe7ff;
 --tag-bg:rgba(52,211,153,.14);--tag-bd:rgba(52,211,153,.42);--tag-tx:#a7f3d0;
 --ok:#a7f3d0;--okb:rgba(52,211,153,.12);--okl:rgba(52,211,153,.35);
 --wn:#fde68a;--wnb:rgba(251,191,36,.12);--wnl:rgba(251,191,36,.35);
 --bd:#fca5a5;--bdb:rgba(248,113,113,.12);--bdl:rgba(248,113,113,.35);
 --knob:linear-gradient(135deg,#1e3a8a,#6d28d9);--track:linear-gradient(135deg,#0b1030,#1d1b4e)}
html[data-theme="light"]{color-scheme:light;
 --bg:#e9efff;--bg1:rgba(79,140,255,.38);--bg2:rgba(167,139,250,.38);--bg3:rgba(34,211,238,.30);
 --text:#0f172a;--muted:#55608a;--dim:#7480a8;--link:#0e7490;--danger:#b91c1c;--focus:#0891b2;
 --glass:rgba(255,255,255,.58);--btn:rgba(255,255,255,.72);--btnh:rgba(255,255,255,.97);--item:rgba(255,255,255,.55);
 --line:rgba(15,23,42,.12);--line2:rgba(15,23,42,.08);--hi:rgba(255,255,255,.95);--sh:rgba(40,60,140,.3);
 --field:rgba(255,255,255,.82);--fieldln:rgba(15,23,42,.2);--sheet:rgba(255,255,255,.92);--back:rgba(30,41,90,.35);
 --t1:linear-gradient(100deg,#0f172a 0%,#0e7490 35%,#4338ca 65%,#0f172a 100%);
 --grp-bg:#dbeafe;--grp-bd:#93c5fd;--grp-tx:#1e40af;
 --tag-bg:#dcfce7;--tag-bd:#86efac;--tag-tx:#166534;
 --ok:#166534;--okb:#dcfce7;--okl:#86efac;--wn:#92400e;--wnb:#fef3c7;--wnl:#fcd34d;--bd:#991b1b;--bdb:#fee2e2;--bdl:#fca5a5;
 --knob:linear-gradient(135deg,#fbbf24,#f97316);--track:linear-gradient(135deg,#bfdbfe,#fde68a)}
*{box-sizing:border-box;margin:0}
body{min-height:100vh;color:var(--text);background:radial-gradient(900px 600px at 10% -10%,var(--bg1),transparent 60%),radial-gradient(800px 600px at 100% 0,var(--bg2),transparent 60%),radial-gradient(700px 500px at 50% 112%,var(--bg3),transparent 60%),var(--bg);background-attachment:fixed;font:16px/1.5 "SF Pro Display",Inter,"Segoe UI",system-ui,sans-serif;padding:20px 16px 40px}
html.tt,html.tt * ,html.tt *::before,html.tt *::after{transition:background-color 3s cubic-bezier(.22,1,.36,1),background 3s cubic-bezier(.22,1,.36,1),color 3s cubic-bezier(.22,1,.36,1),border-color 3s cubic-bezier(.22,1,.36,1),box-shadow 3s cubic-bezier(.22,1,.36,1),fill 3s cubic-bezier(.22,1,.36,1),stroke 3s cubic-bezier(.22,1,.36,1),text-decoration-color 3s cubic-bezier(.22,1,.36,1),backdrop-filter 3s cubic-bezier(.22,1,.36,1)!important}
html.tt{transition:--bg 3s cubic-bezier(.22,1,.36,1),--bg1 3s cubic-bezier(.22,1,.36,1),--bg2 3s cubic-bezier(.22,1,.36,1),--bg3 3s cubic-bezier(.22,1,.36,1),--text 3s cubic-bezier(.22,1,.36,1),--muted 3s cubic-bezier(.22,1,.36,1),--dim 3s cubic-bezier(.22,1,.36,1),--link 3s cubic-bezier(.22,1,.36,1),--danger 3s cubic-bezier(.22,1,.36,1),--focus 3s cubic-bezier(.22,1,.36,1),--glass 3s cubic-bezier(.22,1,.36,1),--btn 3s cubic-bezier(.22,1,.36,1),--btnh 3s cubic-bezier(.22,1,.36,1),--item 3s cubic-bezier(.22,1,.36,1),--line 3s cubic-bezier(.22,1,.36,1),--line2 3s cubic-bezier(.22,1,.36,1),--hi 3s cubic-bezier(.22,1,.36,1),--sh 3s cubic-bezier(.22,1,.36,1),--field 3s cubic-bezier(.22,1,.36,1),--fieldln 3s cubic-bezier(.22,1,.36,1),--sheet 3s cubic-bezier(.22,1,.36,1),--back 3s cubic-bezier(.22,1,.36,1),--grp-bg 3s cubic-bezier(.22,1,.36,1),--grp-bd 3s cubic-bezier(.22,1,.36,1),--grp-tx 3s cubic-bezier(.22,1,.36,1),--tag-bg 3s cubic-bezier(.22,1,.36,1),--tag-bd 3s cubic-bezier(.22,1,.36,1),--tag-tx 3s cubic-bezier(.22,1,.36,1),--ok 3s cubic-bezier(.22,1,.36,1),--okb 3s cubic-bezier(.22,1,.36,1),--okl 3s cubic-bezier(.22,1,.36,1),--wn 3s cubic-bezier(.22,1,.36,1),--wnb 3s cubic-bezier(.22,1,.36,1),--wnl 3s cubic-bezier(.22,1,.36,1),--bd 3s cubic-bezier(.22,1,.36,1),--bdb 3s cubic-bezier(.22,1,.36,1),--bdl 3s cubic-bezier(.22,1,.36,1)}
.wrap{width:min(760px,100%);margin:0 auto}
.glass{background:var(--glass);border:1px solid var(--line);border-radius:24px;backdrop-filter:blur(24px) saturate(170%);-webkit-backdrop-filter:blur(24px) saturate(170%);box-shadow:inset 0 1px 0 var(--hi),0 20px 50px -20px var(--sh);padding:24px}
.glass + .glass{margin-top:18px}
.sec{margin-top:22px}
header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin:4px 2px 20px}
.right{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:8px;margin-left:auto}
.brand{display:flex;align-items:center;gap:14px;padding:10px 20px 10px 10px;border-radius:22px;text-decoration:none;color:inherit;background:var(--glass);border:1px solid var(--line);backdrop-filter:blur(24px) saturate(170%);-webkit-backdrop-filter:blur(24px) saturate(170%);box-shadow:inset 0 1px 0 var(--hi),0 14px 36px -16px var(--sh);transition:transform .3s}
.brand:hover{transform:translateY(-2px)}
.mark{flex:none;width:48px;height:48px;border-radius:15px;display:grid;place-items:center;background:var(--g);box-shadow:inset 0 1px 0 rgba(255,255,255,.5),0 8px 26px -6px rgba(99,102,241,.8)}
.mark svg{width:24px;height:24px;fill:none;stroke:#fff;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
.bt{display:grid;line-height:1.2}
.t1{font-size:1.28rem;font-weight:750;letter-spacing:-.025em;background:var(--t1);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:shine 7s linear infinite}
.t2{font-size:.82rem;font-weight:500;color:var(--muted);letter-spacing:.02em;margin-top:3px}
@keyframes shine{to{background-position:-200% 0}}
.who{display:flex;align-items:center;gap:8px;padding:3px 4px 3px 12px;border-radius:99px;background:var(--glass);border:1px solid var(--line);font-size:.85rem;color:var(--text);text-decoration:none}
.who:hover,.who.on{background:var(--btnh)}
.un{font-weight:650}
.grp{display:inline-flex;align-items:center;justify-content:center;line-height:1.2;text-align:center;font-size:.7rem;font-weight:600;padding:3px 10px;border-radius:99px;background:var(--grp-bg);border:1px solid var(--grp-bd);color:var(--grp-tx);white-space:nowrap;vertical-align:middle}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.tag{display:inline-flex;align-items:center;gap:6px;font-size:.74rem;font-weight:600;padding:3px 10px;border-radius:99px;background:var(--tag-bg);border:1px solid var(--tag-bd);color:var(--tag-tx)}
.tag button{all:unset;cursor:pointer;line-height:1;font-size:1rem;opacity:.8}.tag button:hover{opacity:1}.tag button:focus-visible{outline:2px solid var(--focus);border-radius:4px}
h1{font-size:1.5rem;letter-spacing:-.02em;margin-bottom:6px}
.muted{color:var(--muted);font-size:.92rem}
label{display:block;font-weight:600;font-size:.88rem;margin:16px 0 6px}
input,select{width:100%;height:48px;padding:0 14px;border-radius:14px;border:1px solid var(--fieldln);background:var(--field);color:var(--text);font:inherit;font-size:16px;outline:0}
input:disabled,select:disabled{opacity:.5}
input[readonly]{opacity:.7}
select option{background:var(--sheet);color:var(--text)}
input:focus,select:focus{border-color:#4f8cff;box-shadow:0 0 0 3px rgba(79,140,255,.28)}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 18px;border-radius:14px;border:1px solid var(--line);background:var(--btn);color:var(--text);font:inherit;font-weight:600;cursor:pointer;text-decoration:none}
.btn:hover{background:var(--btnh)}
.btn.sm{min-height:34px;padding:0 12px;font-size:.82rem;border-radius:11px}
.btn.on{background:rgba(79,140,255,.22);border-color:rgba(120,160,255,.5)}
.btn.p{border:0;background:var(--g);color:#fff;margin-top:18px;width:100%}
.btn.p.auto{width:auto;margin-top:0}
.btn.d{color:var(--danger)}
.err{color:var(--danger);font-size:.9rem;margin-top:12px;min-height:1.3em}
.okmsg{color:var(--ok);font-size:.9rem;margin-top:12px;min-height:1.3em}
.head{display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap}
.list{margin-top:18px;display:grid;gap:12px}
.searchbar{display:flex;gap:10px;align-items:center;margin:14px 0 4px}.searchbar input{flex:1;min-width:0}.searchmeta{font-size:.8rem;color:var(--muted);white-space:nowrap}.tip{display:inline-grid;place-items:center;width:18px;height:18px;margin-left:5px;border:1px solid var(--line);border-radius:50%;font-size:.72rem;font-weight:800;color:var(--link);cursor:help;vertical-align:middle}.invalid-field{border-color:#ef4444!important;box-shadow:0 0 0 3px rgba(239,68,68,.18)!important;animation:fieldshake .32s ease}.valid-field{border-color:#22c55e!important;box-shadow:0 0 0 3px rgba(34,197,94,.18)!important}@keyframes fieldshake{0%,100%{transform:translateX(0)}25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}.item{display:grid;gap:4px;padding:16px 18px;border-radius:18px;background:var(--item);border:1px solid var(--line2)}
.top{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
.short{font-weight:650;word-break:break-all;color:var(--link)}
.pname{font-weight:700;font-size:1.05rem}
.dest{color:var(--muted);font-size:.88rem;word-break:break-all}
.badge{display:inline-flex;align-items:center;justify-content:center;line-height:1.2;text-align:center;vertical-align:middle;flex:none;font-size:.72rem;padding:3px 10px;border-radius:99px;border:1px solid;font-weight:600}
.badge.ok{color:var(--ok);background:var(--okb);border-color:var(--okl)}
.badge.warn{color:var(--wn);background:var(--wnb);border-color:var(--wnl)}
.badge.bad{color:var(--bd);background:var(--bdb);border-color:var(--bdl)}
.acts{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.acts .btn{min-height:38px;padding:0 14px;font-size:.86rem}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.tagrow{display:flex;gap:8px}.tagrow .btn{min-height:48px;flex:none}
.ck{display:flex;align-items:center;gap:10px;font-weight:600;font-size:.9rem;margin:16px 0 6px;cursor:pointer}
.ck input{width:20px;height:20px;padding:0;flex:none;accent-color:#4f8cff}
.perm{align-items:flex-start;padding:9px 12px;border-radius:12px;border:1px solid var(--line2);background:var(--item);margin:8px 0 0;font-size:.88rem}
.sechead{margin:18px 0 0;font-size:.72rem;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);font-weight:700}
.perm small{display:block;color:var(--muted);font-weight:400;font-size:.8rem}
.perm input:disabled+span{opacity:.5}
.prof{display:flex;align-items:center;gap:16px}
.avatar{flex:none;width:64px;height:64px;border-radius:20px;display:grid;place-items:center;font-size:1.4rem;font-weight:750;color:#fff;background:var(--g);box-shadow:inset 0 1px 0 rgba(255,255,255,.5),0 10px 28px -8px rgba(99,102,241,.8)}
.theme{position:relative;flex:none;width:58px;height:32px;border-radius:99px;border:1px solid var(--line);background:var(--track);cursor:pointer;padding:0}
.theme .knob{position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:var(--knob);display:grid;place-items:center;color:#fff;box-shadow:0 3px 10px -2px rgba(0,0,0,.45);transition:transform .8s cubic-bezier(.22,1,.36,1),background 3s ease,box-shadow 3s ease}
html[data-theme="light"] .theme .knob{transform:translateX(26px) rotate(360deg)}
.theme svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
html[data-theme="light"] .i-moon,html:not([data-theme="light"]) .i-sun{display:none}
dialog{border:0;padding:0;background:none;color:inherit;width:min(540px,100% - 24px);max-height:calc(100dvh - 24px);margin:auto;overflow:visible}
dialog::backdrop{background:var(--back);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
dialog[open]{animation:pop .3s cubic-bezier(.2,.9,.3,1.15)}
@keyframes pop{from{opacity:0;transform:translateY(16px) scale(.97)}}
.sheet{background:var(--sheet);max-height:calc(100dvh - 24px);overflow-y:auto}
.bar{height:8px;border-radius:99px;background:var(--line2);overflow:hidden;margin-top:20px;box-shadow:inset 0 1px 2px rgba(0,0,0,.12)}.bar i{display:block;width:100%;height:100%;border-radius:inherit;background:var(--g);transform-origin:left;transition:width .12s linear;will-change:width}
.cd{font-weight:700;color:var(--link)}.two{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:18px}.two .btn.p{margin-top:0}
.foot{margin-top:36px;text-align:center;color:var(--dim);font-size:.85rem}
.adminnav{display:flex;gap:8px;flex-wrap:wrap;padding:8px;margin:18px 0 22px;border:1px solid var(--line);border-radius:18px;background:var(--glass);backdrop-filter:blur(18px)}
.adminnav a{display:flex;align-items:center;gap:9px;padding:11px 15px;border-radius:12px;text-decoration:none;color:var(--muted);font-size:.9rem;font-weight:650;transition:background .2s,color .2s;flex:1;justify-content:center;min-width:120px}
.adminnav a:hover{background:var(--btnh);color:var(--text)}.adminnav a.on{background:var(--g);color:white;box-shadow:0 8px 24px rgba(79,140,255,.2)}
.dashhero{position:relative;overflow:hidden;padding:clamp(22px,4vw,38px);background:linear-gradient(125deg,rgba(34,211,238,.13),rgba(79,140,255,.12) 45%,rgba(139,92,246,.15)),var(--glass)}
.dashhero:after{content:'↗';position:absolute;right:24px;top:-28px;font-size:170px;line-height:1;font-weight:800;opacity:.055;pointer-events:none}
.eyebrow{font-size:.72rem;text-transform:uppercase;letter-spacing:.16em;color:var(--link);font-weight:800;margin-bottom:10px}
.dashhero h1{font-size:clamp(1.8rem,4vw,2.65rem);line-height:1.12;max-width:650px;margin-bottom:12px}.dashhero .muted{max-width:620px}
.dashgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:16px}
.dashstat{padding:20px;border:1px solid var(--line);border-radius:20px;background:var(--glass);min-width:0}.staticon{width:42px;height:42px;display:grid;place-items:center;border-radius:14px;background:var(--btn);font-size:1.25rem;margin-bottom:16px}.statnum{font-size:1.8rem;font-weight:800;letter-spacing:-.04em;line-height:1.2}.statlabel{font-size:.82rem;color:var(--muted);margin-top:5px}
.dashsection{margin-top:24px}.dashsection h2{font-size:1.1rem;margin-bottom:12px}.quickgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.quick{display:flex;align-items:flex-start;gap:14px;padding:18px;border:1px solid var(--line);border-radius:18px;background:var(--glass);text-decoration:none;color:var(--text);transition:transform .2s,border-color .2s,background .2s}.quick:hover{transform:translateY(-2px);border-color:rgba(96,165,250,.5);background:var(--btnh)}.quickicon{flex:none;width:44px;height:44px;display:grid;place-items:center;border-radius:14px;background:var(--btn);font-size:1.25rem}.quick strong{display:block;margin-bottom:4px}.quick small{display:block;color:var(--muted);font-size:.83rem;line-height:1.45}
.accessrow{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}.accesspill{display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border:1px solid var(--line);border-radius:99px;background:var(--item);font-size:.78rem;color:var(--muted)}.accesspill:before{content:'✓';color:var(--ok);font-weight:800}
@media(max-width:700px){.dashgrid{grid-template-columns:1fr}.quickgrid{grid-template-columns:1fr}.adminnav a{min-width:calc(50% - 8px);justify-content:flex-start}}
@media(max-width:520px){.row2{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.t1,.bar i,dialog[open]{animation:none}.brand,.theme .knob{transition:none}html.tt,html.tt *,html.tt *::before,html.tt *::after{transition:none!important}}
:focus-visible{outline:2px solid var(--focus);outline-offset:3px}
button:disabled,input:disabled{opacity:.48;cursor:not-allowed;filter:grayscale(1)}
input.pw-ok{border-color:#16a34a!important;box-shadow:0 0 0 3px rgba(34,197,94,.22),0 0 24px rgba(34,197,94,.28)!important;animation:pwPulseOk .65s ease-out!important}input.pw-bad{border-color:#ef4444!important;box-shadow:0 0 0 3px rgba(239,68,68,.2),0 0 22px rgba(239,68,68,.24)!important;animation:pwShake .42s ease-in-out!important}.pw-feedback.success{color:#16a34a;font-weight:700;animation:pwFade .3s ease-out}.pw-feedback.error{color:#ef4444;font-weight:700;animation:pwFade .25s ease-out}@keyframes pwPulseOk{0%{box-shadow:0 0 0 0 rgba(34,197,94,.05)}45%{box-shadow:0 0 0 6px rgba(34,197,94,.25),0 0 30px rgba(34,197,94,.35)}100%{box-shadow:0 0 0 3px rgba(34,197,94,.22),0 0 24px rgba(34,197,94,.28)}}@keyframes pwShake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-5px)}40%,80%{transform:translateX(5px)}}@keyframes pwFade{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}
[hidden]{display:none!important}
.glass+.glass{margin-top:20px}
.red-select-info{padding:16px 22px!important;margin-top:20px!important;margin-bottom:0!important}
.red-search-panel{margin-top:20px!important;padding-top:20px!important}
.red-selection-copy{margin:0!important;line-height:1.45}
@media(max-width:560px){.red-select-info{padding:14px 16px!important}.red-search-panel{margin-top:16px!important}}
.ck{align-items:flex-start}.ck input{margin-top:2px}
.ck small{display:block;margin-top:2px;color:var(--muted);font-weight:400;font-size:.8rem;line-height:1.4}
.mt14{margin-top:14px}.mt18{margin-top:18px}.big{font-size:1.25rem}.hint{margin-top:6px;font-size:.8rem}.off{opacity:.58;cursor:not-allowed}
.mark.logo{background:var(--btn);box-shadow:none;overflow:hidden}.mark img{display:block;width:100%;height:100%;object-fit:cover;border-radius:inherit}
.sect{font-size:1.15rem;margin-bottom:4px}
.preview{margin-top:14px;padding:20px;border:1px dashed var(--line);background:var(--item);display:grid;gap:14px;justify-items:start}.preview .foot{margin:0;text-align:left}.preview .brand:hover{transform:none}
.rte{margin-top:6px;border:1px solid var(--fieldln);border-radius:14px;background:var(--field);overflow:hidden}.rte:focus-within{border-color:#4f8cff;box-shadow:0 0 0 3px rgba(79,140,255,.28)}
.rtebar{display:flex;flex-wrap:wrap;gap:4px;padding:6px;border-bottom:1px solid var(--line2);background:var(--item)}
.rtebar button,.emojis button{all:unset;box-sizing:border-box;min-width:36px;height:36px;padding:0 10px;display:inline-grid;place-items:center;border-radius:10px;cursor:pointer;font-size:.88rem;font-weight:650;color:var(--text)}
.rtebar button:hover,.emojis button:hover{background:var(--btnh)}.rtebar button:focus-visible,.emojis button:focus-visible{outline:2px solid var(--focus)}
.rtebar .sep{width:1px;margin:5px 3px;background:var(--line)}
.emojis,.rtelink{display:flex;flex-wrap:wrap;gap:4px;padding:6px;border-bottom:1px solid var(--line2)}.emojis button{font-size:1.15rem;font-weight:400}
.rtelink{flex-wrap:nowrap}.rtelink input{height:38px;font-size:15px}.rtelink .btn{min-height:38px;flex:none}
.rtebody{min-height:78px;padding:14px;outline:0;overflow-wrap:anywhere}.rtebody a{color:var(--link)}.rtebody:empty:before{content:attr(data-ph);color:var(--dim)}
.rtebody.center{text-align:center;color:var(--dim);font-size:.85rem}
.rtefoot{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:6px 8px 6px 14px;border-top:1px solid var(--line2);font-size:.78rem;color:var(--muted)}
.swatches,.seg{display:flex;flex-wrap:wrap;gap:8px;margin-top:6px}
.sw{all:unset;box-sizing:border-box;cursor:pointer;display:grid;gap:6px;justify-items:center;padding:7px;border-radius:14px;border:2px solid transparent;font-size:.76rem;font-weight:600;color:var(--muted)}
.sw i{display:block;width:58px;height:28px;border-radius:9px;border:1px solid var(--line)}.sw[aria-pressed="true"]{border-color:#4f8cff;color:var(--text)}.sw:focus-visible{outline:2px solid var(--focus)}
.colors{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:10px}.colors label{margin:0 0 4px}input[type="color"]{padding:4px;cursor:pointer}
.foot a,.muted a{color:var(--link)}

.analytics-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.analytics-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px}.analytics-kpi{padding:17px;border:1px solid var(--line);border-radius:16px;background:var(--item)}.analytics-kpi strong{display:block;font-size:1.6rem;letter-spacing:-.04em}.analytics-kpi span{color:var(--muted);font-size:.82rem}.chartbox{min-height:220px}.chart-bars{display:flex;align-items:end;gap:8px;height:150px;padding:16px 4px 0;border-bottom:1px solid var(--line2)}.chart-col{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;justify-content:end;height:100%;gap:7px}.chart-bar{width:min(32px,80%);min-height:2px;border-radius:7px 7px 2px 2px;background:linear-gradient(180deg,#22d3ee,#6366f1);box-shadow:0 0 18px #6366f133}.chart-label{font-size:.68rem;color:var(--muted);white-space:nowrap}.country-row{display:grid;grid-template-columns:minmax(70px,1fr) 2fr 42px;gap:10px;align-items:center;margin:12px 0;font-size:.84rem}.country-track{height:8px;border-radius:9px;background:var(--line2);overflow:hidden}.country-fill{height:100%;border-radius:9px;background:linear-gradient(90deg,#22d3ee,#8b5cf6)}.analytics-tools{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:12px 0}.analytics-tools input,.analytics-tools select{width:auto;min-width:150px;flex:1}.tablewrap{overflow:auto}table.analytics-table{width:100%;border-collapse:collapse;font-size:.82rem}table.analytics-table th,table.analytics-table td{text-align:left;padding:11px 9px;border-bottom:1px solid var(--line2);vertical-align:top;white-space:nowrap}table.analytics-table th{color:var(--muted);font-weight:650}table.analytics-table td.path{white-space:normal;overflow-wrap:anywhere;min-width:160px;max-width:340px}.status-code{display:inline-block;border-radius:8px;padding:3px 7px;background:var(--item);font-variant-numeric:tabular-nums}.status-code.bad{color:var(--danger)}.analytics-note{font-size:.8rem;color:var(--muted)}@media(max-width:780px){.analytics-grid{grid-template-columns:1fr}.analytics-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}

/* ---------- Liquid Glass refresh v25 ---------- */
:root,html[data-theme="dark"]{
 --glass:rgba(19,24,45,.54);--btn:rgba(255,255,255,.075);--btnh:rgba(255,255,255,.14);--item:rgba(255,255,255,.045);
 --line:rgba(255,255,255,.16);--line2:rgba(255,255,255,.095);--hi:rgba(255,255,255,.22);--sh:rgba(0,0,0,.42);
 --field:rgba(7,11,27,.48);--fieldln:rgba(255,255,255,.16);--sheet:rgba(15,20,40,.94);
}
html[data-theme="light"]{
 --bg:#edf2ff;--bg1:rgba(100,160,255,.35);--bg2:rgba(180,145,255,.32);--bg3:rgba(93,225,224,.22);
 --glass:rgba(255,255,255,.57);--btn:rgba(255,255,255,.58);--btnh:rgba(255,255,255,.88);--item:rgba(255,255,255,.48);
 --line:rgba(255,255,255,.78);--line2:rgba(65,83,130,.12);--hi:rgba(255,255,255,.95);--sh:rgba(73,91,155,.18);
 --field:rgba(255,255,255,.68);--fieldln:rgba(78,98,151,.19);--sheet:rgba(247,249,255,.96);
}
html{scroll-behavior:smooth}
body{padding:clamp(16px,2.6vw,34px) clamp(12px,2.4vw,30px) 44px;background-image:radial-gradient(ellipse 50rem 34rem at -8% -8%,var(--bg1),transparent 66%),radial-gradient(ellipse 42rem 32rem at 108% 5%,var(--bg2),transparent 66%),radial-gradient(ellipse 42rem 30rem at 45% 112%,var(--bg3),transparent 68%),linear-gradient(145deg,var(--bg),var(--bg));}
body:before{content:"";position:fixed;inset:0;z-index:-1;pointer-events:none;opacity:.22;background-image:radial-gradient(rgba(255,255,255,.55) .65px,transparent .65px);background-size:5px 5px;mask-image:linear-gradient(to bottom,black,transparent 82%)}
.wrap{width:min(1180px,100%);margin:0 auto}
body:has(#username) .wrap{width:min(470px,100%)}
header{gap:16px;margin:0 0 22px;padding:8px 0}
.brand{gap:13px;padding:8px 17px 8px 8px;border-radius:21px;background:linear-gradient(135deg,rgba(255,255,255,.16),rgba(255,255,255,.035)),var(--glass);border-color:var(--line);box-shadow:inset 0 1px 0 var(--hi),0 12px 32px -20px var(--sh);}
.mark{width:44px;height:44px;border-radius:15px}
.t1{font-size:1.2rem;letter-spacing:-.04em}
.t2{font-size:.76rem;letter-spacing:.025em}
.adminnav{position:relative;display:flex;align-items:center;gap:5px;flex-wrap:wrap;padding:7px;margin:0 0 25px;border-radius:20px;background:linear-gradient(120deg,rgba(255,255,255,.12),rgba(255,255,255,.025)),var(--glass);border:1px solid var(--line);backdrop-filter:blur(30px) saturate(190%);-webkit-backdrop-filter:blur(30px) saturate(190%);box-shadow:inset 0 1px 0 var(--hi),0 12px 36px -24px var(--sh)}
.adminnav a{position:relative;flex:0 1 auto;justify-content:flex-start;min-width:0;padding:11px 15px;border-radius:14px;color:var(--muted);font-size:.86rem;letter-spacing:-.01em;transition:background .22s ease,color .22s ease,transform .22s ease}
.adminnav a:hover{transform:translateY(-1px);background:var(--btnh);color:var(--text)}
.adminnav a.on{color:var(--text);background:linear-gradient(135deg,rgba(91,151,255,.24),rgba(160,119,255,.17));border:1px solid rgba(120,155,255,.27);box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 5px 18px rgba(60,90,180,.1)}
.adminnav a.on:after{content:"";position:absolute;left:18px;right:18px;bottom:3px;height:2px;border-radius:2px;background:var(--g);opacity:.9}
.glass{position:relative;overflow:hidden;border-radius:26px;background:linear-gradient(140deg,rgba(255,255,255,.105),rgba(255,255,255,.015) 42%,rgba(120,150,255,.035)),var(--glass);border:1px solid var(--line);backdrop-filter:blur(30px) saturate(185%);-webkit-backdrop-filter:blur(30px) saturate(185%);box-shadow:inset 0 1px 0 var(--hi),inset 0 -1px 0 rgba(255,255,255,.025),0 22px 60px -32px var(--sh);padding:clamp(19px,2.4vw,30px)}
.glass:before{content:"";position:absolute;inset:0 0 auto;height:1px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.48),transparent);opacity:.65;pointer-events:none}
.glass+.glass{margin-top:18px}
.dashhero{padding:clamp(27px,4.8vw,52px);background:radial-gradient(ellipse at 85% 15%,rgba(144,117,255,.2),transparent 45%),radial-gradient(ellipse at 5% 95%,rgba(48,207,224,.13),transparent 48%),linear-gradient(125deg,rgba(255,255,255,.1),rgba(255,255,255,.015)),var(--glass)}
.dashhero:after{right:3%;top:-18%;font-size:clamp(130px,18vw,220px);opacity:.045;transform:rotate(-8deg)}
.eyebrow{display:inline-flex;align-items:center;gap:8px;padding:7px 11px;margin-bottom:17px;border:1px solid var(--line);border-radius:999px;background:var(--item);font-size:.68rem;letter-spacing:.13em}
.eyebrow:before{content:"";width:7px;height:7px;border-radius:50%;background:#58d9c7;box-shadow:0 0 12px #58d9c7}
.dashhero h1{font-size:clamp(2rem,5vw,3.3rem);letter-spacing:-.065em;line-height:1.04;margin-bottom:15px}
.dashhero .muted{max-width:650px;font-size:1rem;line-height:1.7}
.dashgrid{gap:16px;margin-top:18px}
.dashstat{position:relative;overflow:hidden;padding:23px;border-radius:23px;background:linear-gradient(145deg,rgba(255,255,255,.085),rgba(255,255,255,.012)),var(--glass);box-shadow:inset 0 1px 0 var(--hi),0 15px 35px -27px var(--sh);transition:transform .25s ease,border-color .25s ease}
.dashstat:after{content:"";position:absolute;width:110px;height:110px;right:-42px;top:-48px;border-radius:50%;background:var(--bg2);filter:blur(25px);opacity:.55;pointer-events:none}
.dashstat:hover{transform:translateY(-3px);border-color:rgba(125,160,255,.4)}
.staticon{width:46px;height:46px;border-radius:16px;background:linear-gradient(145deg,rgba(255,255,255,.13),rgba(255,255,255,.025)),var(--btn);border:1px solid var(--line);box-shadow:inset 0 1px 0 var(--hi);margin-bottom:19px}
.statnum{font-size:2.1rem;letter-spacing:-.06em;font-variant-numeric:tabular-nums}
.statlabel{font-size:.83rem}
.dashsection{margin-top:29px}
.dashsection>h2{font-size:1.15rem;letter-spacing:-.025em;margin-bottom:14px}
.quickgrid{gap:14px}
.quick{border-radius:21px;padding:20px;background:linear-gradient(135deg,rgba(255,255,255,.075),rgba(255,255,255,.015)),var(--glass);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);box-shadow:inset 0 1px 0 var(--hi);transition:transform .24s ease,border-color .24s ease,box-shadow .24s ease}
.quick:hover{transform:translateY(-3px);border-color:rgba(111,157,255,.42);box-shadow:inset 0 1px 0 var(--hi),0 16px 35px -25px var(--sh)}
.quickicon{border:1px solid var(--line);border-radius:15px;background:linear-gradient(135deg,rgba(255,255,255,.13),rgba(255,255,255,.025)),var(--btn)}
h1{letter-spacing:-.045em;font-size:clamp(1.45rem,3vw,1.8rem)}
h2{letter-spacing:-.025em}
.item{border-radius:20px;padding:18px 20px;background:linear-gradient(130deg,rgba(255,255,255,.065),rgba(255,255,255,.012)),var(--item);transition:transform .2s ease,border-color .2s ease,background .2s ease}
.item:hover{border-color:var(--line);transform:translateY(-1px)}
.btn{border-radius:14px;min-height:43px;border-color:var(--line);background:linear-gradient(135deg,rgba(255,255,255,.09),rgba(255,255,255,.02)),var(--btn);box-shadow:inset 0 1px 0 rgba(255,255,255,.08);transition:transform .18s ease,background .18s ease,border-color .18s ease,box-shadow .18s ease}
.btn:hover{background:linear-gradient(135deg,rgba(255,255,255,.16),rgba(255,255,255,.04)),var(--btnh);border-color:rgba(130,160,255,.32);box-shadow:inset 0 1px 0 rgba(255,255,255,.16),0 7px 18px -14px var(--sh)}
.btn:active{transform:scale(.985)}
.btn.p{background:var(--g);box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 8px 24px -12px rgba(83,125,255,.45);color:#fff}
.btn.p:hover{background:var(--g);filter:brightness(1.08);box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 12px 28px -12px rgba(83,125,255,.55)}
input,select{border-radius:15px;transition:border-color .2s ease,box-shadow .2s ease,background .2s ease}
input:focus,select:focus{border-color:rgba(98,157,255,.8);box-shadow:0 0 0 4px rgba(79,140,255,.16),0 0 22px rgba(79,140,255,.08)}
.who{padding:5px 6px 5px 13px;border-radius:15px;background:var(--glass);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}
.theme{box-shadow:inset 0 1px 0 rgba(255,255,255,.12)}
.accesspill{background:linear-gradient(135deg,rgba(255,255,255,.09),rgba(255,255,255,.02)),var(--item);border-color:var(--line);padding:8px 12px}
.analytics-kpi{border-radius:20px;background:linear-gradient(135deg,rgba(255,255,255,.09),rgba(255,255,255,.02)),var(--glass);box-shadow:inset 0 1px 0 var(--hi)}
.analytics-kpi strong{letter-spacing:-.055em;font-variant-numeric:tabular-nums}
.chartbox{border-radius:22px}
.country-track{background:var(--line2)}
.tag{border-radius:9px}
.badge{border-radius:9px}
.sheet{background:var(--sheet);backdrop-filter:blur(36px) saturate(180%);-webkit-backdrop-filter:blur(36px) saturate(180%)}
.dialog::backdrop{backdrop-filter:blur(12px)}
.foot{padding:18px 10px 0;font-size:.78rem;opacity:.8}
:focus-visible{outline-offset:4px}
@media(max-width:760px){
 body{padding:12px 10px 30px}
 header{align-items:flex-start;gap:12px;margin-bottom:17px}
 .brand{max-width:100%;padding-right:12px}
 .right{gap:6px}
 .adminnav{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px;margin-bottom:18px;padding:6px;border-radius:17px}
 .adminnav a{justify-content:flex-start;padding:11px 12px;font-size:.82rem}
 .adminnav a.on:after{left:12px;right:auto;width:24px}
 .dashgrid{grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
 .dashstat{padding:15px 12px;border-radius:18px}
 .staticon{width:36px;height:36px;border-radius:12px;margin-bottom:13px}
 .statnum{font-size:1.55rem}
 .statlabel{font-size:.74rem;line-height:1.35}
 .glass{border-radius:22px;padding:20px}
 .dashhero{padding:25px 21px}
 .dashhero .muted{font-size:.92rem}
 .who{max-width:170px;flex-wrap:wrap;gap:4px}
 .un{max-width:145px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
}
@media(max-width:440px){
 .dashgrid{grid-template-columns:1fr;gap:10px}
 .dashstat{display:grid;grid-template-columns:44px 1fr;column-gap:12px;align-items:center;padding:15px}
 .staticon{grid-row:span 2;margin:0}
 .statnum{font-size:1.55rem}
 .statlabel{margin-top:1px}
 .adminnav a{font-size:.78rem;gap:7px;padding:10px 8px}
 .brand .t1{font-size:1.04rem}
 .brand .t2{font-size:.7rem}
 .right .btn.sm{font-size:.72rem;padding:0 9px}
}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}.dashstat,.quick,.btn,.item,.adminnav a{transition:none!important}.dashstat:hover,.quick:hover,.item:hover{transform:none}}



[hidden]{display:none!important}.content-help{font-size:.82rem;color:var(--muted)}
.content-public{max-width:900px;margin:24px auto}.public-text{overflow-wrap:anywhere;font:inherit;line-height:1.75;padding:clamp(18px,3vw,30px);border-radius:16px;background:var(--item);border:1px solid var(--line);max-height:none}.public-text>*:first-child{margin-top:0}.public-text>*:last-child{margin-bottom:0}.public-text h1,.public-text h2,.public-text h3{margin:1.1em 0 .5em}.public-text ul,.public-text ol{padding-left:1.6em}.public-text blockquote{border-left:4px solid var(--accent);padding:.3em 1em;margin:1em 0;background:var(--item);border-radius:0 10px 10px 0}.public-text img{max-width:100%;height:auto;border-radius:10px}.public-text pre,.public-text code{white-space:pre-wrap;background:var(--item);border-radius:6px;padding:.12em .35em}.content-public .two{margin-top:16px;display:flex;flex-wrap:wrap;gap:10px}
.rich-editor-shell{border:1px solid var(--line);border-radius:15px;overflow:hidden;background:var(--field);margin-top:12px}.rich-toolbar{display:flex;flex-wrap:wrap;gap:6px;padding:10px;border-bottom:1px solid var(--line);background:var(--item)}.rich-toolbar button{min-width:34px;min-height:34px;padding:6px 9px;border:1px solid var(--line);border-radius:8px;background:var(--btn);color:var(--text);cursor:pointer;font-weight:650}.rich-toolbar button:hover,.rich-toolbar button:focus-visible{background:var(--btnh);outline:2px solid var(--focus);outline-offset:1px}.rich-toolbar .tool-sep{width:1px;background:var(--line);margin:3px 2px}.rich-toolbar select,.rich-toolbar input[type=color]{width:auto;min-width:42px;min-height:34px;padding:3px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--text)}.rich-editor{min-height:240px;padding:18px;outline:0;line-height:1.75;overflow-wrap:anywhere}.rich-editor:empty:before{content:attr(data-placeholder);color:var(--muted);pointer-events:none}.rich-editor:focus{box-shadow:inset 0 0 0 2px var(--focus)}.rich-editor h2,.rich-editor h3{margin:.8em 0 .45em}.rich-editor blockquote{border-left:4px solid var(--accent);margin:1em 0;padding:.3em 1em;background:var(--item)}.editor-footer{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:9px 12px;border-top:1px solid var(--line);color:var(--muted);font-size:.78rem}.public-home{max-width:1050px;margin:26px auto;display:grid;grid-template-columns:minmax(0,1.1fr) minmax(270px,.9fr);gap:18px;align-items:start}.public-home.public-home-public{grid-template-columns:minmax(0,1fr);max-width:none;width:100%;margin:26px 0}.public-home-public .public-home-copy{width:100%;max-width:none;margin-inline:0;min-height:270px}.public-home-copy{min-height:250px}.public-home-copy h1{font-size:clamp(2rem,5vw,3.7rem);line-height:1.04;letter-spacing:-.055em}.public-home-login{position:sticky;top:14px}.login-dialog{width:min(480px,calc(100% - 24px));max-height:calc(100dvh - 28px);overflow:visible}.login-dialog::backdrop{background:rgba(4,6,16,.64);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}.login-dialog[open]{animation:loginPop .46s cubic-bezier(.22,1,.36,1)}.login-sheet{padding:clamp(22px,4vw,32px)}.login-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:8px}.login-head h2{font-size:1.45rem;letter-spacing:-.03em}.login-close{flex:none;min-width:38px;min-height:38px;padding:0 10px}.login-sheet .btn.p{margin-top:20px}@keyframes loginPop{from{opacity:0;transform:translateY(20px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}.group-card{display:grid;gap:10px;padding:17px;border:1px solid var(--line);border-radius:16px;background:var(--item)}.group-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}.group-card h2{margin:0;font-size:1.1rem}.group-card p{margin:0}.group-perms{display:flex;flex-wrap:wrap;gap:6px}.group-perms span{font-size:.75rem;padding:4px 8px;border-radius:8px;background:var(--btn);border:1px solid var(--line)}.form-alert{min-height:1.2em}.field-error{font-size:.82rem;color:var(--danger);margin-top:5px}
@media(max-width:760px){.public-home{grid-template-columns:1fr}.public-home-login{position:static}.rich-editor{min-height:200px}}
/* v26 command palette */
.palette-sheet{width:min(620px,calc(100vw - 24px));margin:0 auto;padding:22px;}
.palette-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:16px}
.palette-head h2{font-size:1.2rem;letter-spacing:-.03em}
.palette-head .eyebrow{margin-bottom:4px}
.palette-hint{font-size:.78rem;margin:10px 2px 12px}
.palette-results{display:grid;gap:5px;max-height:min(48dvh,420px);overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding:4px;scrollbar-gutter:stable}.palette-sheet{max-height:calc(100dvh - 20px);overflow:hidden;display:flex;flex-direction:column}.palette-sheet #v26PaletteSearch{flex:none}.palette-item{min-width:0}.palette-item>span:last-child{min-width:0;overflow-wrap:anywhere}.palette-item.selected{outline:2px solid color-mix(in srgb,var(--accent) 35%,transparent);outline-offset:-2px}
.palette-item{display:flex;align-items:center;gap:12px;padding:12px;border:1px solid transparent;border-radius:14px;color:var(--text);text-decoration:none;transition:background .16s ease,border-color .16s ease,transform .16s ease}
.palette-item:hover,.palette-item.selected{background:var(--btnh);border-color:var(--line);transform:translateX(2px)}
.palette-icon{display:grid;place-items:center;width:34px;height:34px;border-radius:11px;background:var(--btn);color:var(--link);font-size:1.05rem;flex:none}
.palette-empty{padding:18px;text-align:center}
.palette-trigger{gap:7px!important}
.palette-trigger kbd{font:inherit;font-size:.72rem;padding:2px 6px;border-radius:6px;border:1px solid var(--line);background:var(--item);color:var(--muted)}
@media(max-width:760px){.palette-trigger span,.palette-trigger kbd{display:none}.palette-trigger{min-width:42px;padding:0 10px!important}}

/* ---------- v26 · Liquid Glass polish, accessible motion and reliable form scrolling ---------- */
/* Cross-document View Transitions on browsers that support them, with a lightweight fallback. */
@view-transition { navigation: auto; }
::view-transition-old(root) {
  animation: v26-page-out .20s cubic-bezier(.4,0,1,1) both;
}
::view-transition-new(root) {
  animation: v26-page-in .42s cubic-bezier(.16,1,.3,1) both;
}
@keyframes v26-page-in {
  from { opacity: 0; transform: translateY(9px) scale(.995); filter: blur(3px); }
  to   { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }
}
@keyframes v26-page-out {
  from { opacity: 1; transform: translateY(0) scale(1); }
  to   { opacity: 0; transform: translateY(-4px) scale(.998); }
}
/* The main page stays scrollable; long dialogs scroll inside their own glass sheet. */
html { min-height: 100%; scroll-behavior: smooth; }
body { min-height: 100vh; min-height: 100dvh; overflow-x: clip; }
.wrap { animation: v26-fallback-enter .42s cubic-bezier(.16,1,.3,1) both; }
@keyframes v26-fallback-enter {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
dialog {
  max-height: calc(100dvh - 16px);
  max-width: calc(100vw - 16px);
  overscroll-behavior: contain;
}
dialog > .glass.sheet,
dialog form.glass.sheet,
.glass.sheet {
  max-height: calc(100dvh - 16px);
  overflow-x: hidden !important;
  overflow-y: auto !important;
  overscroll-behavior-y: contain;
  -webkit-overflow-scrolling: touch;
  touch-action: pan-y;
  scrollbar-gutter: stable;
  padding-bottom: max(24px, env(safe-area-inset-bottom));
}
dialog::backdrop { transition: background-color .25s ease; }
dialog[open] { animation: v26-dialog-in .30s cubic-bezier(.16,1,.3,1) both; }
@keyframes v26-dialog-in {
  from { opacity: 0; transform: translateY(14px) scale(.985); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
.glass, .dashstat, .quick, .item {
  background-clip: padding-box;
}
.btn, .brand, .adminnav a, .theme {
  -webkit-tap-highlight-color: transparent;
}
.btn { transition: transform .18s ease, background-color .2s ease, border-color .2s ease, box-shadow .2s ease; }
.btn:active { transform: scale(.985); }
.glass:focus-within { border-color: color-mix(in srgb, var(--focus) 30%, var(--line)); }
@media (max-width: 760px) {
  body { padding-bottom: max(30px, env(safe-area-inset-bottom)); }
  dialog { width: calc(100vw - 16px); }
  dialog form.glass.sheet, .glass.sheet { max-height: calc(100dvh - 16px); }
}
@media (prefers-reduced-motion: reduce) {
  @view-transition { navigation: none; }
  html { scroll-behavior: auto; }
  .wrap { animation: none !important; }
  ::view-transition-old(root), ::view-transition-new(root) { animation: none !important; }
  dialog[open] { animation: none !important; }
  .btn:active { transform: none; }
}


/* v8 rich-text rendering and editor controls */
.home-main-text>*:first-child,.home-public-note>*:first-child{margin-top:0}.home-main-text>*:last-child,.home-public-note>*:last-child{margin-bottom:0}.home-main-text p,.home-public-note p{margin:.6em 0}.home-main-text ul,.home-main-text ol,.home-public-note ul,.home-public-note ol{padding-left:1.5em}.home-main-text blockquote,.home-public-note blockquote{margin:.8em 0;padding:.25em 1em;border-left:3px solid var(--accent);background:var(--item);border-radius:0 9px 9px 0}.home-main-text img,.home-public-note img{max-width:100%;height:auto;border-radius:10px}.home-main-text table,.home-public-note table,.rtebody table{border-collapse:collapse;width:100%;margin:12px 0}.home-main-text td,.home-main-text th,.home-public-note td,.home-public-note th,.rtebody td,.rtebody th{border:1px solid var(--line);padding:7px 9px;vertical-align:top}.home-main-text pre,.home-public-note pre,.rtebody pre{white-space:pre-wrap;overflow-wrap:anywhere;padding:10px;border-radius:8px;background:var(--item)}
.rtebar select{max-width:180px;min-height:36px;padding:5px 8px;border:1px solid var(--line);border-radius:9px;background:var(--field);color:var(--text);font:inherit;font-size:.82rem}.rtebar input[type=color]{width:38px;min-width:38px;height:36px;padding:3px;border:1px solid var(--line);border-radius:9px;background:var(--field);cursor:pointer}.rtebar .rte-color{display:inline-flex;align-items:center;gap:4px;padding:0 5px;font-size:.72rem;color:var(--muted)}.rtebody{min-height:190px;line-height:1.7}.rtebody h1,.rtebody h2,.rtebody h3,.rtebody h4{margin:.8em 0 .45em}.rtebody blockquote{border-left:4px solid var(--accent);margin:1em 0;padding:.3em 1em;background:var(--item)}.rtebody img{max-width:100%;height:auto;border-radius:8px}.rtebody hr{border:0;border-top:1px solid var(--line);margin:1em 0}.rtefoot{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap}.preview-home-sample{margin-top:16px;padding:14px;border:1px solid var(--line);border-radius:14px;text-align:left;background:var(--item)}.preview-home-sample h2{font-size:1.2rem;margin:0 0 8px}.preview-home-sample .preview-note{margin-top:10px;padding-top:10px;border-top:1px solid var(--line)}

/*@theme*/`;

const FOOTER = "<!--@footer-->"; // remplacé à l’envoi par applySite()
function shell(nonce, title, body, script = "", theme = "light") {
  const palette = `<dialog id="v26Palette" aria-label="Recherche et navigation"><div class="glass sheet palette-sheet"><div class="palette-head"><div><div class="eyebrow">Navigation rapide</div><h2>Où voulez-vous aller ?</h2></div><button type="button" class="btn sm" id="v26PaletteClose" aria-label="Fermer la recherche">Échap ✕</button></div><input id="v26PaletteSearch" type="search" placeholder="Rechercher une page…" autocomplete="off" aria-label="Rechercher une page"><p class="muted palette-hint">Astuce : utilisez Ctrl + K (ou ⌘ + K sur Mac).</p><div id="v26PaletteResults" class="palette-results" role="listbox" aria-label="Pages disponibles"></div></div></dialog>`;
  const paletteScript = `<script nonce="${nonce}">(function(){const d=document.getElementById('v26Palette'),q=document.getElementById('v26PaletteSearch'),r=document.getElementById('v26PaletteResults'),close=document.getElementById('v26PaletteClose');if(!d||!q||!r)return;let items=[],active=0,shown=[];const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('fr');const draw=()=>{const term=norm(q.value.trim());shown=items.filter(x=>norm(x.label+' '+x.href).includes(term));active=shown.length?Math.min(Math.max(active,0),shown.length-1):0;r.replaceChildren();if(!shown.length){const p=document.createElement('p');p.className='muted palette-empty';p.textContent='Aucune page trouvée.';r.append(p);return;}shown.forEach((x,i)=>{const a=document.createElement('a');a.className='palette-item'+(i===active?' selected':'');a.href=x.href;a.setAttribute('role','option');a.setAttribute('aria-selected',String(i===active));const icon=document.createElement('span');icon.className='palette-icon';icon.textContent=x.icon||'↗';const label=document.createElement('span');label.textContent=x.label;a.append(icon,label);a.addEventListener('mouseenter',()=>{active=i;updateSelection();});r.append(a);});requestAnimationFrame(()=>r.querySelector('.selected')?.scrollIntoView({block:'nearest'}));};const updateSelection=()=>{[...r.querySelectorAll('.palette-item')].forEach((node,j)=>{node.classList.toggle('selected',j===active);node.setAttribute('aria-selected',String(j===active));});r.querySelector('.selected')?.scrollIntoView({block:'nearest'});};const refresh=()=>{items=[...document.querySelectorAll('.adminnav a:not(.locked), header a.who, header a.brand, a[href="/admin/red/new"]')].filter(a=>a.href&&new URL(a.href).origin===location.origin).map(a=>({href:a.getAttribute('href'),label:(a.innerText||a.getAttribute('aria-label')||a.title||'Page').replace(/\s+/g,' ').trim(),icon:a.querySelector('.navicon,.palette-icon')?.textContent?.trim()||'↗'}));const seen=new Set();items=items.filter(x=>x.href&&!seen.has(x.href)&&seen.add(x.href));draw();};const open=()=>{if(!document.querySelector('.adminnav'))return;refresh();q.value='';active=0;draw();if(!d.open)d.showModal();requestAnimationFrame(()=>q.focus());};const shut=()=>{if(d.open)d.close();};document.getElementById('v26PaletteOpen')?.addEventListener('click',open);close?.addEventListener('click',shut);q.addEventListener('input',()=>{active=0;draw();});q.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();if(shown.length){active=Math.min(active+1,shown.length-1);updateSelection();}}else if(e.key==='ArrowUp'){e.preventDefault();if(shown.length){active=Math.max(active-1,0);updateSelection();}}else if(e.key==='Enter'&&shown[active]){e.preventDefault();location.href=shown[active].href;}else if(e.key==='Escape'){shut();}});document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();open();}if(e.key==='Escape')shut();});d.addEventListener('click',e=>{if(e.target===d)shut();});})();</script>`;
  return `<!DOCTYPE html><html lang="fr" data-theme="${theme === "dark" ? "dark" : "light"}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><link rel="icon" type="image/svg+xml" href="${ICON}"><title>${esc(title)}</title><script nonce="${nonce}">try{const t=localStorage.getItem("links-theme");if(t==="light"||t==="dark")document.documentElement.dataset.theme=t;}catch{}</script><style nonce="${nonce}">${CSS}</style></head><body><div class="wrap">${body}${FOOTER}</div>${palette}${script ? `<script nonce="${nonce}">${script}</script>` : ""}${paletteScript}</body></html>`;
}
function pageTitle(page) { return ({dashboard:"Vue d’ensemble",red:"Redirections",rednew:"Ajouter une redirection",users:"Utilisateurs",account:"Mon compte",settings:"Personnalisation",analytics:"Centre d’analyse",login:"Connexion"}[page] || "Accueil") + " · " + TITLE; }
function htmlRes(nonce, html, status = 200) {
  return new Response(html, { status, headers: {
    "content-type": "text/html; charset=utf-8", "cache-control": "no-store",
    "content-security-policy": `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'nonce-${nonce}'; connect-src 'self'; img-src data: https:; frame-src https:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`,
    "x-content-type-options": "nosniff", "x-frame-options": "DENY", "referrer-policy": "no-referrer" } });
}
const THEME_SWITCH = light => `<button class="theme" id="th" type="button" role="switch" aria-checked="${light}" aria-label="Mode clair ou sombre" title="Mode clair / sombre"><span class="knob"><svg class="i-moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg><svg class="i-sun" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></span></button>`;
function header(me, page) {
  let right = "";
  if (!me) right = `${THEME_SWITCH(false)}${page === "login" ? "" : page === "home" ? `<button class="btn sm" id="openLogin" type="button">Se connecter</button>` : `<a class="btn sm" href="/#login">Se connecter</a>`}`;
  else right = `<a class="who${page === "account" ? " on" : ""}" href="/admin/account" title="Mon compte (@${esc(me.username)})"><span class="un">${esc(me.display)}</span><span class="grp">${esc(me.label)}</span></a><button class="btn sm palette-trigger" id="v26PaletteOpen" type="button" title="Navigation rapide (Ctrl+K)">⌕ <span>Rechercher</span> <kbd>⌘ K</kbd></button>${THEME_SWITCH(me.theme === "light")}<button class="btn sm" id="out" type="button" title="Fermer la session">Se déconnecter</button>`;
  const nav = me && page !== "home" ? `<nav class="adminnav" aria-label="Navigation de l’administration">
<a class="${page === "dashboard" ? "on" : ""}" href="/admin/dashboard"><span aria-hidden="true">⌂</span> Vue d’ensemble</a>
<a class="${page === "red" ? "on" : ""}" href="/admin"><span aria-hidden="true">↗</span> Redirections</a>
${me.perms.usersView ? `<a class="${page === "users" ? "on" : ""}" href="/admin/users"><span aria-hidden="true">♙</span> Utilisateurs</a>` : `<a href="/admin/users" aria-disabled="true" title="Vous n’avez pas l’autorisation de consulter les utilisateurs" class="locked"><span aria-hidden="true">♙</span> Utilisateurs · verrouillé</a>`}
<a class="${page === "account" ? "on" : ""}" href="/admin/account"><span aria-hidden="true">⚙</span> Mon compte</a>
${(me.owner || me.perms.analyticsView) ? `<a class="${page === "analytics" ? "on" : ""}" href="/admin/analytics"><span aria-hidden="true">▥</span> Centre d’analyse</a>` : ""}
${(me.owner || me.perms.groupsManage) ? `<a class="${page === "groups" ? "on" : ""}" href="/admin/groups"><span aria-hidden="true">▦</span> Groupes de droits</a>` : ""}
${me.owner ? `<a class="${page === "settings" ? "on" : ""}" href="/admin/settings"><span aria-hidden="true">✦</span> Personnalisation</a>` : ""}</nav>` : "";
  return `<header>${BRAND}<div class="right">${right}</div></header>${nav}`;
}
function notice(title, text, status) {
  const nonce = newNonce();
  return htmlRes(nonce, shell(nonce, TITLE, `<header>${BRAND}</header><div class="glass"><h1>${esc(title)}</h1><p class="muted">${esc(text)}</p></div>`), status);
}

/* ---------- Scripts (navigateur) ---------- */
const SESSION_JS = `
const out=document.getElementById('out');if(out)out.addEventListener('click',async()=>{try{await fetch('/admin/logout',{method:'POST'});}catch{}location.href='/';});
const th=document.getElementById('th');if(th)th.addEventListener('click',async()=>{const h=document.documentElement,n=h.dataset.theme==='light'?'dark':'light';
 h.classList.add('tt');h.dataset.theme=n;th.setAttribute('aria-checked',String(n==='light'));try{localStorage.setItem('links-theme',n);}catch{}setTimeout(()=>h.classList.remove('tt'),3150);
 try{await fetch('/admin/api/me/theme',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({theme:n})});}catch{}});`;
const COMMON_JS = SESSION_JS + `
const $=s=>document.querySelector(s);
function el(t,c,x){const n=document.createElement(t);if(c)n.className=c;if(x!==undefined)n.textContent=x;return n;}
async function api(p,o={}){const r=await fetch(p,{headers:{'Content-Type':'application/json'},...o});
 if(r.status===401){location.reload();return;}
 const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Erreur');return d;}
const fmt=ms=>new Date(ms).toLocaleString('fr-FR',{dateStyle:'medium',timeStyle:'short'});
function bindDialog(d){d.addEventListener('click',e=>{if(e.target===d)d.close();});}`;

const LOGIN_JS = SESSION_JS + `
const f=document.getElementById('f'),e=document.getElementById('e'),loginDialog=document.getElementById('loginDialog');
const showLogin=()=>{if(!loginDialog)return;if(!loginDialog.open)loginDialog.showModal();requestAnimationFrame(()=>document.getElementById('username')?.focus({preventScroll:true}));};
document.getElementById('openLogin')?.addEventListener('click',showLogin);
document.getElementById('closeLogin')?.addEventListener('click',()=>loginDialog?.close());
loginDialog?.addEventListener('click',ev=>{if(ev.target===loginDialog)loginDialog.close();});
if(location.hash==='#login')showLogin();
window.addEventListener('hashchange',()=>{if(location.hash==='#login')showLogin();});
f?.addEventListener('submit',async ev=>{ev.preventDefault();e.textContent='';
 try{const r=await fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:f.username.value,password:f.password.value})});
  const d=await r.json().catch(()=>({}));if(r.ok)location.href=d.mustChange?'/admin/account?force=1':'/admin/dashboard';else e.textContent=d.error||'Connexion impossible.';}
 catch{e.textContent='Réseau indisponible.';}});`;

const REDIR_JS = COMMON_JS + `
const err=$('#e'),list=$('#list');let allLinks=[];
const loc=ms=>{const d=new Date(ms-new Date(ms).getTimezoneOffset()*60000);return d.toISOString().slice(0,16);};
function wire(p){[['From',0],['Until',7*864e5]].forEach(([k,add])=>{const on=$('#'+p+k+'On'),inp=$('#'+p+k);if(!on||!inp)return;on.addEventListener('change',()=>{inp.disabled=!on.checked;if(on.checked&&!inp.value)inp.value=loc(Date.now()+add);});});}
function setDates(p,from,until){[['From',from],['Until',until]].forEach(([k,v])=>{const on=$('#'+p+k+'On'),inp=$('#'+p+k);if(!on||!inp)return;on.checked=!!v;inp.disabled=!v;inp.value=v?loc(v):'';});}
function readDates(p){const r={};for(const [k,key,name] of [['From','from','de début'],['Until','until','d’expiration']]){const on=$('#'+p+k+'On'),inp=$('#'+p+k);if(!on||!inp)continue;const v=inp.value;if(!on.checked){r[key]=null;continue;}const t=new Date(v).getTime();if(!v||isNaN(t))throw new Error('Date '+name+' invalide.');r[key]=t;}if(r.from&&r.until&&r.until<=r.from)throw new Error('La date d’expiration doit être après la date de début.');return r;}
function invalid(input,msg){if(!input)return;input.classList.remove('valid-field','invalid-field');void input.offsetWidth;input.classList.add('invalid-field');input.setAttribute('aria-invalid','true');const out=$('#'+input.id+'Error');if(out)out.textContent=msg||'';}
function valid(input){if(!input)return;input.classList.remove('invalid-field');input.classList.add('valid-field');input.setAttribute('aria-invalid','false');const out=$('#'+input.id+'Error');if(out)out.textContent='';}
function clearField(input){if(!input)return;input.classList.remove('invalid-field','valid-field');input.removeAttribute('aria-invalid');const out=$('#'+input.id+'Error');if(out)out.textContent='';}
function checkURL(input){const v=String(input?.value||'').trim();try{if(!v.toLowerCase().startsWith('https://')||v.includes(' '))throw 0;const u=new URL(v);if(u.protocol!=='https:'||!u.hostname)throw 0;valid(input);return true;}catch{invalid(input,'Adresse incorrecte : saisissez une URL HTTPS complète vers un site ou un fichier.');return false;}}
async function checkSlug(input,creating){const raw=String(input?.value||'').trim(),slug=raw.toLowerCase();if(!/^[a-z0-9][a-z0-9_-]{0,63}$/.test(slug)||['admin','robots.txt','favicon.ico'].includes(slug)){invalid(input,'Adresse courte invalide ou réservée. Utilisez lettres, chiffres, tirets ou tirets bas.');return false;}if(!creating){valid(input);return true;}try{const d=await api('/admin/api/links/check?slug='+encodeURIComponent(slug));if(d.exists){invalid(input,'Cette adresse courte est déjà utilisée. Choisissez-en une autre.');return false;}valid(input);return true;}catch(e){if(e.message&&/déjà|existe/i.test(e.message)){invalid(input,e.message);return false;}throw e;}}
function status(l){const n=Date.now();if(l.until&&n>l.until)return['Expirée','bad'];if(l.from&&n<l.from)return['Programmée','warn'];return['Active','ok'];}
function setType(prefix){const t=$('#'+prefix+'Type')?.value;const urlBox=$('#'+prefix+'UrlBox'),textBox=$('#'+prefix+'TextBox');if(urlBox)urlBox.hidden=t!=='url';if(textBox)textBox.hidden=t!=='text';const url=$('#'+prefix+'Url');if(url)url.required=t==='url';const open=$('#'+prefix+'OpenEditor');if(open&&t!=='text'){const panel=$('#'+prefix+'RichPanel');if(panel)panel.hidden=true;}}
function syncRich(prefix){const ed=$('#'+prefix+'Editor'),field=$('#'+prefix+'Content'),count=$('#'+prefix+'WordCount');if(!ed||!field)return;field.value=ed.innerHTML;if(count)count.textContent=ed.innerText.trim().length+' caractères';}
function wireRich(prefix){const wrap=$('#'+prefix+'Rich'),ed=$('#'+prefix+'Editor');if(!wrap||!ed)return;wrap.querySelectorAll('[data-cmd]').forEach(b=>{b.addEventListener('mousedown',e=>e.preventDefault());b.addEventListener('click',()=>{ed.focus();const cmd=b.dataset.cmd;let val=b.dataset.value||null;if(cmd==='createLink'){const href=prompt('Collez l’adresse HTTPS du lien :','https://');if(!href)return;try{const u=new URL(href);if(u.protocol!=='https:'||!u.hostname)throw 0;val=u.href;}catch{alert('Veuillez saisir une adresse HTTPS valide.');return;}document.execCommand('createLink',false,val);}else if(cmd==='formatBlock'){document.execCommand('formatBlock',false,val||'p');}else if(cmd==='insertImage'){const href=prompt('Adresse HTTPS de l’image :','https://');if(!href)return;try{const u=new URL(href);if(u.protocol!=='https:'||!u.hostname)throw 0;document.execCommand('insertImage',false,u.href);}catch{alert('Veuillez saisir une adresse HTTPS valide.');}}else if(cmd==='unlink'){document.execCommand('unlink',false,null);}else document.execCommand(cmd,false,val);syncRich(prefix);});});
wrap.querySelectorAll('[data-rich-format]').forEach(sel=>sel.addEventListener('change',()=>{ed.focus();document.execCommand('formatBlock',false,sel.value);syncRich(prefix);}));
wrap.querySelectorAll('[data-rich-color]').forEach(inp=>inp.addEventListener('input',()=>{ed.focus();document.execCommand(inp.dataset.richColor,false,inp.value);syncRich(prefix);}));
ed.addEventListener('input',()=>syncRich(prefix));ed.addEventListener('blur',()=>syncRich(prefix));
const open=$('#'+prefix+'OpenEditor'),panel=$('#'+prefix+'RichPanel');if(open&&panel)open.addEventListener('click',()=>{panel.hidden=false;open.hidden=true;ed.focus();});const close=$('#'+prefix+'CloseEditor');if(close&&panel)close.addEventListener('click',()=>{syncRich(prefix);panel.hidden=true;if(open)open.hidden=false;});
}
async function submitLink(prefix,editing){const type=$('#'+prefix+'Type').value,slugInput=$('#'+(editing?'mSlug':'slug')),slug=slugInput.value.trim().toLowerCase(),data={slug,name:$('#'+(editing?'mName':'cName')).value.trim(),contentType:type,showBy:$('#'+(editing?'mShowBy':'showBy')).checked,showFrom:$('#'+(editing?'mShowFrom':'showFrom')).checked,showUntil:$('#'+(editing?'mShowUntil':'showUntil')).checked,byFormat:$('#'+(editing?'mByFormat':'byFormat')).value,createOnly:!editing,...readDates(prefix)};
 if(!editing&&!await checkSlug(slugInput,true))throw new Error('Cette adresse courte est invalide ou déjà utilisée.');
 if(type==='url'){const target=$('#'+prefix+'Url');if(!checkURL(target))throw new Error('Veuillez corriger l’adresse de destination.');data.url=target.value.trim();}
 else if(type==='text'){syncRich(prefix);const content=$('#'+prefix+'Content').value;if(!content.trim()||!$('#'+prefix+'Editor').innerText.trim())throw new Error('Le contenu de la page texte ne peut pas être vide.');data.content=content;}
 await api('/admin/api/links',{method:'POST',body:JSON.stringify(data)});return true;}
const dlg=$('#dlg'),createDlg=$('#createDlg');
if(createDlg){bindDialog(createDlg);wire('c');wireRich('c');$('#pre').textContent=location.origin+'/';const nb=$('#newRedirBtn');if(nb)nb.addEventListener('click',()=>{const e=$('#ce');if(e)e.textContent='';createDlg.showModal();});const cancel=$('#cancelCreate');if(cancel)cancel.addEventListener('click',()=>createDlg.close());const cType=$('#cType');cType.addEventListener('change',()=>setType('c'));setType('c');const slug=$('#slug'),url=$('#cUrl');slug.addEventListener('input',()=>clearField(slug));slug.addEventListener('blur',()=>{checkSlug(slug,true).catch(e=>{$('#ce').textContent=e.message;});});url.addEventListener('input',()=>clearField(url));url.addEventListener('blur',()=>{if(url.value.trim())checkURL(url);});$('#f').addEventListener('submit',async ev=>{ev.preventDefault();const e=$('#ce');e.textContent='';try{await submitLink('c',false);createDlg.close();slug.value='';$('#cName').value='';$('#cUrl').value='';$('#cContent').value='';$('#cEditor').innerHTML='';syncRich('c');cType.value='url';setType('c');clearField(slug);clearField(url);setDates('c',null,null);load();}catch(x){e.textContent=x.message||'Impossible de créer la redirection.';if(/adresse courte|déjà utilisée|existe déjà/i.test(e.textContent))invalid(slug,e.textContent);else if(/destination|HTTPS|URL/i.test(e.textContent)&&cType.value==='url')invalid(url,e.textContent);}});}
if(dlg){bindDialog(dlg);wire('m');wireRich('m');$('#mType').addEventListener('change',()=>setType('m'));setType('m');$('#mf').addEventListener('submit',async ev=>{ev.preventDefault();const me=$('#me');me.textContent='';try{await submitLink('m',true);dlg.close();load();}catch(x){me.textContent=x.message||'Impossible de modifier la redirection.';if(/destination|HTTPS|URL/i.test(me.textContent))invalid($('#mUrl'),me.textContent);}});$('#mc').addEventListener('click',()=>dlg.close());}
function render(links){list.textContent='';const q=($('#linkSearch')?.value||'').trim().toLowerCase();const filtered=links.filter(l=>[l.slug,l.name,l.url,l.by,l.byName].some(v=>String(v||'').toLowerCase().includes(q)));const count=$('#linkCountLabel');if(count)count.textContent=filtered.length+' résultat'+(filtered.length===1?'':'s');if(!filtered.length){list.appendChild(el('p','muted',q?'Aucune redirection ne correspond à votre recherche.':'Aucune redirection pour le moment.'));return;}
 filtered.forEach(l=>{const short=location.origin+'/'+l.slug,it=el('div','item'),top=el('div','top'),st=status(l);top.append(el('div','short',short),el('span','badge '+st[1],st[0]));it.append(top);if(l.name)it.appendChild(el('div','dest','Nom : '+l.name));it.append(el('div','dest',(l.contentType==='text'?'▤ Document Texte':l.contentType==='pdf'?'▧ Ancien fichier hébergé (conservé)': '→ '+(l.url||'Lien externe'))),el('div','dest','Créateur : '+(l.by||'inconnu')));if(l.contentType==='text')it.appendChild(el('div','dest',(l.content||'').replace(/<[^>]*>/g,' ').slice(0,140)+(String(l.content||'').length>140?'…':'')));if(l.protected)it.appendChild(el('div','dest','🔒 Redirection protégée (ancienne option)'));if(l.from)it.appendChild(el('div','dest','Début : '+fmt(l.from)));if(l.until)it.appendChild(el('div','dest','Expiration : '+fmt(l.until)));
 const a=el('div','acts'),cp=el('button','btn','Copier');cp.onclick=async()=>{try{await navigator.clipboard.writeText(short);cp.textContent='Copié';setTimeout(()=>cp.textContent='Copier',1500);}catch{}};a.appendChild(cp);
 if(l.canEdit&&l.contentType!=='pdf'){const ed=el('button','btn','Modifier');ed.onclick=()=>{$('#mSlug').value=l.slug;$('#mName').value=l.name||'';$('#mUrl').value=l.url||'';$('#mType').value=l.contentType==='text'?'text':'url';$('#mContent').value=l.content||'';$('#mEditor').innerHTML=l.content||'';syncRich('m');setType('m');const panel=$('#mRichPanel'),open=$('#mOpenEditor');if(panel)panel.hidden=l.contentType!=='text';if(open)open.hidden=l.contentType==='text';setDates('m',l.from,l.until);$('#me').textContent='';clearField($('#mUrl'));dlg.showModal();};a.appendChild(ed);}else if(l.contentType==='pdf'){const note=el('button','btn','Fichier ancien · lecture seule');note.disabled=true;note.title='Ce fichier hébergé est conservé, mais les nouvelles redirections utilisent uniquement les liens HTTPS externes ou le texte riche.';a.appendChild(note);}else if(!l.own){const ed=el('button','btn','Modifier');ed.disabled=true;ed.title='Vous n’avez pas l’autorisation de modifier cette redirection';ed.setAttribute('aria-label',ed.title);a.appendChild(ed);}
 if(l.canDel){const dl=el('button','btn d','Supprimer');dl.onclick=async()=>{if(!confirm('Supprimer /'+l.slug+' ?'))return;try{await api('/admin/api/links/'+encodeURIComponent(l.slug),{method:'DELETE'});load();}catch(x){err.textContent=x.message;}};a.appendChild(dl);}it.appendChild(a);list.appendChild(it);});}
async function load(){try{allLinks=(await api('/admin/api/links')).links;render(allLinks);}catch(x){err.textContent=x.message;}}
const ls=$('#linkSearch');if(ls)ls.addEventListener('input',()=>render(allLinks));load();if(location.hash==='#new'&&createDlg)createDlg.showModal();`;
const USERS_JS = COMMON_JS + `
const KEYS=${JSON.stringify(KEYS)},SHORT=${JSON.stringify(Object.fromEntries(RIGHTS.map(r => [r.k, r.short])))},PRE=${JSON.stringify(PRESETS)};let groupDefs=[];
const loc=ms=>{const d=new Date(ms-new Date(ms).getTimezoneOffset()*60000);return d.toISOString().slice(0,16);};
function wire(p){[['From',0],['Until',7*864e5]].forEach(([k,add])=>{const on=$('#'+p+k+'On'),inp=$('#'+p+k);on.addEventListener('change',()=>{inp.disabled=!on.checked;if(on.checked&&!inp.value)inp.value=loc(Date.now()+add);});});}
function setDates(p,from,until){[['From',from],['Until',until]].forEach(([k,v])=>{const on=$('#'+p+k+'On'),inp=$('#'+p+k);on.checked=!!v;inp.disabled=!v;inp.value=v?loc(v):'';});}
function readDates(p){const r={};for(const [k,key,name] of [['From','from','de début'],['Until','until','d’expiration']]){const on=$('#'+p+k+'On').checked,v=$('#'+p+k).value;if(!on){r[key]=null;continue;}const t=new Date(v).getTime();if(!v||isNaN(t))throw new Error('Date '+name+' invalide.');r[key]=t;}if(r.from&&r.until&&r.until<=r.from)throw new Error('La date d’expiration doit être après la date de début.');return r;}
const GL={super:'Super-Admin',standard:'Utilisateur Standard',reader:'Lecteur',restricted:'Utilisateur Restreint',custom:'Personnalisé','':'Sans accès'};
const groupLabel=u=>{const g=groupDefs.find(x=>x.id===u.groupId);return g?g.name:(GL[gkey(u.perms)]||'Personnalisé');};
async function loadGroups(){const d=await api('/admin/api/groups');groupDefs=d.groups||[];const select=$('#grp'),old=select.value;select.innerHTML='<option value="">Choisir un groupe…</option>'+groupDefs.filter(g=>g.id!=='super'||AP.super).map(g=>'<option value="'+String(g.id).replace(/[&<>"']/g,'')+'">'+String(g.name).replace(/[&<>]/g,'')+'</option>').join('');if(old&&groupDefs.some(g=>g.id===old))select.value=old;}
const ctx=$('#ctx').dataset,AP=JSON.parse(ctx.perms),ul=$('#ulist'),ge=$('#ge'),dlg=$('#dlg'),ue=$('#ue');let allUsers=[];
const cb=k=>$('#p_'+k);
let editing=null,tags=[],selfLock=false;
const P=()=>{const p={super:cb('super').checked};KEYS.forEach(k=>p[k]=cb(k).checked);return p;};
function gkey(p){if(p.super)return'super';const on=KEYS.filter(k=>k!=='pw'&&p[k]).sort().join();if(!on)return'';for(const g in PRE)if(PRE[g].slice().sort().join()===on)return g;const g=groupDefs.find(x=>!x.builtin&&!x.perms.super&&KEYS.filter(k=>k!=='pw'&&x.perms[k]).sort().join()===on);return g?g.id:'custom';}
function lock(){if(!AP.super)cb('super').checked=false;const s=cb('super').checked;if(s)KEYS.forEach(k=>cb(k).checked=true);
 KEYS.forEach(k=>{if(!AP[k])cb(k).checked=false;cb(k).disabled=selfLock||s||!AP[k];});
 cb('super').disabled=selfLock||!AP.super;$('#grp').disabled=selfLock;}
function dep(k){const on=x=>cb(x).checked,set=(x,v)=>cb(x).checked=v;
 if((k==='editAll'||k==='delAll')&&on(k))set('view',true);
 if(k==='view'&&!on('view')){set('editAll',false);set('delAll',false);}
 if(['usersCreate','usersEdit','usersDelete'].includes(k)&&on(k))set('usersView',true);
 if(k==='usersView'&&!on('usersView')){set('usersCreate',false);set('usersEdit',false);set('usersDelete',false);}}
function sync(k){if(k)dep(k);lock();$('#grp').value=gkey(P());}
cb('super').addEventListener('change',()=>sync(null));
KEYS.forEach(k=>cb(k).addEventListener('change',()=>sync(k)));
$('#grp').addEventListener('change',()=>{const id=$('#grp').value,g=groupDefs.find(x=>x.id===id);
 if(id==='super'){cb('super').checked=true;}
 else if(g && id!=='custom'){cb('super').checked=false;KEYS.forEach(k=>cb(k).checked=!!g.perms[k]&&(AP.super||!!AP[k]));}
 else return;lock();$('#grp').value=id;});
if(!AP.super)$('#grp option[value="super"]').disabled=true;
function drawTags(){const c=$('#tags');c.textContent='';tags.forEach((t,i)=>{const s=el('span','tag',t),b=el('button','','×');b.type='button';
 b.setAttribute('aria-label','Retirer le tag '+t);b.onclick=()=>{tags.splice(i,1);drawTags();};s.appendChild(b);c.appendChild(s);});}
function addTag(){const v=$('#tagIn').value.replace(/,/g,' ').trim().slice(0,20);if(!v)return;
 if(tags.length>=8){ue.textContent='8 tags maximum.';return;}
 if(!tags.some(t=>t.toLowerCase()===v.toLowerCase()))tags.push(v);$('#tagIn').value='';drawTags();}
$('#tagIn').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===','){e.preventDefault();addTag();}});
$('#tagAdd').addEventListener('click',addTag);
function openUser(u){editing=u;ue.textContent='';selfLock=!!u&&u.username===ctx.user;
 setDates('u',u&&u.from,u&&u.until);$('#forcePw').checked=!!(u&&u.forcePwChange);
 $('#uTitle').textContent=u?'Modifier '+u.username:'Nouvel utilisateur';$('#uActive').checked=!u||u.active!==false;$('#uActive').disabled=!u||selfLock;$('#activeRow').title=selfLock?'Vous ne pouvez pas désactiver votre propre compte.':'';$('#activeRow').style.opacity=selfLock?'.55':'1';
 $('#un').value=u?u.username:'';$('#un').readOnly=!!u;$('#fn').value=u?u.first||'':'';$('#ln').value=u?u.last||'':'';
 $('#up').value='';$('#up').required=!u;
 $('#upl').textContent=u?'Nouveau mot de passe (laisse vide pour ne pas le changer)':'Mot de passe (10 caractères minimum)';
 cb('super').checked=u?u.perms.super:false;KEYS.forEach(k=>cb(k).checked=u?!!u.perms[k]:k==='pw');
 tags=u?[...(u.tags||[])]:[];$('#tagIn').value='';drawTags();lock();$('#grp').value=u?(u.groupId||gkey(u.perms)):'';if(typeof dlg.showModal==='function')dlg.showModal();else dlg.setAttribute('open','');}
function summary(p){if(p.super)return'Tous les droits';const a=KEYS.filter(k=>p[k]).map(k=>SHORT[k]);return a.length?a.join(', '):'Aucun';}
function renderUsers(users){ul.textContent='';const q=($('#userSearch')?.value||'').trim().toLowerCase();const filtered=users.filter(u=>[u.username,u.first,u.last,u.by,...(u.tags||[]),groupLabel(u)].some(v=>String(v||'').toLowerCase().includes(q)));const count=$('#userCountLabel');if(count)count.textContent=filtered.length+' résultat'+(filtered.length===1?'':'s');if(!filtered.length){ul.appendChild(el('p','muted',q?'Aucun utilisateur ne correspond à votre recherche.':'Aucun utilisateur.'));return;}
 // Toujours afficher le compte principal en premier, indépendamment des métadonnées KV.
 const ordered=[...filtered.filter(u=>u.owner),...filtered.filter(u=>!u.owner)];
 ordered.forEach(u=>{const it=el('div','item'),top=el('div','top'),nm=[u.first,u.last].filter(Boolean).join(' ')||u.username;
  top.append(el('div','pname',nm),el('span','grp',groupLabel(u)));
  it.append(top,el('div','dest','@'+u.username));
  if(u.tags&&u.tags.length){const c=el('div','chips');u.tags.forEach(t=>c.appendChild(el('span','tag',t)));it.appendChild(c);}
  it.appendChild(el('div','dest','Droits : '+summary(u.perms)));
  if(u.owner){it.appendChild(el('div','dest','Compte principal (géré dans Cloudflare)'));it.appendChild(el('span','badge ok','Super-Admin'));}
  else {it.appendChild(el('span','badge '+(u.active===false?'bad':'ok'),u.active===false?'Désactivé':'Actif'));if(u.created)it.appendChild(el('div','dest','Créé le '+u.created+(u.by?' par '+u.by:'')));if(u.forcePwChange)it.appendChild(el('div','dest','⚠ Changement de mot de passe requis à la prochaine connexion'));if(u.from)it.appendChild(el('div','dest','Actif à partir du '+fmt(u.from)));if(u.until)it.appendChild(el('div','dest','Expire le '+fmt(u.until)));}
  const a=el('div','acts');
  if(u.canEdit){const ed=el('button','btn','Modifier');ed.onclick=()=>openUser(u);a.appendChild(ed);}
  if(u.canDelete){const dl=el('button','btn d','Supprimer');
   dl.onclick=async()=>{if(!confirm('Supprimer l’utilisateur '+u.username+' ?'))return;try{await api('/admin/api/users/'+encodeURIComponent(u.username),{method:'DELETE'});load();}catch(x){ge.textContent=x.message;}};a.appendChild(dl);}
  if(a.children.length)it.appendChild(a);
  ul.appendChild(it);});}
async function load(){try{await loadGroups();const d=await api('/admin/api/users');allUsers=d.users||[];renderUsers(allUsers);}catch(x){ge.textContent=x.message;}}
const us=$('#userSearch');if(us)us.addEventListener('input',()=>renderUsers(allUsers));
bindDialog(dlg);const nu=$('#nu');if(nu)nu.addEventListener('click',()=>{try{openUser(null);}catch(x){ge.textContent='Impossible d’ouvrir le formulaire : '+(x&&x.message?x.message:'erreur inconnue');}});$('#uc').addEventListener('click',()=>dlg.close());
$('#uf').addEventListener('submit',async ev=>{ev.preventDefault();ue.textContent='';addTag();const p=P();
 if(!(p.super||KEYS.some(k=>k!=='pw'&&p[k]))){ue.textContent='Veuillez sélectionner au moins un droit (en plus du mot de passe).';return;}
 const body={first:$('#fn').value,last:$('#ln').value,tags,perms:p,groupId:$('#grp').value,password:$('#up').value,forcePwChange:$('#forcePw').checked,active:$('#uActive').checked,...readDates('u')};
 try{if(editing)await api('/admin/api/users/'+encodeURIComponent(editing.username),{method:'PUT',body:JSON.stringify(body)});
  else await api('/admin/api/users',{method:'POST',body:JSON.stringify({...body,username:$('#un').value})});
  dlg.close();load();}catch(x){ue.textContent=x.message;}});
wire('u');load();`;

function accountScript(me) { return COMMON_JS + `
const profile=$('#profileForm');let profileTags=${JSON.stringify(me.tags)};const tagBox=$('#profileTags'),tagIn=$('#profileTagIn');function drawProfileTags(){if(!tagBox)return;tagBox.textContent='';profileTags.forEach((t,i)=>{const s=el('span','tag',t),b=el('button','','×');b.type='button';b.onclick=()=>{profileTags.splice(i,1);drawProfileTags();};s.appendChild(b);tagBox.appendChild(s);});}if(tagIn){drawProfileTags();$('#profileTagAdd').onclick=()=>{const v=tagIn.value.trim().slice(0,20);if(v&&!profileTags.some(t=>t.toLowerCase()===v.toLowerCase())&&profileTags.length<8)profileTags.push(v);tagIn.value='';drawProfileTags();};tagIn.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===','){e.preventDefault();$('#profileTagAdd').click();}});}if(profile){profile.addEventListener('submit',async ev=>{ev.preventDefault();const e=$('#profileMsg');e.textContent='';const payload={};if(${me.owner || me.perms.profileEdit}){payload.first=$('#profileFirst').value;payload.last=$('#profileLast').value;}if(${me.owner || me.perms.tagsEdit})payload.tags=profileTags;try{await api('/admin/api/me/profile',{method:'POST',body:JSON.stringify(payload)});e.className='okmsg';e.textContent='Profil enregistré. Recharge la page pour voir les changements.';}catch(x){e.className='err';e.textContent=x.message;}});}
const pf=$('#pf');if(pf){const m=$('#pm');pf.addEventListener('submit',async ev=>{ev.preventDefault();m.textContent='';m.className='err';
 const n=$('#pn').value;if(n!==$('#pn2').value){m.textContent='Les deux nouveaux mots de passe sont différents.';return;}
 try{await api('/admin/api/me/password',{method:'POST',body:JSON.stringify({current:$('#pc').value,next:n})});pf.reset();m.className='okmsg';m.textContent='Mot de passe modifié.';}
 catch(x){m.textContent=x.message;}});}`; }

/* ---------- Pages ---------- */
const dateFields = p => `<label class="ck"><input type="checkbox" id="${p}FromOn"> Définir une date de début</label><input type="datetime-local" id="${p}From" aria-label="Date de début" disabled>
<label class="ck"><input type="checkbox" id="${p}UntilOn"> Définir une date d’expiration</label><input type="datetime-local" id="${p}Until" aria-label="Date d’expiration" disabled>`;

function publicHomePage(nonce, me = null) {
  const sessionCard = me ? `<section class="glass public-home-login"><div class="eyebrow">Session active</div><h2>Bonjour ${esc(me.first || me.username)}</h2><p class="muted">Vous êtes connecté à l’espace d’administration.</p><a class="btn p" href="/admin/dashboard">Ouvrir le tableau de bord</a></section>` : "";
  const loginModal = me ? "" : `<dialog id="loginDialog" class="login-dialog" aria-labelledby="loginTitle"><form class="glass sheet login-sheet" id="f" novalidate><div class="login-head"><div><div class="eyebrow">Administration</div><h2 id="loginTitle">Accéder à l’administration</h2><p class="muted">Connectez-vous pour accéder à la page d’administration et gérer le site.</p></div><button class="btn login-close" id="closeLogin" type="button" aria-label="Fermer la fenêtre de connexion" title="Fermer">✕</button></div><label for="username">Identifiant</label><input id="username" name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required aria-describedby="e"><label for="password">Mot de passe</label><input id="password" name="password" type="password" autocomplete="current-password" required aria-describedby="e"><div class="err" id="e" role="alert" aria-live="polite"></div><button class="btn p" type="submit">Se connecter</button></form></dialog>`;
  const layoutClass = me ? "public-home-session" : "public-home-public";
  const main = `${header(me,"home")}<main class="public-home ${layoutClass}"><section class="glass public-home-copy"><div class="eyebrow">Bienvenue</div><h1><!--@hometitle--></h1><div class="muted home-main-text"><!--@hometext--></div>${me?`<p class="mt18"><a class="btn" href="/admin">Gérer les redirections</a></p>`:`<div class="muted home-public-note mt18"><!--@homepublicnote--></div>`}</section>${sessionCard}</main>${loginModal}`;
  return htmlRes(nonce, shell(nonce, TITLE, main, me ? SESSION_JS : LOGIN_JS, me?.theme || "light"));
}
function loginPage(nonce) { return publicHomePage(nonce, null); }
function dashboardPage(nonce, me) {
  const p = me.perms;
  const canUsers = p.usersView;
  const status = p.super ? "Accès complet" : (p.view ? "Consultation partagée" : "Espace personnel");
  const actions = `<div class="quickgrid">
<a class="quick" href="/admin"><span class="quickicon" aria-hidden="true">↗</span><span><strong>Gérer les redirections</strong><small>Consultez les liens, créez-en de nouveaux ou modifiez ceux que vos droits vous autorisent à gérer.</small></span></a>
${canUsers ? `<a class="quick" href="/admin/users"><span class="quickicon" aria-hidden="true">♙</span><span><strong>Gérer les utilisateurs</strong><small>Comptes, groupes et autorisations dans un espace dédié.</small></span></a>` : `<div class="quick off" aria-disabled="true" title="Vous n’avez pas l’autorisation de consulter les utilisateurs"><span class="quickicon" aria-hidden="true">🔒</span><span><strong>Gestion des utilisateurs · verrouillée</strong><small>Cette section nécessite l’autorisation « Voir les utilisateurs ».</small></span></div>`}
${(p.super || p.groupsManage) ? `<a class="quick" href="/admin/groups"><span class="quickicon" aria-hidden="true">▦</span><span><strong>Gérer les groupes de droits</strong><small>Créez et organisez des modèles d’autorisations réutilisables.</small></span></a>` : ""}
${(p.super || p.analyticsView) ? `<a class="quick" href="/admin/analytics"><span class="quickicon" aria-hidden="true">▥</span><span><strong>Centre d’analyse</strong><small>Consultez les requêtes reçues, les pays et les codes HTTP.</small></span></a>` : ""}
<a class="quick" href="/admin/account"><span class="quickicon" aria-hidden="true">⚙</span><span><strong>Mon compte</strong><small>Profil, thème et options de sécurité. Le compte principal reste géré par Cloudflare.</small></span></a>
<a class="quick" href="/" target="_blank" rel="noopener"><span class="quickicon" aria-hidden="true">⌁</span><span><strong>Tester une redirection</strong><small>Ouvrir la page publique et tester un raccourci existant.</small></span></a>
</div>`;
  const permissions = [{k:"view",t:"Voir les redirections partagées"},{k:"create",t:"Créer des redirections"},{k:"editOwn",t:"Modifier les siennes"},{k:"editAll",t:"Modifier celles des autres"},{k:"usersView",t:"Consulter les utilisateurs"}];
  const pills = permissions.filter(x=>p.super||p[x.k]).map(x=>`<span class="accesspill">${x.t}</span>`).join("") || `<span class="muted">Aucun droit de gestion spécifique n’est activé.</span>`;
  const script = COMMON_JS + `
(async()=>{try{const d=await api('/admin/api/links');const n=d.links.length;const e=document.getElementById('linkCount');if(e)e.textContent=n;const own=d.links.filter(x=>x.own).length;const o=document.getElementById('ownCount');if(o)o.textContent=own;const a=document.getElementById('shareCount');if(a)a.textContent=n-own;}catch(e){for(const id of ['linkCount','ownCount','shareCount']){const n=document.getElementById(id);if(n)n.textContent='—';}}})();`;
  return htmlRes(nonce, shell(nonce, pageTitle("dashboard"), `${header(me, "dashboard")}
<section class="glass dashhero"><div class="eyebrow">Centre de contrôle · Cloudflare Pages</div><h1>Bonjour ${esc(me.first || me.username)} 👋</h1><p class="muted">Bienvenue dans votre espace de gestion. Tout est organisé par rubrique : retrouvez rapidement vos redirections, les comptes et les paramètres de votre profil.</p><div class="accessrow"><span class="grp">${esc(me.label)}</span><span class="accesspill">${status}</span><span class="accesspill">Session protégée</span></div></section>
<div class="dashgrid"><article class="dashstat"><div class="staticon" aria-hidden="true">↗</div><div class="statnum" id="linkCount">…</div><div class="statlabel">Redirections visibles</div></article><article class="dashstat"><div class="staticon" aria-hidden="true">✦</div><div class="statnum" id="ownCount">…</div><div class="statlabel">Créées par vous</div></article><article class="dashstat"><div class="staticon" aria-hidden="true">◎</div><div class="statnum" id="shareCount">…</div><div class="statlabel">Autres redirections visibles</div></article></div>
<section class="dashsection"><h2>Raccourcis</h2>${actions}</section>
<section class="glass dashsection"><h2>Ton niveau d’accès</h2><p class="muted">Les actions disponibles dépendent des autorisations attribuées à votre compte. Les options non autorisées restent verrouillées et expliquées au survol.</p><div class="accessrow">${pills}</div></section>`, script, me.theme));
}

function richEditorMarkup(prefix) {
  const btn = (cmd, label, title, value = "") => `<button type="button" data-cmd="${cmd}" ${value ? `data-value="${value}"` : ""} title="${esc(title)}" aria-label="${esc(title)}">${label}</button>`;
  return `<div id="${prefix}Rich" class="rich-editor-shell"><div class="rich-toolbar" role="toolbar" aria-label="Outils de mise en forme">
    ${btn("undo","↶","Annuler")}${btn("redo","↷","Rétablir")}<span class="tool-sep"></span>${btn("bold","B","Gras")}${btn("italic","I","Italique")}${btn("underline","U","Souligné")}${btn("strikeThrough","S̶","Barré")}<span class="tool-sep"></span>
    <select data-rich-format aria-label="Style du paragraphe" title="Style du paragraphe"><option value="p">Paragraphe</option><option value="h2">Titre 2</option><option value="h3">Titre 3</option><option value="blockquote">Citation</option><option value="pre">Code</option></select>
    ${btn("insertUnorderedList","• Liste","Liste à puces")}${btn("insertOrderedList","1. Liste","Liste numérotée")}${btn("justifyLeft","⇤","Aligner à gauche")}${btn("justifyCenter","≡","Centrer")}${btn("justifyRight","⇥","Aligner à droite")}<span class="tool-sep"></span>
    ${btn("createLink","🔗","Insérer un lien HTTPS")}${btn("unlink","⛓","Retirer le lien")}${btn("insertImage","▧","Insérer une image distante HTTPS")}${btn("insertHorizontalRule","―","Insérer une ligne horizontale")}${btn("removeFormat","Tx","Retirer la mise en forme")}
    <label title="Couleur du texte">Texte <input type="color" data-rich-color="foreColor" value="#2563eb" aria-label="Couleur du texte"></label><label title="Couleur de surlignage">Surlignage <input type="color" data-rich-color="hiliteColor" value="#fff59d" aria-label="Couleur de surlignage"></label>
  </div><div id="${prefix}Editor" class="rich-editor" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Contenu de la page texte" data-placeholder="Rédigez votre contenu ici…" spellcheck="true"></div><div class="editor-footer"><span>Liens HTTPS · mise en forme · listes · citations · couleurs</span><span id="${prefix}WordCount">0 caractères</span></div></div><textarea id="${prefix}Content" hidden aria-hidden="true"></textarea>`;
}
function redirPage(nonce, me) {
  const P = me.perms, canEditAny = P.editOwn || P.editAll || P.super;
  const form = P.create ? `<div class="glass"><div class="head"><div><h1>Redirections</h1><p class="muted">Liens HTTPS vers un site ou un fichier externe, ou pages de texte enrichi.</p></div><button class="btn p auto" id="newRedirBtn" type="button">＋ Ajouter une redirection</button></div></div><div class="glass red-select-info"><p class="muted red-selection-copy">Sélectionnez une redirection pour copier l’adresse ou la modifier.</p><div class="err" id="e" role="alert"></div></div>
<dialog id="createDlg"><form class="glass sheet" id="f" novalidate><h1>Nouvelle redirection</h1><p class="muted">Choisissez une adresse courte, puis un lien HTTPS externe ou une page texte avec mise en forme avancée.</p>
<label for="slug">Adresse courte <span class="tip" title="Compose la partie finale de votre lien public. Lettres, chiffres, tirets et tirets bas uniquement." aria-label="Aide sur l’adresse courte">i</span> <span class="muted" id="pre"></span></label><input id="slug" required maxlength="64" placeholder="mon-lien" autocapitalize="none" spellcheck="false" pattern="[A-Za-z0-9_\-]+" title="Exemple : mon-lien. L’adresse doit être unique."><div id="slugError" class="field-error" role="alert"></div>
<label for="cName">Nom de la redirection <span class="muted">(facultatif)</span></label><input id="cName" maxlength="120" placeholder="Ex. Documentation du serveur"><p class="muted">Ce nom sera affiché sur l’écran de confirmation avant la redirection.</p>\n<label for="cType">Type de redirection <span class="tip" title="Choisissez un site/fichier externe ou une page de texte enrichi hébergée ici." aria-label="Aide sur le type">i</span></label><select id="cType"><option value="url">Lien vers un site ou fichier externe</option><option value="text">Document Texte (éditeur avancé)</option></select>
<div id="cUrlBox"><label for="cUrl">URL du site ou du fichier externe <span class="tip" title="Adresse HTTPS complète, par exemple https://exemple.fr/document.pdf." aria-label="Aide sur la destination">i</span></label><input id="cUrl" type="text" inputmode="url" maxlength="700" placeholder="https://exemple.fr/document.pdf" autocomplete="url" title="Utilisez une adresse HTTPS complète."><div id="cUrlError" class="field-error" role="alert"></div><p class="muted">Le lien peut pointer vers un site, un document PDF ou un autre fichier accessible en HTTPS.</p></div>
<div id="cTextBox" hidden><p class="muted">Créez une page publique avec titres, mise en forme, listes, citations, liens et couleurs.</p><button id="cOpenEditor" class="btn" type="button">✎ Ouvrir l’éditeur avancé</button><div id="cRichPanel" hidden>${richEditorMarkup("c")}<div class="two"><button id="cCloseEditor" class="btn" type="button">Fermer l’éditeur</button></div></div></div>
${dateFields("c")}<h2 class="sect mt18">Informations visibles avant la redirection</h2><label class="ck"><input type="checkbox" id="showBy" checked><span>Afficher le créateur</span></label><label for="byFormat">Nom du créateur affiché</label><select id="byFormat"><option value="name">Prénom et nom</option><option value="username">Identifiant</option></select><label class="ck"><input type="checkbox" id="showFrom" checked><span>Afficher la date de début</span></label><label class="ck"><input type="checkbox" id="showUntil" checked><span>Afficher la date d’expiration</span></label>
<div class="err" id="ce" role="alert"></div><div class="two"><button class="btn" id="cancelCreate" type="button">Annuler</button><button class="btn p" type="submit">Créer la redirection</button></div></form></dialog>`
    : `<div class="glass"><h1>Redirections</h1><p class="muted">${canEditAny ? "Vous pouvez modifier les redirections existantes selon vos droits." : "Accès en lecture seule : vous pouvez consulter les redirections."}</p><div class="err" id="e" role="alert"></div></div>`;
  const dialog = canEditAny ? `<dialog id="dlg"><form class="glass sheet" id="mf" novalidate><h1>Modifier la redirection</h1><label for="mSlug">Adresse courte</label><input id="mSlug" readonly>
<label for="mName">Nom de la redirection <span class="muted">(facultatif)</span></label><input id="mName" maxlength="120" placeholder="Ex. Documentation du serveur"><p class="muted">Ce nom sera affiché sur l’écran de confirmation avant la redirection.</p>\n<label for="mType">Type de redirection</label><select id="mType"><option value="url">Lien vers un site ou fichier externe</option><option value="text">Document Texte (éditeur avancé)</option></select>
<div id="mUrlBox"><label for="mUrl">URL du site ou du fichier externe <span class="tip" title="Adresse HTTPS complète." aria-label="Aide sur la destination">i</span></label><input id="mUrl" type="text" inputmode="url" maxlength="700" placeholder="https://exemple.fr/document.pdf"><div id="mUrlError" class="field-error" role="alert"></div></div>
<div id="mTextBox" hidden><button id="mOpenEditor" class="btn" type="button">✎ Ouvrir l’éditeur avancé</button><div id="mRichPanel" hidden>${richEditorMarkup("m")}<div class="two"><button id="mCloseEditor" class="btn" type="button">Fermer l’éditeur</button></div></div></div><p class="muted">Les anciennes options de protection et d’intégration ne sont pas proposées dans les nouvelles redirections ; les liens existants sont conservés.</p>
${dateFields("m")}<h2 class="sect mt18">Informations visibles avant la redirection</h2><label class="ck"><input type="checkbox" id="mShowBy" checked><span>Afficher le créateur</span></label><label for="mByFormat">Nom du créateur affiché</label><select id="mByFormat"><option value="name">Prénom et nom</option><option value="username">Identifiant</option></select><label class="ck"><input type="checkbox" id="mShowFrom" checked><span>Afficher la date de début</span></label><label class="ck"><input type="checkbox" id="mShowUntil" checked><span>Afficher la date d’expiration</span></label>
<div class="err" id="me" role="alert"></div><div class="two"><button class="btn" id="mc" type="button">Annuler</button><button class="btn p" type="submit">Enregistrer</button></div></form></dialog>` : "";
  const note = !P.view ? `<p class="muted mt18">Vous voyez uniquement vos propres redirections.</p>` : "";
  return htmlRes(nonce, shell(nonce, pageTitle("red"), `${header(me, "red")}${form}${dialog}${note}<div class="glass red-search-panel"><label for="linkSearch">Rechercher une redirection <span class="tip" title="Recherchez par adresse courte, destination ou créateur." aria-label="Aide sur la recherche">i</span></label><div class="searchbar"><input id="linkSearch" type="search" placeholder="Ex. mon-lien, exemple.fr…" autocomplete="off"><span class="searchmeta" id="linkCountLabel">0 résultat</span></div></div><div class="list" id="list"></div>`, REDIR_JS, me.theme));
}
function newRedirPage(nonce, me) {
  return new Response(null, { status: 302, headers: { Location: "/admin#new", "Cache-Control": "no-store" } });
}

function usersPage(nonce, me) {
  const rights = RIGHTS.map(r => (r.sec ? `<p class="sechead">${r.sec}</p>` : "") + `<label class="ck perm"><input type="checkbox" id="p_${r.k}"><span>${r.label}${r.hint ? `<small>${r.hint}</small>` : ""}</span></label>`).join("");
  const add = me.perms.usersCreate ? `<button class="btn p auto" id="nu" type="button">Nouvel utilisateur</button>` : "";
  return htmlRes(nonce, shell(nonce, pageTitle("users"), `${header(me, "users")}<div id="ctx" hidden data-user="${esc(me.username)}" data-perms="${esc(JSON.stringify(me.perms))}"></div>
<div class="glass"><div class="head"><div><h1>Utilisateurs</h1><p class="muted">Un utilisateur ne peut accorder ou gérer que des droits qu’il possède lui-même.</p></div>${add}</div><div class="err" id="ge" role="alert"></div><label for="userSearch">Rechercher un utilisateur <span class="tip" title="Recherchez par prénom, nom, identifiant, groupe ou tag." aria-label="Aide sur la recherche">i</span></label><div class="searchbar"><input id="userSearch" type="search" placeholder="Ex. prénom, identifiant, homelab…" autocomplete="off"><span class="searchmeta" id="userCountLabel">0 résultat</span></div></div>
<div class="list" id="ulist"></div>
<dialog id="dlg"><form class="glass sheet" id="uf"><h1 id="uTitle">Nouvel utilisateur</h1>
<label for="un">Identifiant</label><input id="un" required minlength="3" maxlength="32" autocomplete="off" autocapitalize="none" spellcheck="false" pattern="[A-Za-z0-9_\\-]+">
<div class="row2"><div><label for="fn">Prénom <span class="tip" title="Prénom affiché dans la liste des utilisateurs et sur les pages où le créateur est visible." aria-label="Aide sur le prénom">i</span></label><input id="fn" required maxlength="40" autocomplete="off"></div><div><label for="ln">Nom <span class="tip" title="Nom affiché dans la liste des utilisateurs et sur les pages où le créateur est visible." aria-label="Aide sur le nom">i</span></label><input id="ln" required maxlength="40" autocomplete="off"></div></div>
<label for="up" id="upl">Mot de passe (10 caractères minimum)</label><input id="up" type="password" minlength="10" maxlength="128" autocomplete="new-password"><label class="ck"><input type="checkbox" id="forcePw"><span>Exiger un changement de mot de passe à la prochaine connexion<small>Le compte devra choisir un nouveau mot de passe avant d’accéder à l’administration.</small></span></label><label class="ck" id="activeRow"><input type="checkbox" id="uActive" checked><span>Compte activé<small>Si décoché, l’utilisateur ne pourra plus se connecter. Ses données ne sont pas supprimées.</small></span></label>${dateFields("u")}
<label for="tagIn">Tags <span class="tip" title="Ajoutez des mots-clés pour retrouver plus facilement les comptes. Huit tags maximum." aria-label="Aide sur les tags">i</span></label><div class="tagrow"><input id="tagIn" maxlength="20" placeholder="ex. famille, amis, test" autocomplete="off"><button class="btn" id="tagAdd" type="button">Ajouter</button></div><div class="chips" id="tags"></div>
<label for="grp">Groupe <span class="tip" title="Un groupe préconfigure les droits ; vous pouvez ensuite ajuster les autorisations une par une." aria-label="Aide sur le groupe">i</span></label><select id="grp"><option value="">Chargement des groupes…</option></select>
<p class="muted hint">Le groupe est un raccourci : il coche les cases correspondantes. Super-Admin coche tout et grise les cases. Vous pouvez ensuite ajuster chaque droit.</p>
<label>Droits</label>
<label class="ck perm"><input type="checkbox" id="p_super"><span>Super-Admin<small>Tous les droits, y compris ceux ajoutés plus tard.</small></span></label>
${rights}
<div class="err" id="ue" role="alert"></div><div class="two"><button class="btn" id="uc" type="button">Annuler</button><button class="btn p" type="submit">Enregistrer</button></div></form></dialog>`, USERS_JS, me.theme));
}
const GROUPS_JS = COMMON_JS + `
const KEYS=${JSON.stringify(KEYS)},RIGHTS=${JSON.stringify(RIGHTS.map(r=>({k:r.k,label:r.label,sec:r.sec||"",hint:r.hint||""})))},ctx=$('#groupsCtx'),AP=JSON.parse(ctx.dataset.perms),list=$('#groupsList'),msg=$('#groupsMsg'),dlg=$('#groupDlg'),form=$('#groupForm');let groups=[],editing=null;
function groupPerms(g){if(g.perms&&g.perms.super)return 'Tous les droits';return KEYS.filter(k=>g.perms&&g.perms[k]).map(k=>{const r=RIGHTS.find(x=>x.k===k);return r?r.label:k;}).join(' · ')||'Aucun droit';}
function draw(){list.textContent='';const built=groups.filter(g=>g.builtin),custom=groups.filter(g=>!g.builtin);const sections=[['Groupes intégrés',built],['Mes groupes personnalisés',custom]];sections.forEach(([title,arr])=>{const h=el('h2','sect',title);list.appendChild(h);if(!arr.length){list.appendChild(el('p','muted','Aucun groupe dans cette section.'));return;}arr.forEach(g=>{const card=el('article','group-card'),head=el('div','group-card-head'),name=el('div',''),title=el('h2','',g.name),id=el('p','muted','Identifiant : '+g.id);name.append(title,id);head.append(name,el('span','badge '+(g.builtin?'':'ok'),g.builtin?'Intégré':'Personnalisé'));card.append(head);if(g.description)card.appendChild(el('p','muted',g.description));card.appendChild(el('p','muted','Droits inclus'));const pills=el('div','group-perms');if(g.perms.super)pills.appendChild(el('span','','Tous les droits'));else KEYS.filter(k=>g.perms&&g.perms[k]).forEach(k=>{const r=RIGHTS.find(x=>x.k===k);pills.appendChild(el('span','',r?r.label:k));});card.appendChild(pills);if(!g.builtin){const acts=el('div','acts'),ed=el('button','btn','Modifier'),dup=el('button','btn','Dupliquer'),del=el('button','btn d','Supprimer');ed.onclick=()=>open(g,false);dup.onclick=()=>open(g,true);del.onclick=async()=>{if(!confirm('Supprimer le groupe « '+g.name+' » ? Les droits déjà attribués aux utilisateurs ne seront pas effacés.'))return;try{await api('/admin/api/groups/'+encodeURIComponent(g.id),{method:'DELETE'});load();}catch(e){msg.textContent=e.message;}};acts.append(ed,dup,del);card.appendChild(acts);}else{card.appendChild(el('p','muted','Groupe intégré : il ne peut pas être supprimé. Vous pouvez créer une copie personnalisée pour l’adapter.'));}list.appendChild(card);});});}
function drawRights(perms){const box=$('#groupRights');box.textContent='';RIGHTS.forEach(r=>{if(r.sec)box.appendChild(el('p','sechead',r.sec));const label=document.createElement('label');label.className='ck perm';const input=document.createElement('input');input.type='checkbox';input.id='gp_'+r.k;input.checked=!!(perms&&perms[r.k]);input.disabled=!AP.super&&!AP[r.k];const span=document.createElement('span');span.textContent=r.label;if(r.hint){const small=document.createElement('small');small.textContent=r.hint;span.appendChild(small);}label.append(input,span);box.appendChild(label);});}
function slugify(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,32)||'groupe';}
function open(g,duplicate){editing=g&&!duplicate?g:null;msg.textContent='';form.reset();$('#groupTitle').textContent=editing?'Modifier le groupe : '+editing.name:(duplicate?'Dupliquer un groupe':'Nouveau groupe de droits');$('#groupId').value=editing?editing.id:(duplicate?slugify(g.name+'-copie'):'');$('#groupId').readOnly=!!editing;$('#groupName').value=editing?editing.name:(duplicate?g.name+' (copie)':'');$('#groupDescription').value=editing?g.description||'':(duplicate?g.description||'':'');drawRights(editing?editing.perms:(duplicate?g.perms:{}));dlg.showModal();}
async function load(){try{const d=await api('/admin/api/groups');groups=d.groups||[];draw();}catch(e){msg.textContent=e.message;}}
$('#newGroup').addEventListener('click',()=>open(null,false));$('#closeGroup').addEventListener('click',()=>dlg.close());form.addEventListener('submit',async ev=>{ev.preventDefault();msg.textContent='';const id=$('#groupId').value.trim().toLowerCase(),name=$('#groupName').value.trim(),description=$('#groupDescription').value.trim(),perms={};KEYS.forEach(k=>{const c=$('#gp_'+k);perms[k]=!!c?.checked;});if(!/^[a-z0-9][a-z0-9_-]{1,31}$/.test(id)){msg.textContent='Identifiant invalide : 2 à 32 caractères, lettres minuscules, chiffres, tirets et tirets bas.';return;}if(!name){msg.textContent='Le nom du groupe est obligatoire.';return;}try{const payload={id,name,description,perms};if(editing)await api('/admin/api/groups/'+encodeURIComponent(editing.id),{method:'PUT',body:JSON.stringify(payload)});else await api('/admin/api/groups',{method:'POST',body:JSON.stringify(payload)});dlg.close();load();}catch(e){msg.textContent=e.message;}});load();`;
function groupsPage(nonce, me) {
  const ctx = `<div id="groupsCtx" hidden data-perms="${esc(JSON.stringify(me.perms))}"></div>`;
  return htmlRes(nonce, shell(nonce, pageTitle("groups"), `${header(me,"groups")}${ctx}<section class="glass"><div class="head"><div><h1>Groupes de droits</h1><p class="muted">Créez des modèles réutilisables lors de la création d’un utilisateur. Les groupes personnalisés ne donnent jamais plus de droits que ceux que vous possédez.</p></div><button id="newGroup" class="btn p auto" type="button">＋ Nouveau groupe</button></div><div id="groupsMsg" class="err" role="alert"></div></section><div id="groupsList" class="list"></div><dialog id="groupDlg"><form id="groupForm" class="glass sheet" novalidate><h1 id="groupTitle">Nouveau groupe de droits</h1><label for="groupName">Nom du groupe</label><input id="groupName" required maxlength="60" placeholder="Ex. Gestionnaires de fichiers"><label for="groupId">Identifiant technique</label><input id="groupId" required minlength="2" maxlength="32" pattern="[a-z0-9_-]+" placeholder="gestion-fichiers"><p class="muted">L’identifiant est créé en minuscules et ne peut pas contenir d’espaces.</p><label for="groupDescription">Description (facultative)</label><textarea id="groupDescription" rows="3" maxlength="240" placeholder="À quoi sert ce groupe ?"></textarea><h2 class="sect mt18">Droits du groupe</h2><p class="muted">Les cases correspondant à des droits que vous ne possédez pas sont verrouillées.</p><div id="groupRights"></div><div id="groupSaveError" class="err" role="alert"></div><div class="two"><button id="closeGroup" class="btn" type="button">Annuler</button><button class="btn p" type="submit">Enregistrer le groupe</button></div></form></dialog>`, GROUPS_JS, me.theme));
}

function accountPage(nonce, me) {
  const ini = esc(((me.first[0] || "") + (me.last[0] || "") || me.username.slice(0, 2)).toUpperCase());
  const tags = me.tags.map(t => `<span class="tag">${esc(t)}</span>`).join("");
  const tagsEditor = (me.owner || me.perms.tagsEdit) ? `<label for="profileTagIn">Mes tags</label><div class="tagrow"><input id="profileTagIn" maxlength="20" placeholder="ex. homelab, admin, test"><button class="btn" id="profileTagAdd" type="button">Ajouter</button></div><div class="chips" id="profileTags">${tags}</div><p class="muted">8 tags maximum. Les tags sont visibles dans la page Utilisateurs.</p>` : `<p class="muted">Tags : ${tags || "aucun"}. Vous n’avez pas l’autorisation de les modifier.</p>`;
  const pw = me.owner ? `<label for="managedPassword">Mot de passe du compte</label><input id="managedPassword" type="password" value="••••••••••••" disabled title="Compte géré par Cloudflare" aria-describedby="managedHint"><p class="muted" id="managedHint">Compte géré par Cloudflare : le mot de passe se modifie dans les paramètres Cloudflare (secret <strong>ADMIN_PASSWORD</strong>), pas ici.</p>`
    : (!me.perms.pw && !me.forcePwChange) ? `<p class="muted">Ton compte n’est pas autorisé à modifier son mot de passe. Demande à un Super-Admin.</p>`
    : `<form id="pf"><label for="pc">Mot de passe actuel</label><input id="pc" type="password" autocomplete="current-password" required><label for="pn">Nouveau mot de passe (10 caractères minimum)</label><input id="pn" type="password" autocomplete="new-password" minlength="10" maxlength="128" required><label for="pn2">Confirmer le nouveau mot de passe</label><input id="pn2" type="password" autocomplete="new-password" minlength="10" maxlength="128" required><div class="err" id="pm" role="alert"></div><button class="btn p" type="submit">Changer le mot de passe</button></form>`;
  return htmlRes(nonce, shell(nonce, pageTitle("account"), `${header(me, "account")}
<div class="glass"><div class="prof"><div class="avatar" aria-hidden="true">${ini}</div><div><div class="pname big">${esc(me.display)}</div><div class="muted">@${esc(me.username)}</div></div></div>
<div class="chips mt14"><span class="grp">${esc(me.label)}</span>${me.owner ? `<span class="accesspill" title="Compte administrateur configuré dans Cloudflare">Compte principal · géré par Cloudflare</span>` : ""}</div></div>
<div class="glass sec"><h1>Mon profil</h1><form id="profileForm"><label for="profileFirst">Prénom</label><input id="profileFirst" maxlength="40" value="${esc(me.first)}" ${(!me.owner && !me.perms.profileEdit) ? "disabled title=\"Vous n’avez pas l’autorisation de modifier vos informations personnelles\"" : ""} ${me.owner ? "" : "required"}><label for="profileLast">Nom</label><input id="profileLast" maxlength="40" value="${esc(me.last)}" ${(!me.owner && !me.perms.profileEdit) ? "disabled title=\"Vous n’avez pas l’autorisation de modifier vos informations personnelles\"" : ""} ${me.owner ? "" : "required"}><p class="muted">Identifiant : <strong>${esc(me.username)}</strong> · non modifiable.</p><label for="profileManagedPw">Mot de passe du compte</label><input id="profileManagedPw" type="password" value="••••••••••" disabled title="Compte géré par Cloudflare" aria-label="Mot de passe non modifiable ici"><p class="muted">Le mot de passe n’est jamais affiché ni modifié dans ce formulaire.</p>${tagsEditor}<div id="profileMsg" class="err" role="status"></div>${(!me.owner && !me.perms.profileEdit && !me.perms.tagsEdit) ? `<p class="muted" title="Vous n’avez pas l’autorisation de modifier vos informations personnelles">Modification du profil désactivée par un administrateur.</p><button class="btn p" type="button" disabled title="Vous n’avez pas l’autorisation de modifier vos informations personnelles">Enregistrer le profil</button>` : `<button class="btn p" type="submit">Enregistrer le profil</button>`}</form></div>
<div class="glass sec"><h1>Mot de passe</h1>${pw}</div>`, accountScript(me), me.theme));
}
/* ---------- Réglages du site (KV « settings:brand ») ---------- */
const ACCENTS = {
  ocean: ["#22d3ee", "#4f8cff", "#8b5cf6"], sunset: ["#fbbf24", "#f97316", "#ec4899"],
  forest: ["#a3e635", "#22c55e", "#14b8a6"], rose: ["#f472b6", "#e11d48", "#a855f7"], slate: ["#94a3b8", "#64748b", "#475569"]
};
const RADII = { soft: 32, std: 24, square: 10 };
const HEX = /^#[0-9a-f]{6}$/i;
const DEFAULT_SITE = {
  name: "Redirections Cloudflare", subtitle: "Homelab de Bertrand", logo: "",
  homeTitle: "Page de gestion des redirections",
  homeText: "Cette page sert uniquement à gérer des redirections Cloudflare. Il n’y a rien d’autre à voir ici.",
  homePublicNote: "Les liens publics restent accessibles sans connexion. La connexion n’est nécessaire que pour gérer le site.",
  footerOn: true, footer: "Fait avec amour par Bertrand sur son Thinkpad préféré ❤️",
  accent: "ocean", colors: ACCENTS.ocean, radius: "std", shine: true
};

// Nettoie le HTML envoyé par l’éditeur : seuls <b> <i> <u> <br> et <a href="http(s)://…"> survivent, tout le reste devient du texte échappé.
function cleanRich(input, max = 300) {
  const src = String(input || "").slice(0, 8000);
  const dec = t => t.replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0*39;/g, "'").replace(/&amp;/g, "&");
  const MAP = { b: "b", strong: "b", i: "i", em: "i", u: "u" };
  const re = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>|([^<]+)|</g;
  const stack = []; let out = "", len = 0, brs = 0, m;
  const lineBreak = () => { if (out && !out.endsWith("<br>") && brs < 3) { out += "<br>"; brs++; } };
  while (len < max && (m = re.exec(src))) {
    if (m[4] !== undefined) {
      let t = dec(m[4]).replace(/[\u0000-\u001f\u007f\u00a0]/g, " ").replace(/ {2,}/g, " ");
      if (!out) t = t.trimStart();
      t = t.slice(0, max - len); len += t.length; out += esc(t);
    } else if (m[2]) {
      const tag = m[2].toLowerCase(), close = m[1] === "/";
      if (tag === "br") lineBreak();
      else if ((tag === "div" || tag === "p") && !close) lineBreak();
      else if (MAP[tag]) {
        const t = MAP[tag];
        if (!close) { stack.push(t); out += `<${t}>`; }
        else { const i = stack.lastIndexOf(t); if (i >= 0) while (stack.length > i) { const x = stack.pop(); if (x !== "-a") out += `</${x}>`; } }
      } else if (tag === "a") {
        if (!close) {
          const hm = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(m[3]);
          const href = hm ? dec(hm[1] ?? hm[2]).trim() : "";
          if (!stack.includes("a") && href.length <= 300 && /^(https?:\/\/|\/(?!\/))\S+$/i.test(href)) { out += `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">`; stack.push("a"); }
          else stack.push("-a");
        } else {
          for (let i = stack.length - 1; i >= 0; i--) if (stack[i] === "a" || stack[i] === "-a") { while (stack.length > i) { const x = stack.pop(); if (x !== "-a") out += `</${x}>`; } break; }
        }
      }
    }
  }
  while (stack.length) { const x = stack.pop(); if (x !== "-a") out += `</${x}>`; }
  out = out.replace(/(<br>)+$/, "");
  return len ? out : "";
}

// Nettoyeur dédié au contenu public des pages texte. Aucun attribut arbitraire ne survit.
function cleanRichContent(input, max = 28000) {
  let src = String(input || "").slice(0, max * 2);
  src = src.replace(/<(script|style|iframe|object|svg|math)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, "");
  const decode = t => t.replace(/&nbsp;/gi, " ").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"').replace(/&#0*39;/gi, "'").replace(/&#(\d+);/g, (_, n) => { const c = Number(n); return c > 0 && c <= 0x10ffff ? String.fromCodePoint(c) : ""; }).replace(/&amp;/gi, "&");
  const allowed = new Set(["p","div","br","h1","h2","h3","h4","blockquote","ul","ol","li","b","strong","i","em","u","s","strike","sub","sup","code","pre","hr","a","span","img","font","table","thead","tbody","tfoot","tr","td","th","caption"]);
  const voids = new Set(["br","hr","img"]), stack = []; let out = "", used = 0, m;
  const re = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>|([^<]+)|</g;
  const popTo = name => { const i = stack.lastIndexOf(name); if (i >= 0) while (stack.length > i) { const x = stack.pop(); out += `</${x}>`; } };
  while (used < max && (m = re.exec(src))) {
    if (m[4] !== undefined) {
      const t = decode(m[4]).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").slice(0, max - used);
      used += t.length; out += esc(t); continue;
    }
    if (!m[2]) { out += "&lt;"; continue; }
    const tag = m[2].toLowerCase(), closing = m[1] === "/", attrs = m[3] || "";
    if (["script","style","iframe","object","svg","math"].includes(tag) || !allowed.has(tag)) continue;
    if (closing) { if (tag === "font") popTo("span"); else if (!voids.has(tag)) popTo(tag); continue; }
    if (tag === "font") {
      const cm = /\bcolor\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
      const zm = /\bsize\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
      const rawColor = cm ? String(cm[1] ?? cm[2] ?? cm[3] ?? "") : "";
      const sizeValue = zm ? String(zm[1] ?? zm[2] ?? zm[3] ?? "") : "";
      const sizes = {"1":"11px","2":"13px","3":"16px","4":"18px","5":"24px","6":"32px","7":"40px"};
      const styles = [];
      if (/^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(rawColor)) styles.push("color:" + rawColor);
      if (sizes[sizeValue]) styles.push("font-size:" + sizes[sizeValue]);
      out += styles.length ? `<span style="${esc(styles.join(";"))}">` : "<span>"; stack.push("span"); continue;
    }
    if (tag === "img") {
      const sm = /\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
      const am = /\balt\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
      const srcValue = sm ? decode(sm[1] ?? sm[2] ?? sm[3] ?? "").trim() : "";
      const altValue = am ? decode(am[1] ?? am[2] ?? am[3] ?? "").trim().slice(0,300) : "";
      if (/^https:\/\/[^\s]+$/i.test(srcValue) && srcValue.length <= 1800) out += `<img src="${esc(srcValue)}" alt="${esc(altValue)}" loading="lazy" referrerpolicy="no-referrer">`;
      continue;
    }
    if (voids.has(tag)) { out += `<${tag}>`; continue; }
    if (tag === "a") {
      const hm = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
      const href = hm ? decode(hm[1] ?? hm[2] ?? hm[3] ?? "").trim() : "";
      if (/^https:\/\/[^\s]+$/i.test(href) && href.length <= 1200 && !stack.includes("a")) { out += `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">`; stack.push("a"); }
      continue;
    }
    if (tag === "span") {
      const sm = /\bstyle\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(attrs); const rawStyle = sm ? (sm[1] ?? sm[2] ?? "") : ""; const clean = [];
      for (const part of rawStyle.split(";")) { const ix = part.indexOf(":"); if (ix < 0) continue; const k = part.slice(0, ix).trim().toLowerCase(), v = part.slice(ix + 1).trim();
        if ((k === "color" || k === "background-color") && /^(?:#[0-9a-f]{3}(?:[0-9a-f]{3})?|rgb\(\s*(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\s*,\s*(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\s*,\s*(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\s*\))$/i.test(v)) clean.push(`${k}:${v}`);
        if (k === "font-size" && /^(?:[1-4]?[0-9](?:\.[0-9]+)?px|(?:0\.[8-9]|[1-2](?:\.[0-9]+)?)em)$/i.test(v)) clean.push(`${k}:${v}`);
        if (k === "text-align" && /^(left|right|center|justify)$/i.test(v)) clean.push(`${k}:${v.toLowerCase()}`);
      }
      out += clean.length ? `<span style="${esc(clean.join(";"))}">` : "<span>"; stack.push("span"); continue;
    }
    if (["p","div","h1","h2","h3","h4","blockquote","li","td","th","caption"].includes(tag)) {
      const sm = /\bstyle\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(attrs); const rawStyle = sm ? (sm[1] ?? sm[2] ?? "") : "";
      const am = /\btext-align\s*:\s*(left|right|center|justify)\b/i.exec(rawStyle); const align = am ? am[1].toLowerCase() : "";
      out += `<${tag}${align ? ` style="text-align:${align}"` : ""}>`; stack.push(tag); continue;
    }
    out += `<${tag}>`; stack.push(tag);
  }
  while (stack.length) out += `</${stack.pop()}>`;
  return out.slice(0, max * 3);
}
function richTextOnly(html) { return String(html || "").replace(/<[^>]*>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"').replace(/&#0*39;/gi, "'").replace(/\s+/g, " ").trim(); }

function normSite(r) {
  r = r && typeof r === "object" ? r : {};
  const d = DEFAULT_SITE, s = {};
  s.name = cleanText(r.name, 60) || d.name;
  s.subtitle = typeof r.subtitle === "string" ? cleanText(r.subtitle, 100) : d.subtitle;
  const logo = String(r.logo || "").trim();
  s.logo = /^https:\/\/\S+$/i.test(logo) && logo.length <= 500 ? logo : "";
  s.homeTitle = cleanText(r.homeTitle, 100) || d.homeTitle;
  s.homeText = typeof r.homeText === "string" ? cleanRichContent(r.homeText, 9000) : d.homeText;
  s.homePublicNote = typeof r.homePublicNote === "string" ? cleanRichContent(r.homePublicNote, 3000) : d.homePublicNote;
  s.footerOn = r.footerOn !== false;
  s.footer = typeof r.footer === "string" ? cleanRichContent(r.footer, 1200) : d.footer;
  s.accent = r.accent === "custom" || ACCENTS[r.accent] ? r.accent : "ocean";
  s.colors = s.accent === "custom" ? (Array.isArray(r.colors) && r.colors.length === 3 && r.colors.every(c => HEX.test(String(c))) ? r.colors.map(c => String(c).toLowerCase()) : [...ACCENTS.ocean]) : [...ACCENTS[s.accent]];
  s.radius = RADII[r.radius] ? r.radius : "std";
  s.shine = r.shine !== false;
  return s;
}
async function loadSite(env) {
  try { return normSite(env.LINKS ? await env.LINKS.get("settings:brand", "json") : null); } catch { return normSite(null); }
}
const siteTitle = s => s.subtitle ? `${s.name} - ${s.subtitle}` : s.name;
function brandHtml(s) {
  const mark = s.logo ? `<span class="mark logo"><img src="${esc(s.logo)}" alt="" referrerpolicy="no-referrer"></span>` : BRAND_MARK;
  return `<a class="brand" href="/" aria-label="Accueil : ${esc(siteTitle(s))}">${mark}<span class="bt"><span class="t1">${esc(s.name)}</span>${s.subtitle ? `<span class="t2">${esc(s.subtitle)}</span>` : ""}</span></a>`;
}
function siteTheme(s) {
  const c = s.colors, css = [];
  if (s.accent !== "ocean") css.push(`:root,html[data-theme]{--g:linear-gradient(135deg,${c[0]},${c[1]} 50%,${c[2]})}`);
  if (s.radius !== "std") css.push(`.glass{border-radius:${RADII[s.radius]}px}`);
  if (!s.shine) css.push(".t1{animation:none}");
  return css.join("");
}
function applySite(html, s) {
  html = html.split(esc(TITLE)).join(esc(siteTitle(s)));
  if (s.logo) html = html.split(ICON).join(esc(s.logo));
  return html
    .split("<!--@brand-->").join(brandHtml(s))
    .split("<!--@footer-->").join(s.footerOn && s.footer ? `<p class="foot">${s.footer}</p>` : "")
    .split("/*@theme*/").join(siteTheme(s))
    .split("<!--@hometitle-->").join(esc(s.homeTitle))
    .split("<!--@hometext-->").join(s.homeText)
    .split("<!--@homepublicnote-->").join(s.homePublicNote);
}

/* ---------- Page « Personnalisation » ---------- */
function editorHtml(id, label, ph, extra = "") {
  return `<div class="rte" id="${id}Box"><div class="rtebar" role="toolbar" aria-label="Mise en forme : ${label}">
<select data-block title="Style de paragraphe" aria-label="Style de paragraphe"><option value="p">Paragraphe</option><option value="h1">Titre 1</option><option value="h2">Titre 2</option><option value="h3">Titre 3</option><option value="h4">Titre 4</option><option value="blockquote">Citation</option><option value="pre">Code préformaté</option></select><select data-font-size title="Taille du texte" aria-label="Taille du texte"><option value="2">Petit</option><option value="3" selected>Normal</option><option value="4">Grand</option><option value="5">Très grand</option><option value="6">Géant</option></select><span class="sep" aria-hidden="true"></span>
<button type="button" data-cmd="bold" title="Gras (Ctrl+B)" aria-label="Gras"><b>B</b></button><button type="button" data-cmd="italic" title="Italique (Ctrl+I)" aria-label="Italique"><i>I</i></button><button type="button" data-cmd="underline" title="Souligné (Ctrl+U)" aria-label="Souligné"><u>U</u></button><button type="button" data-cmd="strikeThrough" title="Barré" aria-label="Barré"><s>S</s></button><button type="button" data-cmd="superscript" title="Exposant" aria-label="Exposant">x²</button><button type="button" data-cmd="subscript" title="Indice" aria-label="Indice">x₂</button><span class="sep" aria-hidden="true"></span>
<button type="button" data-cmd="insertUnorderedList" title="Liste à puces" aria-label="Liste à puces">• Liste</button><button type="button" data-cmd="insertOrderedList" title="Liste numérotée" aria-label="Liste numérotée">1. Liste</button><button type="button" data-cmd="outdent" title="Réduire le retrait" aria-label="Réduire le retrait">⇤</button><button type="button" data-cmd="indent" title="Augmenter le retrait" aria-label="Augmenter le retrait">⇥</button><span class="sep" aria-hidden="true"></span>
<button type="button" data-cmd="justifyLeft" title="Aligner à gauche" aria-label="Aligner à gauche">⇤</button><button type="button" data-cmd="justifyCenter" title="Centrer" aria-label="Centrer">≡</button><button type="button" data-cmd="justifyRight" title="Aligner à droite" aria-label="Aligner à droite">⇥</button><button type="button" data-cmd="justifyFull" title="Justifier" aria-label="Justifier">☷</button><span class="sep" aria-hidden="true"></span>
<label class="rte-color" title="Couleur du texte">A <input type="color" data-color-cmd="foreColor" value="#243247" aria-label="Couleur du texte"></label><label class="rte-color" title="Surlignage">▰ <input type="color" data-color-cmd="hiliteColor" value="#fff19a" aria-label="Couleur de surlignage"></label><span class="sep" aria-hidden="true"></span>
<button type="button" data-act="link" title="Insérer un lien HTTPS" aria-label="Insérer un lien">Lien</button><button type="button" data-act="unlink" title="Retirer le lien" aria-label="Retirer le lien">Sans lien</button><button type="button" data-act="image" title="Insérer une image HTTPS" aria-label="Insérer une image">Image</button><button type="button" data-act="table" title="Insérer un tableau" aria-label="Insérer un tableau">Tableau</button><button type="button" data-cmd="insertHorizontalRule" title="Séparateur horizontal" aria-label="Séparateur horizontal">―</button><span class="sep" aria-hidden="true"></span>
<button type="button" data-cmd="undo" title="Annuler" aria-label="Annuler">↶</button><button type="button" data-cmd="redo" title="Rétablir" aria-label="Rétablir">↷</button><button type="button" data-act="emoji" title="Insérer un emoji" aria-label="Insérer un emoji">😊</button><button type="button" data-act="clear" title="Effacer la mise en forme" aria-label="Effacer la mise en forme">Effacer</button></div>
<div class="rtelink" hidden><input type="url" inputmode="url" placeholder="https://…" aria-label="Adresse HTTPS du lien" autocomplete="off" spellcheck="false"><button class="btn sm" type="button" data-act="linkok">Appliquer</button></div>
<div class="emojis" hidden></div>
<div class="rtebody ${extra}" id="${id}" contenteditable="true" role="textbox" aria-multiline="true" aria-label="${label}" data-ph="${ph}" spellcheck="true"></div>
<div class="rtefoot"><span id="${id}Count" aria-live="polite"></span><button class="btn sm" type="button" data-act="reset">Texte d’origine</button></div></div>`;
}
const SETTINGS_JS = COMMON_JS + String.raw`
const root=$('#site'),S=JSON.parse(root.dataset.site),DEF=JSON.parse(root.dataset.def),ACC=JSON.parse(root.dataset.acc);
const LABELS={ocean:'Océan',sunset:'Coucher de soleil',forest:'Forêt',rose:'Rose',slate:'Ardoise',custom:'Personnalisé'};
const RAD={soft:32,std:24,square:10},RADL={soft:'Très arrondi',std:'Standard',square:'Sobre'};
const EMOJIS=['❤️','😊','☕','🚀','✨','🏠','💻','🌍','🔒','🎉','👋','🛠️','🐧','⭐'];
const st={accent:S.accent,colors:S.colors.slice(),radius:S.radius};
const grad=c=>'linear-gradient(135deg,'+c[0]+','+c[1]+' 50%,'+c[2]+')';
const cur=()=>st.accent==='custom'?st.colors:ACC[st.accent];
const msg=$('#se');let edHome=null,edPublicNote=null,edFoot=null,lastLogo=null;
function say(t,ok){msg.className=ok?'okmsg':'err';msg.textContent=t;}
function preview(){
 const pv=$('#pv');pv.style.setProperty('--g',grad(cur()));pv.style.borderRadius=RAD[st.radius]+'px';
 $('#pvT1').textContent=$('#name').value.trim()||DEF.name;$('#pvT1').style.animation=$('#shine').checked?'':'none';
 const pht=$('#pvHomeTitle'),ph=$('#pvHomeText'),pn=$('#pvPublicNote');if(pht)pht.textContent=$('#homeTitle')?.value||DEF.homeTitle;if(ph&&edHome)ph.innerHTML=edHome.get();if(pn&&edPublicNote)pn.innerHTML=edPublicNote.get();
 const sub=$('#subtitle').value.trim(),t2=$('#pvT2');t2.textContent=sub;t2.hidden=!sub;
 const mark=$('#pvMark'),url=$('#logo').value.trim();
 if(url!==lastLogo){lastLogo=url;const dm=()=>{mark.className='mark';mark.innerHTML=$('#defMark').innerHTML;};
  if(/^https:\/\/\S+$/i.test(url)){mark.className='mark logo';mark.textContent='';const im=el('img');im.alt='';im.referrerPolicy='no-referrer';im.onerror=dm;im.src=url;mark.appendChild(im);}else dm();}
 const f=$('#pvFoot');f.hidden=!$('#footerOn').checked;if(edFoot)f.innerHTML=edFoot.get();
}
function editor(id,max,html){
 const box=$('#'+id+'Box'),body=$('#'+id),linkRow=box.querySelector('.rtelink'),linkIn=linkRow.querySelector('input'),emo=box.querySelector('.emojis'),cnt=$('#'+id+'Count');
 let saved=null;body.innerHTML=html||'';
 EMOJIS.concat(['✅','❌','📌','📅','📣','💡','🔗','📄','🎨','🌟','🚩','➡️','⬅️','⬆️','⬇️']).forEach(e=>{const b=el('button','',e);b.type='button';b.dataset.emo=e;b.title='Insérer '+e;b.setAttribute('aria-label','Insérer '+e);emo.appendChild(b);});
 const len=()=>body.textContent.length;
 const upd=()=>{const n=len();cnt.textContent=n.toLocaleString('fr-FR')+' / '+max.toLocaleString('fr-FR')+' caractères';cnt.style.color=n>max?'var(--danger)':'';preview();};
 const keep=()=>{const sel=getSelection();if(sel&&sel.rangeCount&&body.contains(sel.anchorNode))saved=sel.getRangeAt(0).cloneRange();};
 const restore=()=>{body.focus();if(saved){try{const sel=getSelection();sel.removeAllRanges();sel.addRange(saved);}catch{}}};
 box.addEventListener('mousedown',e=>{if(e.target.closest('button'))e.preventDefault();});
 ['keyup','mouseup','blur'].forEach(n=>body.addEventListener(n,keep));
 body.addEventListener('input',()=>{keep();upd();});
 // Keep pasted formatting, but remove executable tags, unsafe URLs and arbitrary attributes before insertion.
 function cleanPaste(markup){
   const doc=new DOMParser().parseFromString(String(markup||''),'text/html');
   doc.querySelectorAll('script,style,iframe,object,embed,svg,math,form,input,button,video,audio,link,meta').forEach(n=>n.remove());
   const safeTags=new Set(['p','div','br','h1','h2','h3','h4','blockquote','ul','ol','li','b','strong','i','em','u','s','strike','sub','sup','code','pre','hr','a','span','img','table','thead','tbody','tfoot','tr','td','th','caption']);
   [...doc.body.querySelectorAll('*')].forEach(n=>{
     if(!safeTags.has(n.tagName.toLowerCase())){n.replaceWith(...n.childNodes);return;}
     [...n.attributes].forEach(a=>{
       const k=a.name.toLowerCase(),v=a.value.trim();
       if(k==='style'){
         const clean=[];v.split(';').forEach(part=>{const i=part.indexOf(':');if(i<0)return;const prop=part.slice(0,i).trim().toLowerCase(),val=part.slice(i+1).trim();
           if((prop==='color'||prop==='background-color')&&/^(?:#[0-9a-f]{3}(?:[0-9a-f]{3})?|rgb\(\s*(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\s*,\s*(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\s*,\s*(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\s*\))$/i.test(val))clean.push(prop+':'+val);
           if(prop==='font-size'&&/^(?:[1-4]?[0-9](?:\.[0-9]+)?px|(?:0\.[8-9]|[1-2](?:\.[0-9]+)?)em)$/i.test(val))clean.push(prop+':'+val);
           if(prop==='text-align'&&/^(left|right|center|justify)$/i.test(val))clean.push(prop+':'+val);
         });if(clean.length)n.setAttribute('style',clean.join(';'));else n.removeAttribute('style');
       }else if(n.tagName.toLowerCase()==='a'&&k==='href'){
         if(!/^https:\/\/[^\s]+$/i.test(v))n.removeAttribute(k);
       }else if(n.tagName.toLowerCase()==='img'&&(k==='src'||k==='alt')){
         if(k==='src'&&!/^https:\/\/[^\s]+$/i.test(v))n.removeAttribute(k);else if(k==='alt')n.setAttribute('alt',v.slice(0,300));
       }else n.removeAttribute(k);
     });
   });
   return doc.body.innerHTML;
 }
 body.addEventListener('paste',e=>{e.preventDefault();const dt=e.clipboardData||window.clipboardData,ht=dt.getData('text/html'),text=dt.getData('text/plain');restore();
   const html=ht?cleanPaste(ht):String(text||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\r?\n/g,'<br>');
   document.execCommand('insertHTML',false,html);keep();upd();});
 body.addEventListener('beforeinput',e=>{if(e.inputType&&e.inputType.indexOf('insert')===0&&len()>=max&&(!getSelection()||getSelection().isCollapsed))e.preventDefault();});
 function applyLink(){let u=linkIn.value.trim();if(!u)return;if(!/^[a-z][a-z0-9+.-]*:/i.test(u))u='https://'+u;
  if(!/^https:\/\/[^\s]+$/i.test(u)){say('Adresse de lien invalide : veuillez saisir une adresse HTTPS valide.',false);linkIn.focus();return;}
  restore();const sel=getSelection();if(sel.isCollapsed){const safe=u.replace(/&/g,'&amp;').replace(/"/g,'%22').replace(/</g,'%3C').replace(/>/g,'%3E');const label=u.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');document.execCommand('insertHTML',false,'<a href="'+safe+'">'+label+'</a>');}
  else document.execCommand('createLink',false,u);linkIn.value='';linkRow.hidden=true;msg.textContent='';keep();upd();}
 linkIn.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();applyLink();}if(e.key==='Escape'){linkRow.hidden=true;restore();}});
 box.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const cmd=b.dataset.cmd,act=b.dataset.act;
  if(cmd){restore();document.execCommand('styleWithCSS',false,true);document.execCommand(cmd,false,null);keep();upd();}
  else if(b.dataset.emo){restore();document.execCommand('insertText',false,b.dataset.emo);keep();upd();}
  else if(act==='link'){keep();emo.hidden=true;linkRow.hidden=!linkRow.hidden;if(!linkRow.hidden)linkIn.focus();}
  else if(act==='linkok')applyLink();
  else if(act==='unlink'){restore();document.execCommand('unlink',false,null);keep();upd();}
  else if(act==='emoji'){keep();linkRow.hidden=true;emo.hidden=!emo.hidden;}
  else if(act==='image'){const raw=prompt('Adresse HTTPS de l’image :','https://');if(!raw)return;let u=raw.trim();if(!/^https:\/\/[^\s]+$/i.test(u)){say('L’image doit être une adresse HTTPS valide.',false);return;}restore();document.execCommand('insertImage',false,u);keep();upd();}
  else if(act==='table'){const rr=Number(prompt('Nombre de lignes (1 à 10) :','3')),cc=Number(prompt('Nombre de colonnes (1 à 8) :','3'));if(!Number.isInteger(rr)||!Number.isInteger(cc)||rr<1||rr>10||cc<1||cc>8){say('Dimensions du tableau incorrectes.',false);return;}let h='<table><tbody>';for(let r=0;r<rr;r++){h+='<tr>';for(let c=0;c<cc;c++)h+=r===0?'<th>En-tête</th>':'<td>Texte</td>';h+='</tr>';}h+='</tbody></table><p><br></p>';restore();document.execCommand('insertHTML',false,h);keep();upd();}
  else if(act==='clear'){restore();document.execCommand('removeFormat');document.execCommand('unlink');keep();upd();}
  else if(act==='reset'){const defaults={homeText:DEF.homeText,homePublicNote:DEF.homePublicNote,footer:DEF.footer};body.innerHTML=defaults[id]||'';saved=null;upd();}});
 box.querySelectorAll('[data-block]').forEach(sel=>sel.addEventListener('change',()=>{restore();document.execCommand('formatBlock',false,sel.value);keep();upd();}));
 box.querySelectorAll('[data-font-size]').forEach(sel=>sel.addEventListener('change',()=>{restore();document.execCommand('styleWithCSS',false,false);document.execCommand('fontSize',false,sel.value);document.execCommand('styleWithCSS',false,true);keep();upd();}));
 box.querySelectorAll('[data-color-cmd]').forEach(inp=>{inp.addEventListener('pointerdown',keep);inp.addEventListener('focus',keep);inp.addEventListener('input',()=>{restore();document.execCommand('styleWithCSS',false,true);document.execCommand(inp.dataset.colorCmd,false,inp.value);keep();upd();});});
 upd();return{get:()=>body.innerHTML};
}
function drawSw(){const box=$('#swatches');box.textContent='';
 Object.keys(LABELS).forEach(k=>{const b=el('button','sw');b.type='button';b.setAttribute('aria-pressed',String(st.accent===k));
  const i=el('i');i.style.background=grad(k==='custom'?st.colors:ACC[k]);b.append(i,el('span','',LABELS[k]));
  b.onclick=()=>{st.accent=k;$('#colors').hidden=k!=='custom';drawSw();preview();};box.appendChild(b);});}
function drawRad(){const box=$('#radii');box.textContent='';
 Object.keys(RADL).forEach(k=>{const b=el('button','btn sm'+(st.radius===k?' on':''),RADL[k]);b.type='button';b.setAttribute('aria-pressed',String(st.radius===k));
  b.onclick=()=>{st.radius=k;drawRad();preview();};box.appendChild(b);});}
$('#name').value=S.name;$('#subtitle').value=S.subtitle;$('#logo').value=S.logo;$('#homeTitle').value=S.homeTitle;
$('#footerOn').checked=S.footerOn;$('#shine').checked=S.shine;
[0,1,2].forEach(n=>{const c=$('#c'+n);c.value=st.colors[n];c.addEventListener('input',()=>{st.colors[n]=c.value;if(st.accent==='custom'){drawSw();preview();}});});
$('#colors').hidden=st.accent!=='custom';
edHome=editor('homeText',9000,S.homeText);edPublicNote=editor('homePublicNote',3000,S.homePublicNote);edFoot=editor('footer',1200,S.footer);
drawSw();drawRad();preview();
['name','subtitle','logo'].forEach(i=>$('#'+i).addEventListener('input',preview));['shine','footerOn'].forEach(i=>$('#'+i).addEventListener('change',preview));
$('#siteForm').addEventListener('submit',async ev=>{ev.preventDefault();say('',true);const logo=$('#logo'),lv=logo.value.trim();logo.classList.remove('invalid-field','valid-field');if(lv&&!/^https:\/\/\S+$/i.test(lv)){logo.classList.add('invalid-field');logo.focus();say('Lien incorrect : veuillez saisir une adresse commençant par https://.',false);return;}if(lv)logo.classList.add('valid-field');
 try{await api('/admin/api/settings',{method:'POST',body:JSON.stringify({name:$('#name').value,subtitle:$('#subtitle').value,logo:$('#logo').value,accent:st.accent,colors:st.colors,radius:st.radius,shine:$('#shine').checked,homeTitle:$('#homeTitle').value,homeText:edHome.get(),homePublicNote:edPublicNote.get(),footerOn:$('#footerOn').checked,footer:edFoot.get()})});
  say('Personnalisation enregistrée, la page se recharge…',true);setTimeout(()=>location.reload(),700);}catch(x){say(x.message,false);}});
$('#resetAll').addEventListener('click',async()=>{if(!confirm('Rétablir tous les réglages d’origine (nom, couleurs, textes, pied de page) ?'))return;
 try{await api('/admin/api/settings',{method:'POST',body:JSON.stringify({reset:true})});location.reload();}catch(x){say(x.message,false);}});`;

function settingsPage(nonce, me, site) {
  const data = `<div id="site" hidden data-site="${esc(JSON.stringify(site))}" data-def="${esc(JSON.stringify(DEFAULT_SITE))}" data-acc="${esc(JSON.stringify(ACCENTS))}"></div><div id="defMark" hidden>${BRAND_MARK}</div>`;
  const body = `${header(me, "settings")}${data}<form id="siteForm" novalidate>
<section class="glass"><h1>Personnalisation du site</h1><p class="muted">Ces réglages s’appliquent à toutes les pages, publiques comprises. L’aperçu ci-dessous suit vos modifications en direct ; rien n’est publié avant l’enregistrement.</p>
<div class="preview glass" id="pv"><div class="brand"><span class="mark" id="pvMark"></span><span class="bt"><span class="t1" id="pvT1"></span><span class="t2" id="pvT2"></span></span></div><div class="preview-home-sample"><h2 id="pvHomeTitle"></h2><div id="pvHomeText"></div><div class="preview-note" id="pvPublicNote"></div></div><span class="btn p auto" aria-hidden="true">Bouton principal</span><p class="foot" id="pvFoot"></p></div></section>
<section class="glass"><h2 class="sect">Identité</h2><p class="muted">Nom, sous-titre et logo affichés dans l’en-tête et dans le titre de l’onglet.</p>
<label for="name">Nom du site</label><input id="name" maxlength="60" autocomplete="off">
<label for="subtitle">Sous-titre</label><input id="subtitle" maxlength="100" autocomplete="off">
<label for="logo">Logo (adresse HTTPS d’une image) <span class="tip" title="L’adresse doit commencer explicitement par https://. Une adresse incomplète sera signalée avant l’enregistrement." aria-label="Aide sur le logo">i</span></label><input id="logo" type="url" maxlength="500" placeholder="https://exemple.com/logo.png" autocomplete="off" spellcheck="false"><p class="muted hint">Laissez vide pour garder l’icône d’origine. Le logo sert aussi d’icône d’onglet.</p></section>
<section class="glass"><h2 class="sect">Apparence</h2><p class="muted">Couleurs des boutons et des accents, forme des cartes, animation du titre.</p>
<label>Couleur d’accent</label><div class="swatches" id="swatches"></div>
<div class="colors" id="colors" hidden><div><label for="c0">Début</label><input type="color" id="c0"></div><div><label for="c1">Milieu</label><input type="color" id="c1"></div><div><label for="c2">Fin</label><input type="color" id="c2"></div></div>
<label>Arrondi des cartes</label><div class="seg" id="radii"></div>
<label class="ck"><input type="checkbox" id="shine"><span>Animer le titre du site<small>Reflet lumineux qui parcourt le nom dans l’en-tête. Désactivé automatiquement si le système demande moins d’animations.</small></span></label></section>
<section class="glass"><h2 class="sect">Page d’accueil publique</h2><p class="muted">Ce que voit une personne qui ouvre l’adresse du site sans lien de redirection.</p>
<label for="homeTitle">Titre</label><input id="homeTitle" maxlength="100" autocomplete="off">
<label for="homeText">Texte principal</label><p class="muted hint">Le contenu peut inclure des titres, listes, tableaux, liens, images HTTPS, couleurs et alignements.</p>${editorHtml("homeText", "Texte principal de la page d’accueil", "Écris le texte d’accueil…", "muted")}
<label for="homePublicNote">Message public sous le texte principal</label><p class="muted hint">Ce message apparaît sur la page d’accueil lorsque la personne n’est pas connectée. Tu peux modifier ou retirer entièrement le texte par défaut.</p>${editorHtml("homePublicNote", "Message public de la page d’accueil", "Écris le message visible sans connexion…", "muted")}</section>
<section class="glass"><h2 class="sect">Pied de page</h2><p class="muted">La ligne tout en bas de chaque page. L’éditeur prend en charge la mise en forme, les titres, les listes, les liens HTTPS, les images, les tableaux, les couleurs et les emojis.</p>
<label class="ck"><input type="checkbox" id="footerOn"><span>Afficher le pied de page</span></label>
<label for="footer">Texte</label>${editorHtml("footer", "Texte du pied de page", "Écrivez votre texte…", "center")}</section>
<section class="glass"><div class="err" id="se" role="status"></div><div class="two"><button class="btn d" id="resetAll" type="button">Tout rétablir</button><button class="btn p" type="submit">Enregistrer</button></div></section></form>`;
  return htmlRes(nonce, shell(nonce, pageTitle("settings"), body, SETTINGS_JS, me.theme));
}

function embeddedPage(target, info = {}) {
  const nonce = newNonce();
  const details = `${info.showBy === false ? "" : (info.by ? `<span>Créateur : <strong>${esc(info.byFormat === "username" ? (info.by || "") : (info.byName || info.by))}</strong></span>` : "")}${info.showFrom === false ? "" : (info.from ? `<span>Début : ${esc(fmtDate(info.from))}</span>` : "")}${info.showUntil === false ? "" : (info.until ? `<span>Expiration : ${esc(fmtDate(info.until))}</span>` : "")}`;
  const body = `<header>${BRAND}<div class="right">${THEME_SWITCH(false)}${info.showNewTab === true ? `<a class="btn sm" href="${esc(target)}" target="_blank" rel="noopener noreferrer">Ouvrir dans un nouvel onglet</a>` : ''}</div></header><div class="glass embed-info"><div><h1>Site intégré</h1><p class="muted">Le site est affiché dans cette page. Si rien ne s’affiche, il est peut-être interdit d’intégration par son propriétaire.</p></div><div class="embed-details">${details}</div></div><div class="embed-frame-wrap"><iframe class="embed-frame" src="${esc(target)}" title="Site de destination intégré" referrerpolicy="no-referrer" allow="fullscreen; clipboard-read; clipboard-write" allowfullscreen></iframe></div>`;
  const extraCss = `.wrap{max-width:none;width:100%;padding:18px 20px}.embed-info{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:14px}.embed-info h1{margin:0 0 4px}.embed-info p{margin:0}.embed-details{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:.9rem}.embed-frame-wrap{height:calc(100vh - 190px);min-height:420px;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;background:var(--card);box-shadow:var(--shadow)}.embed-frame{display:block;width:100%;height:100%;border:0;background:white}@media(max-width:700px){.wrap{padding:10px}.embed-frame-wrap{height:calc(100vh - 230px);min-height:360px}.embed-info .right{width:100%;flex-wrap:wrap}}`;
  const html = shell(nonce, TITLE, body, SESSION_JS, "light").replace("</style>", `${extraCss}</style>`);
  return htmlRes(nonce, html);
}

function confirmPage(target, info = {}) {
  if (info.integration === true) return embeddedPage(target, info);
  const nonce = newNonce();
  const js = SESSION_JS + `const t=${JSON.stringify(target).replace(/</g, "\\u003c")};let n=10;
const c=document.getElementById('c'),m=document.getElementById('m'),bar=document.getElementById('progress'),start=Date.now(),duration=10000;
const iv=setInterval(()=>{const elapsed=Date.now()-start,remaining=Math.max(0,duration-elapsed);n=Math.ceil(remaining/1000);c.textContent=n;bar.style.width=(remaining/duration*100)+'%';bar.parentElement.setAttribute('aria-valuenow',String(Math.round(remaining/duration*100)));if(remaining<=0){clearInterval(iv);location.href=t;}},100);
document.getElementById('go').onclick=()=>{clearInterval(iv);location.href=t;};
const nt=document.getElementById('newTab');if(nt)nt.onclick=()=>{const w=window.open(t,'_blank');if(w){w.opener=null;clearInterval(iv);m.textContent='La destination a été ouverte dans un nouvel onglet.';bar.parentElement.remove();document.getElementById('newTabWrap')?.remove();}else{m.textContent='Le navigateur a bloqué l’ouverture du nouvel onglet. Autorisez les fenêtres contextuelles pour ce site.';}};
document.getElementById('no').onclick=()=>{clearInterval(iv);document.querySelector('.bar').remove();document.querySelector('.two').remove();m.textContent='Redirection annulée. Vous pouvez fermer cet onglet.';};`;
  const details = `${info.showBy === false ? "" : (info.by ? `<p class="muted">Créateur : <strong>${esc(info.byFormat === "username" ? (info.by || "") : (info.byName || info.by))}</strong></p>` : "")}${info.showFrom === false ? "" : (info.from ? `<p class="muted">Début : ${esc(fmtDate(info.from))}</p>` : "")}${info.showUntil === false ? "" : (info.until ? `<p class="muted">Expiration : ${esc(fmtDate(info.until))}</p>` : "")}`;
  const body = `<header>${BRAND}<div class="right">${THEME_SWITCH(false)}</div></header><div class="glass"><h1>${info.name ? esc(info.name) : "Redirection"}</h1>${details}<p class="muted" id="m">Souhaitez-vous vraiment être redirigé vers cette adresse ? Sans réponse, la redirection aura lieu dans <span class="cd" id="c">10</span> secondes.</p><label>Destination</label><p class="dest">${esc(target)}</p><div class="bar" role="progressbar" aria-label="Temps restant avant la redirection" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100"><i id="progress"></i></div><div class="two"><button class="btn" id="no" type="button">Annuler</button><button class="btn p" id="go" type="button">Continuer</button></div>${info.showNewTab === true ? '<div id="newTabWrap" style="margin-top:12px"><button class="btn" id="newTab" type="button">Ouvrir dans un nouvel onglet</button></div>' : ''}</div>`;
  return htmlRes(nonce, shell(nonce, TITLE, body, js).replace("<head>", `<head><noscript><meta http-equiv="refresh" content="10;url=${esc(target)}"></noscript>`));
}

/* ---------- Administration ---------- */
async function failCount(req, env) { const rk = "rl:" + (req.headers.get("CF-Connecting-IP") || "x"); return { rk, tries: Number(await env.LINKS.get(rk)) || 0 }; }

async function login(req, env) {
  const { rk, tries } = await failCount(req, env);
  if (tries >= 5) return json({ error: "Trop de tentatives. Veuillez réessayer dans 15 minutes." }, 429);
  let b = {}; try { b = await req.json(); } catch {}
  const name = String(b.username || "").trim().toLowerCase().slice(0, 40), pw = String(b.password || "").slice(0, 200);
  let ok = false;
  if (name === ownerName(env)) {
    ok = safeEq(await hmac(env.SESSION_SECRET, "pw:" + pw), await hmac(env.SESSION_SECRET, "pw:" + env.ADMIN_PASSWORD));
  } else {
    const rec = USER.test(name) ? await env.LINKS.get("u:" + name, "json") : null;
    const h = await pbkdf2(pw, rec?.salt || "00".repeat(16));
    ok = !!rec && rec.active !== false && (!(rec.from && Date.now() < rec.from)) && (!(rec.until && Date.now() > rec.until)) && safeEq(h, rec.hash || "");
  }
  if (!ok) { await env.LINKS.put(rk, String(tries + 1), { expirationTtl: 900 }); return json({ error: "Identifiant ou mot de passe incorrect." }, 401); }
  await env.LINKS.delete(rk);
  const userRec = name === ownerName(env) ? null : await env.LINKS.get("u:" + name, "json");
  return json({ ok: true, mustChange: !!userRec?.forcePwChange }, 200, { "set-cookie": `hl_session=${await makeSession(env, name)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800` });
}

const userMeta = rec => ({ perms: compactPerms(normPerms(rec)), groupId: rec.groupId || "", first: rec.first || "", last: rec.last || "", tags: readTags(rec.tags), active: rec.active !== false, created: rec.created || "", by: rec.by || "", from: rec.from || null, until: rec.until || null, forcePwChange: !!rec.forcePwChange });

function analyticsPage(nonce, me) {
  const body = `<section class="glass dashhero"><div class="eyebrow">Statistiques simplifiées</div><h1>Clics sur les redirections</h1><p class="muted">Un compteur par lien, sans journalisation des IP, pays, navigateurs ou requêtes.</p></section><section class="glass"><div class="head"><div><h2>Fréquentation des liens</h2><p class="muted">Nombre de visites comptabilisées pour chaque redirection.</p></div><button class="btn p" id="refresh">↻ Actualiser</button></div><div id="error" class="err" role="alert"></div><div class="tablewrap"><table class="analytics-table"><thead><tr><th>Lien</th><th>Nombre de visites</th></tr></thead><tbody id="rows"><tr><td colspan="2">Chargement…</td></tr></tbody></table></div></section>`;
  const script = COMMON_JS + `
async function load(){const rows=document.getElementById('rows'),err=document.getElementById('error');try{const d=await api('/admin/api/analytics');rows.innerHTML='';const links=d.links||[];if(!links.length){rows.innerHTML='<tr><td colspan="2">Aucune visite enregistrée pour le moment.</td></tr>';return;}links.sort((a,b)=>b.clicks-a.clicks).forEach(x=>{const tr=document.createElement('tr'),a=document.createElement('td'),b=document.createElement('td');a.textContent='/'+x.slug;b.textContent=Number(x.clicks||0).toLocaleString('fr-FR');tr.append(a,b);rows.append(tr);});}catch(e){err.textContent=e.message||'Impossible de charger les compteurs.';}}
document.getElementById('refresh').addEventListener('click',load);load();`;
  return htmlRes(nonce, shell(nonce, pageTitle("analytics"), `${header(me,"analytics")}${body}`, script, me.theme));
}

async function admin(req, env, url) {
  const nonce = newNonce();
  const missing = ["LINKS", "ADMIN_PASSWORD", "SESSION_SECRET"].filter(k => !env[k]);
  if (missing.length) return htmlRes(nonce, shell(nonce, TITLE, `<header>${BRAND}</header><div class="glass"><h1>Configuration à terminer</h1><p class="muted">Éléments manquants dans Cloudflare : <strong>${missing.join(", ")}</strong>. Ajoute-les dans les réglages du projet, puis redéploie.</p></div>`), 503);
  const p = url.pathname.replace(/\/$/, "");
  const write = req.method !== "GET" && req.method !== "HEAD";
  if (write && req.headers.get("Origin") !== url.origin) return json({ error: "Origine refusée." }, 403);
  const isPage = !write && (p === "/admin" || p === "/admin/dashboard" || p === "/admin/users" || p === "/admin/account" || p === "/admin/settings" || p === "/admin/analytics" || p === "/admin/groups" || p === "/admin/red/new");
  const me = await getSession(req, env, isPage);

  if (isPage) {
    if (!me) return new Response(null, { status: 302, headers: { Location: "/#login", "Cache-Control": "no-store" } });
    if (me.forcePwChange && p !== "/admin/account") return new Response(null, { status: 302, headers: { Location: "/admin/account?force=1", "Cache-Control": "no-store" } });
    if (p === "/admin/users") return me.perms.usersView ? usersPage(nonce, me) : new Response(null, { status: 302, headers: { Location: "/admin/dashboard", "Cache-Control": "no-store" } });
    if (p === "/admin/account") return accountPage(nonce, me);
    if (p === "/admin/red/new") return me.perms.create ? newRedirPage(nonce, me) : new Response(null, { status: 302, headers: { Location: "/admin", "Cache-Control": "no-store" } });
    if (p === "/admin/settings") return me.owner ? settingsPage(nonce, me, await loadSite(env)) : new Response(null, { status: 302, headers: { Location: "/admin/dashboard", "Cache-Control": "no-store" } });
    if (p === "/admin/analytics") return (me.owner || me.perms.analyticsView) ? analyticsPage(nonce, me) : new Response(null, { status: 302, headers: { Location: "/admin/dashboard", "Cache-Control": "no-store" } });
    if (p === "/admin/groups") return (me.owner || me.perms.groupsManage) ? groupsPage(nonce, me) : new Response(null, { status: 302, headers: { Location: "/admin/dashboard", "Cache-Control": "no-store" } });
    if (p === "/admin/dashboard") return dashboardPage(nonce, me);
    return redirPage(nonce, me);
  }
  if (p === "/admin/login" && req.method === "POST") return login(req, env);
  if (p === "/admin/logout" && req.method === "POST") return json({ ok: true }, 200, { "set-cookie": "hl_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0" });
  if (!me) return json({ error: "Non connecté." }, 401);

  const P = me.perms;
  if (p === "/admin/api/analytics" && req.method === "GET") {
    if (!(P.super || P.analyticsView)) return json({ error: "Vous n’êtes pas autorisé à consulter le centre d’analyse." }, 403);
    const listed = await env.LINKS.list({ prefix: "click:", limit: 1000 });
    const links = [];
    for (const key of (listed.keys || [])) {
      const slug = key.name.slice(6);
      const clicks = Number(await env.LINKS.get(key.name) || 0);
      links.push({ slug, clicks: Number.isFinite(clicks) ? clicks : 0 });
    }
    return json({ links, truncated: !listed.list_complete });
  }
  const own = m => !!m?.by && m.by === me.username;
  const canEdit = m => P.super || P.editAll || (P.editOwn && own(m));
  const canDel = m => P.super || P.delAll || (P.delOwn && own(m));

  /* Modèles de groupes de droits */
  if (p === "/admin/api/groups" && req.method === "GET") {
    return json({ groups: await listGroups(env) });
  }
  if (p === "/admin/api/groups" && req.method === "POST") {
    if (!(P.super || P.groupsManage)) return json({ error: "Vous n’êtes pas autorisé à gérer les groupes de droits." }, 403);
    let b; try { b = await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
    const id = String(b.id || "").trim().toLowerCase(), name = cleanText(b.name, 60), description = cleanText(b.description, 240);
    if (!GROUP_ID.test(id) || BUILTIN_GROUPS.some(g => g.id === id)) return json({ error: "Identifiant de groupe invalide ou réservé." }, 400);
    if (!name) return json({ error: "Le nom du groupe est obligatoire." }, 400);
    const groups = await listGroups(env);
    if (groups.some(g => g.id === id)) return json({ error: "Cet identifiant de groupe existe déjà." }, 409);
    if (groups.some(g => g.name.toLocaleLowerCase("fr") === name.toLocaleLowerCase("fr"))) return json({ error: "Un groupe porte déjà ce nom." }, 409);
    const perms = readPerms({ perms: b.perms || {} });
    if (perms.super) return json({ error: "Un groupe personnalisé ne peut pas accorder le statut Super-Admin." }, 400);
    if (!within(perms, P)) return json({ error: "Le groupe ne peut pas accorder des droits que vous ne possédez pas." }, 403);
    const now = new Date().toISOString();
    const rec = { id, name, description, perms: compactPerms(perms), created: now, updated: now, by: me.username };
    await env.LINKS.put("g:" + id, JSON.stringify(rec));
    return json({ ok: true, group: { ...rec, perms } }, 201);
  }
  if (p.startsWith("/admin/api/groups/")) {
    let id; try { id = decodeURIComponent(p.slice("/admin/api/groups/".length)).toLowerCase(); } catch { return json({ error: "Identifiant de groupe invalide." }, 400); }
    if (!GROUP_ID.test(id) || BUILTIN_GROUPS.some(g => g.id === id)) return json({ error: "Les groupes intégrés ne peuvent pas être modifiés ou supprimés." }, 400);
    if (!(P.super || P.groupsManage)) return json({ error: "Vous n’êtes pas autorisé à gérer les groupes de droits." }, 403);
    const rec = await env.LINKS.get("g:" + id, "json");
    if (!rec) return json({ error: "Groupe introuvable." }, 404);
    if (req.method === "DELETE") {
      await env.LINKS.delete("g:" + id);
      return json({ ok: true });
    }
    if (req.method === "PUT") {
      let b; try { b = await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
      const name = cleanText(b.name, 60), description = cleanText(b.description, 240);
      if (!name) return json({ error: "Le nom du groupe est obligatoire." }, 400);
      const groups = await listGroups(env);
      if (groups.some(g => g.id !== id && g.name.toLocaleLowerCase("fr") === name.toLocaleLowerCase("fr"))) return json({ error: "Un groupe porte déjà ce nom." }, 409);
      const perms = readPerms({ perms: b.perms || {} });
      if (perms.super) return json({ error: "Un groupe personnalisé ne peut pas accorder le statut Super-Admin." }, 400);
      if (!within(perms, P)) return json({ error: "Le groupe ne peut pas accorder des droits que vous ne possédez pas." }, 403);
      rec.name = name; rec.description = description; rec.perms = compactPerms(perms); rec.updated = new Date().toISOString(); rec.by = me.username;
      await env.LINKS.put("g:" + id, JSON.stringify(rec));
      return json({ ok: true, group: { ...rec, perms } });
    }
    return json({ error: "Méthode non autorisée." }, 405);
  }

  if (p === "/admin/api/settings" && req.method === "POST") {
    if (!me.owner) return json({error:"Seul le compte principal peut personnaliser le site."},403);
    let b; try { b=await req.json(); } catch { return json({error:"Requête invalide."},400); }
    if (b.reset === true) { await env.LINKS.delete("settings:brand"); return json({ok:true}); }
    const logo=String(b.logo||"").trim();
    if (!cleanText(b.name,60)) return json({error:"Le nom du site est obligatoire."},400);
    if (logo && (!/^https:\/\/\S+$/i.test(logo) || logo.length>500)) return json({error:"Le logo doit être une URL HTTPS valide."},400);
    if (b.accent==="custom" && !(Array.isArray(b.colors) && b.colors.length===3 && b.colors.every(c=>HEX.test(String(c))))) return json({error:"Les couleurs personnalisées sont invalides."},400);
    const site=normSite(b);
    await env.LINKS.put("settings:brand",JSON.stringify(site)); return json({ok:true});
  }

  if (p === "/admin/api/me/profile" && req.method === "POST") {
    let b; try { b=await req.json(); } catch { return json({error:"Requête invalide."},400); }
    const canEditProfile = me.owner || P.profileEdit;
    const canEditTags = me.owner || P.tagsEdit;
    if (!canEditProfile && !(canEditTags && b.tags !== undefined)) return json({error:"Vous n’avez pas l’autorisation de modifier votre profil."},403);
    if (b.tags !== undefined && !canEditTags) return json({error:"Vous n’avez pas l’autorisation de gérer vos tags."},403);
    const rec=me.owner ? (await env.LINKS.get("profile:owner","json") || {}) : await env.LINKS.get("u:"+me.username,"json");
    if(!rec && !me.owner)return json({error:"Compte introuvable."},404);
    if (canEditProfile && (b.first !== undefined || b.last !== undefined)) {
      const first=cleanText(b.first,40), last=cleanText(b.last,40);
      if(!me.owner && (!first||!last))return json({error:"Le prénom et le nom sont obligatoires."},400);
      rec.first=first; rec.last=last;
    }
    if (b.tags !== undefined && canEditTags) rec.tags=readTags(b.tags);
    if(me.owner) await env.LINKS.put("profile:owner",JSON.stringify(rec));
    else await env.LINKS.put("u:"+me.username,JSON.stringify(rec),{metadata:userMeta(rec)});
    return json({ok:true});
  }

  /* Préférences et mot de passe personnels */
  if (p === "/admin/api/me/theme" && req.method === "POST") {
    let b; try { b = await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
    await env.LINKS.put("t:" + me.username, b.theme === "light" ? "light" : "dark");
    return json({ ok: true });
  }
  if (p === "/admin/api/me/password" && req.method === "POST") {
    if (me.owner) return json({ error: "Le mot de passe du compte principal se modifie dans Cloudflare." }, 400);
    if (!P.pw && !me.forcePwChange) return json({ error: "Ton compte n’est pas autorisé à modifier son mot de passe." }, 403);
    let b; try { b = await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
    const { rk, tries } = await failCount(req, env);
    if (tries >= 5) return json({ error: "Trop de tentatives. Veuillez réessayer dans 15 minutes." }, 429);
    const rec = await env.LINKS.get("u:" + me.username, "json");
    const cur = String(b.current || "").slice(0, 200), next = String(b.next || "");
    if (!rec || !safeEq(await pbkdf2(cur, rec.salt), rec.hash || "")) { await env.LINKS.put(rk, String(tries + 1), { expirationTtl: 900 }); return json({ error: "Mot de passe actuel incorrect." }, 401); }
    if (next.length < 10 || next.length > 128) return json({ error: "Le nouveau mot de passe doit faire entre 10 et 128 caractères." }, 400);
    rec.salt = hex(crypto.getRandomValues(new Uint8Array(16))); rec.hash = await pbkdf2(next, rec.salt); rec.forcePwChange = false;
    await env.LINKS.put("u:" + me.username, JSON.stringify(rec), { metadata: userMeta(rec) });
    await env.LINKS.delete(rk);
    return json({ ok: true });
  }

  /* Redirections */
  if (p === "/admin/api/links/check" && req.method === "GET") {
    const slug = String(url.searchParams.get("slug") || "").trim().toLowerCase().replace(/^\/+/, "");
    if (!SLUG.test(slug) || RESERVED.includes(slug)) return json({ exists: false, valid: false });
    const old = await env.LINKS.getWithMetadata("l:" + slug);
    return json({ exists: !!old.value, valid: true });
  }
  if (p === "/admin/api/links" && req.method === "GET") {
    const out = []; let cursor;
    do { const r = await env.LINKS.list({ prefix: "l:", cursor });
      for (const k of r.keys) { const m = k.metadata || {};
        const rawLinkContent = m.contentType === "text" ? ((await env.LINKS.get("t:" + k.name.slice(2))) || "") : "";
        const linkContent = m.contentType === "text" ? cleanRichContent(rawLinkContent) : "";
        if (P.super || P.view || own(m)) out.push({ slug: k.name.slice(2), name: m.name || "", url: m.url || "", contentType: m.contentType || "url", content: linkContent, by: m.by || "", byName: m.byName || m.by || "", from: m.from || null, until: m.until || null, showBy: m.showBy !== false, showFrom: m.showFrom !== false, showUntil: m.showUntil !== false, byFormat: m.byFormat === "username" ? "username" : "name", protected: !!m.pwHash, integration: m.integration === true, showNewTab: m.showNewTab === true, own: own(m), canEdit: canEdit(m), canDel: canDel(m) }); }
      cursor = r.list_complete ? undefined : r.cursor; } while (cursor);
    out.sort((a, b) => a.slug.localeCompare(b.slug));
    return json({ links: out });
  }
  if (p === "/admin/api/links" && req.method === "POST") {
    let b={}, file=null; try { if((req.headers.get('content-type')||'').includes('multipart/form-data')){const fd=await req.formData();for(const [k,v] of fd.entries()){if(k==='file'){if(v && typeof v.arrayBuffer==='function' && v.size>0)file=v;}else b[k]=v;}for(const k of ['from','until'])if(b[k]==='')b[k]=null;for(const k of ['showBy','showFrom','showUntil','integration','showNewTab','removePassword','keepPdf'])b[k]=b[k]==='true';}else b=await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
    const slug = String(b.slug || "").trim().toLowerCase().replace(/^\/+/, "");
    if (!SLUG.test(slug) || RESERVED.includes(slug)) return json({ error: "Nom invalide : lettres, chiffres, - et _ uniquement (64 max)." }, 400);
    const contentType=['url','pdf-url','text','pdf'].includes(String(b.contentType||''))?String(b.contentType):'url';
    let target='', content=String(b.content||'');
    if(contentType==='url'||contentType==='pdf-url'){const rawTarget=String(b.url||'').trim();if(!/^https:\/\/\S+$/i.test(rawTarget))return json({error:'Destination incorrecte : veuillez saisir une adresse HTTPS complète.'},400);target=cleanUrl(rawTarget);if(!target||target.length>700)return json({error:'Destination HTTPS invalide (700 caractères maximum).'},400);}
    if(contentType==='text') { content = cleanRichContent(content); if(!richTextOnly(content) || content.length>28000) return json({error:'Le contenu enrichi doit contenir du texte et ne pas dépasser la limite autorisée.'},400); }
    if(contentType==='pdf' && !env.CONTENT_FILES)return json({error:'Le stockage PDF n’est pas configuré. Ajoute un bucket R2 avec le binding CONTENT_FILES dans les paramètres du Worker.'},400);
    if(contentType!=='url' && String(b.password||''))return json({error:'La protection par mot de passe est actuellement disponible pour les redirections URL uniquement.'},400);
    const num = v => (v === null || v === undefined || v === "") ? null : Number(v);
    const from = num(b.from), until = num(b.until);
    const okT = t => t === null || (Number.isFinite(t) && t > 9.46e11 && t < 4.1e12);
    if (!okT(from) || !okT(until)) return json({ error: "Date invalide." }, 400);
    if (from && until && until <= from) return json({ error: "La date d’expiration doit être après la date de début." }, 400);
    const old = await env.LINKS.getWithMetadata("l:" + slug);
    if (old.value && b.createOnly === true) return json({ error: "Cette adresse courte est déjà utilisée. Choisissez-en une autre." }, 409);
    if (old.value) { if (!canEdit(old.metadata)) return json({ error: "Vous n’êtes pas autorisé à modifier cette redirection." }, 403); }
    else if (!(P.super || P.create)) return json({ error: "Vous n’êtes pas autorisé à créer des redirections." }, 403);
    const meta = { name: String(b.name !== undefined ? b.name : (old.metadata?.name || "")).trim().slice(0,120), url: target, contentType, by: old.metadata?.by || me.username, byName: old.metadata?.byName || me.display || me.username, showBy: b.showBy !== undefined ? b.showBy === true : (old.metadata?.showBy !== false), showFrom: b.showFrom !== undefined ? b.showFrom === true : (old.metadata?.showFrom !== false), showUntil: b.showUntil !== undefined ? b.showUntil === true : (old.metadata?.showUntil !== false), byFormat: b.byFormat === "username" ? "username" : (old.metadata?.byFormat || "name"), integration: b.integration !== undefined ? b.integration === true : (old.metadata?.integration === true), showNewTab: b.showNewTab !== undefined ? b.showNewTab === true : (old.metadata?.showNewTab === true) };
    if (old.metadata?.pwHash && contentType==='url') { meta.pwHash = old.metadata.pwHash; meta.pwSalt = old.metadata.pwSalt; }
    const pass = String(b.password || ""); if (pass) { if (pass.length < 6 || pass.length > 128) return json({error:"Le mot de passe doit faire entre 6 et 128 caractères."},400); meta.pwSalt = hex(crypto.getRandomValues(new Uint8Array(16))); meta.pwHash = await pbkdf2(pass, meta.pwSalt); }
    if (b.removePassword === true || contentType!=='url') { delete meta.pwHash; delete meta.pwSalt; }
    meta.from = from; meta.until = until;
    if(contentType==='pdf'){
      const existingKey=old.metadata?.contentKey||('pdf/'+slug);
      if(file){if(file.type!=='application/pdf'&&!String(file.name||'').toLowerCase().endsWith('.pdf'))return json({error:'Le fichier doit être un PDF.'},400);if(file.size>15*1024*1024)return json({error:'Le PDF dépasse 15 Mo.'},400);await env.CONTENT_FILES.put(existingKey,file.stream(),{httpMetadata:{contentType:'application/pdf',contentDisposition:'inline; filename="'+slug+'.pdf"'},customMetadata:{slug,uploadedBy:me.username}});}
      else if(!old.metadata?.contentKey)return json({error:'Sélectionne un fichier PDF à téléverser.'},400);
      meta.contentKey=existingKey;
    }else if(old.metadata?.contentKey&&env.CONTENT_FILES){await env.CONTENT_FILES.delete(old.metadata.contentKey);}
    if(contentType==='text')await env.LINKS.put('t:'+slug,content);else await env.LINKS.delete('t:'+slug);
    await env.LINKS.put("l:" + slug, target || ('content:'+contentType), { metadata: meta });
    return json({ ok: true });
  }
  if (p.startsWith("/admin/api/links/") && req.method === "DELETE") {
    let slug; try { slug = decodeURIComponent(p.slice(17)).toLowerCase(); } catch { return json({ error: "Nom invalide." }, 400); }
    if (!SLUG.test(slug)) return json({ error: "Nom invalide." }, 400);
    const old = await env.LINKS.getWithMetadata("l:" + slug);
    if (old.value && !canDel(old.metadata)) return json({ error: "Vous n’êtes pas autorisé à supprimer cette redirection." }, 403);
    if(old.metadata?.contentKey&&env.CONTENT_FILES)await env.CONTENT_FILES.delete(old.metadata.contentKey);
    await env.LINKS.delete("t:"+slug);await env.LINKS.delete("l:" + slug);
    return json({ ok: true });
  }

  /* Utilisateurs */
  if (p.startsWith("/admin/api/users")) {
    const owner = ownerName(env);
    const NOGRANT = "Vous ne pouvez pas accorder ou gérer des droits dont vous ne disposez pas vous-même.";
    if (p === "/admin/api/users" && req.method === "GET") {
      if (!P.usersView) return json({ error: "Vous n’êtes pas autorisé à consulter les utilisateurs." }, 403);
      const ownerProfile = await env.LINKS.get("profile:owner", "json") || {};
      const out = [{ username: owner, perms: normPerms({ super: true }), first: ownerProfile.first || "", last: ownerProfile.last || "", tags: Array.isArray(ownerProfile.tags) ? ownerProfile.tags : [], owner: true, active: true, canEdit: false, canDelete: false }]; let cursor;
      do { const r = await env.LINKS.list({ prefix: "u:", cursor });
        for (const k of r.keys) {
          const name = k.name.slice(2);
          if (name === owner) continue; // évite le doublon si une ancienne clé u:<owner> existe
          // Lire la valeur réelle en plus des métadonnées : les anciens enregistrements peuvent être incomplets.
          const record = await env.LINKS.get(k.name, "json") || {};
          const m = { ...(k.metadata || {}), ...record };
          const tp = normPerms(m);
          out.push({ username: name, perms: tp, groupId: m.groupId || "", first: m.first || "", last: m.last || "", tags: readTags(m.tags), created: m.created || "", by: m.by || "", from:m.from||null, until:m.until||null, forcePwChange:!!m.forcePwChange, active:m.active!==false,
            canEdit: !!P.usersEdit && within(tp, P), canDelete: !!P.usersDelete && name !== me.username && within(tp, P) });
        }
        cursor = r.list_complete ? undefined : r.cursor; } while (cursor);
      return json({ users: out });
    }
    if (p === "/admin/api/users" && req.method === "POST") {
      if (!P.usersCreate) return json({ error: "Vous n’êtes pas autorisé à créer des utilisateurs." }, 403);
      let b; try { b = await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
      const name = String(b.username || "").trim().toLowerCase(), pw = String(b.password || "");
      if (!USER.test(name)) return json({ error: "Identifiant invalide : 3 à 32 caractères (lettres, chiffres, - et _)." }, 400);
      const first = cleanText(b.first, 40), last = cleanText(b.last, 40);
      if (!first || !last) return json({ error: "Le prénom et le nom sont obligatoires." }, 400);
      if (pw.length < 10 || pw.length > 128) return json({ error: "Le mot de passe doit faire entre 10 et 128 caractères." }, 400);
      const perms = readPerms(b);
      if (!hasAccess(perms)) return json({ error: "Coche au moins un droit (en plus du mot de passe)." }, 400);
      if (!within(perms, P)) return json({ error: NOGRANT }, 403);
      if (name === owner || await env.LINKS.get("u:" + name)) return json({ error: "Cet identifiant existe déjà." }, 409);
      const from = b.from ? Number(b.from) : null, until = b.until ? Number(b.until) : null; if ((from && (!Number.isFinite(from)||from<Date.now()-864e5)) || (until && !Number.isFinite(until)) || (from&&until&&until<=from)) return json({error:"Dates de compte invalides."},400);
      const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
      const groupId = String(b.groupId || "");
      const groups = await listGroups(env); if (groupId && !groups.some(g => g.id === groupId)) return json({ error: "Le groupe sélectionné n’existe plus. Rechargez la liste des groupes." }, 400);
      const rec = { salt, hash: await pbkdf2(pw, salt), perms: compactPerms(perms), groupId, first, last, tags: readTags(b.tags), created: new Date().toISOString().slice(0, 10), by: me.username, forcePwChange: b.forcePwChange === true, from, until };
      await env.LINKS.put("u:" + name, JSON.stringify(rec), { metadata: userMeta(rec) });
      return json({ ok: true });
    }
    if (p.startsWith("/admin/api/users/") && (req.method === "PUT" || req.method === "DELETE")) {
      let name; try { name = decodeURIComponent(p.slice(17)).toLowerCase(); } catch { return json({ error: "Identifiant invalide." }, 400); }
      if (name === owner) return json({ error: "Le compte principal se gère dans Cloudflare." }, 400);
      if (!USER.test(name)) return json({ error: "Identifiant invalide." }, 400);
      const rec = await env.LINKS.get("u:" + name, "json");
      if (req.method === "DELETE") {
        if (!P.usersDelete) return json({ error: "Vous n’êtes pas autorisé à supprimer des utilisateurs." }, 403);
        if (name === me.username) return json({ error: "Vous ne pouvez pas supprimer votre propre compte." }, 400);
        if (rec && !within(normPerms(rec), P)) return json({ error: NOGRANT }, 403);
        await env.LINKS.delete("u:" + name); await env.LINKS.delete("t:" + name);
        return json({ ok: true });
      }
      if (!P.usersEdit) return json({ error: "Vous n’êtes pas autorisé à modifier des utilisateurs." }, 403);
      let b; try { b = await req.json(); } catch { return json({ error: "Requête invalide." }, 400); }
      if (!rec) return json({ error: "Utilisateur introuvable." }, 404);
      const tp = normPerms(rec);
      if (!within(tp, P)) return json({ error: NOGRANT }, 403);
      const first = cleanText(b.first, 40), last = cleanText(b.last, 40);
      if (!first || !last) return json({ error: "Le prénom et le nom sont obligatoires." }, 400);
      let perms = tp;
      if (name !== me.username) { // on ne modifie jamais ses propres droits
        perms = readPerms(b);
        if (!hasAccess(perms)) return json({ error: "Coche au moins un droit (en plus du mot de passe)." }, 400);
        if (!within(perms, P)) return json({ error: NOGRANT }, 403);
      }
      const pw = String(b.password || "");
      if (pw) {
        if (pw.length < 10 || pw.length > 128) return json({ error: "Le mot de passe doit faire entre 10 et 128 caractères." }, 400);
        rec.salt = hex(crypto.getRandomValues(new Uint8Array(16))); rec.hash = await pbkdf2(pw, rec.salt);
      }
      delete rec.role; rec.perms = compactPerms(perms); if (b.groupId !== undefined) { const groupId = String(b.groupId || ""); const groups = await listGroups(env); if (groupId && !groups.some(g => g.id === groupId)) return json({ error: "Le groupe sélectionné n’existe plus. Rechargez la liste des groupes." }, 400); rec.groupId = groupId; } rec.first = first; rec.last = last; rec.tags = readTags(b.tags); if(name!==me.username && b.active !== undefined) rec.active = b.active === true; if (b.forcePwChange !== undefined) rec.forcePwChange = b.forcePwChange === true; if (b.from !== undefined) rec.from = b.from ? Number(b.from) : null; if (b.until !== undefined) rec.until = b.until ? Number(b.until) : null;
      await env.LINKS.put("u:" + name, JSON.stringify(rec), { metadata: userMeta(rec) });
      return json({ ok: true });
    }
  }
  return json({ error: "Introuvable." }, 404);
}

/* ---------- Routage ---------- */
const router = {
  async fetch(req, env) {
    const url = new URL(req.url);
    const path = url.pathname;
    if (path === "/robots.txt") return new Response("User-agent: *\nDisallow: /\n", { headers: { "content-type": "text/plain" } });
    if (path === "/admin" || path.startsWith("/admin/")) return admin(req, env, url);

    if (path === "/") {
      const nonce = newNonce();
      const me = await getSession(req, env, true);
      return publicHomePage(nonce, me);
    }
    let slug = "";
    try { slug = decodeURIComponent(path.slice(1)).toLowerCase().replace(/\/$/, ""); } catch {}
    if (req.method === "POST" && env.LINKS && SLUG.test(slug)) {
      const rec=await env.LINKS.getWithMetadata("l:"+slug); const m=rec.metadata||{};
      if (m.from && Date.now() < m.from) return notice("Ce lien n’est pas encore actif", `Il sera disponible à partir du ${fmtDate(m.from)}.`, 404);
      if (m.until && Date.now() > m.until) return notice("Ce lien a expiré", `Il n’est plus disponible depuis le ${fmtDate(m.until)}.`, 410);
      if (!rec.value || !m.pwHash) return new Response(null,{status:303,headers:{Location:"/"+slug,"Cache-Control":"no-store"}});
      // Lire le formulaire de manière robuste : si formData() échoue sur un runtime
      // ou un type de contenu inattendu, ne pas remplacer silencieusement le mot de passe par une chaîne vide.
      let magic = "";
      try {
        const form = await req.clone().formData();
        magic = String(form.get("magic") || "").slice(0, 128);
      } catch {
        try {
          const raw = await req.text();
          const params = new URLSearchParams(raw);
          magic = String(params.get("magic") || "").slice(0, 128);
        } catch {}
      }
      const h = await pbkdf2(magic, m.pwSalt || "00".repeat(16));
      if (!safeEq(h, String(m.pwHash || ""))) {
        return new Response(null, { status: 303, headers: { Location: "/" + slug + "?e=1", "Cache-Control": "no-store" } });
      }
      const target = cleanUrl(rec.value);
      return target ? confirmPage(target, m) : notice("Lien invalide", "La destination est incorrecte.", 404);
    }
    if (env.LINKS && SLUG.test(slug)) {
      const v = await env.LINKS.getWithMetadata("l:" + slug);
      const m = v.metadata || {};
      if(v.value && m.contentType==='text'){
        const now=Date.now();if(m.from&&now<m.from)return notice('Ce lien n’est pas encore actif',`Il sera disponible à partir du ${fmtDate(m.from)}.`,404);if(m.until&&now>m.until)return notice('Ce lien a expiré',`Il n’est plus disponible depuis le ${fmtDate(m.until)}.`,410);
        const content=await env.LINKS.get('t:'+slug);if(content===null)return notice('Contenu introuvable','Le texte associé à ce lien n’est plus disponible.',404);
        const safeContent=cleanRichContent(content), plainContent=richTextOnly(safeContent);const nonce=newNonce(),body=`<header>${BRAND}<div class="right">${THEME_SWITCH(false)}</div></header><section class="glass content-public"><div class="eyebrow">Document Texte</div><h1>${esc(slug)}</h1><article class="public-text">${safeContent}</article><div class="two"><button class="btn p" id="copyText" type="button">Copier le texte</button><a class="btn" href="data:text/plain;charset=utf-8,${encodeURIComponent(plainContent).replace(/'/g,'%27')}" download="${esc(slug)}.txt">Télécharger .txt</a></div></section>`;
        const js=`const b=document.getElementById('copyText');b?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(document.querySelector('.public-text').innerText);b.textContent='Copié !';setTimeout(()=>b.textContent='Copier le texte',1500)}catch{b.textContent='Copie indisponible'}});`;
        return htmlRes(nonce,shell(nonce,`Texte · ${slug}`,body,js));
      }
      if(v.value && m.contentType==='pdf'){
        const now=Date.now();if(m.from&&now<m.from)return notice('Ce lien n’est pas encore actif',`Il sera disponible à partir du ${fmtDate(m.from)}.`,404);if(m.until&&now>m.until)return notice('Ce lien a expiré',`Il n’est plus disponible depuis le ${fmtDate(m.until)}.`,410);
        if(!env.CONTENT_FILES||!m.contentKey)return notice('PDF indisponible','Le stockage du fichier n’est pas configuré.',503);const obj=await env.CONTENT_FILES.get(m.contentKey);if(!obj)return notice('PDF introuvable','Le fichier associé à ce lien est absent.',404);const headers=new Headers({'content-type':'application/pdf','content-disposition':`inline; filename="${slug}.pdf"`,'cache-control':'public, max-age=300','x-content-type-options':'nosniff'});obj.writeHttpMetadata?.(headers);headers.set('content-type','application/pdf');headers.set('content-disposition',`inline; filename="${slug}.pdf"`);headers.set('x-content-type-options','nosniff');return new Response(obj.body,{headers});
      }
      const target = v.value && cleanUrl(v.value);
      if (target) {
        const m = v.metadata || {}, now = Date.now();
        if (m.from && now < m.from) return notice("Ce lien n’est pas encore actif", `Il sera disponible à partir du ${fmtDate(m.from)}.`, 404);
        if (m.until && now > m.until) return notice("Ce lien a expiré", `Il n’est plus disponible depuis le ${fmtDate(m.until)}.`, 410);
        // Compteur agrégé : une seule clé KV par lien, aucun événement détaillé.
        if (req.method === "GET" || req.method === "HEAD") {
          try {
            const counterKey = "click:" + slug;
            const current = Number(await env.LINKS.get(counterKey) || 0);
            await env.LINKS.put(counterKey, String((Number.isFinite(current) ? current : 0) + 1));
          } catch (_) { /* Le comptage ne doit jamais interrompre une redirection. */ }
        }
        if (m.pwHash) {
          const nonce = newNonce();
          const body = `<header>${BRAND}<div class="right">${THEME_SWITCH(false)}</div></header><form class="glass" id="unlockForm" method="POST" action="/${esc(slug)}"><div class="eyebrow">Accès sécurisé</div><h1>🔒 Redirection protégée par mot de passe</h1><p class="muted">Entrez le mot magique !</p><label for="magic">Mot de passe</label><input id="magic" name="magic" type="password" autocomplete="current-password" required autofocus aria-describedby="pwMessage"><div class="err" id="pwMessage" role="alert">${url.searchParams.get("e")==="1"?"Mot de passe incorrect. Veuillez réessayer.":""}</div><button class="btn p" id="unlockButton" type="submit">Déverrouiller la redirection</button></form>`;
          const js = SESSION_JS + `
const form=document.getElementById('unlockForm'),field=document.getElementById('magic'),msg=document.getElementById('pwMessage'),btn=document.getElementById('unlockButton');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function result(ok,text){field.classList.remove('pw-ok','pw-bad');void field.offsetWidth;field.classList.add(ok?'pw-ok':'pw-bad');field.setAttribute('aria-invalid',ok?'false':'true');msg.className=ok?'pw-feedback success':'pw-feedback error';msg.textContent=text;}
function startConfirmation(){const c=document.getElementById('c'),m=document.getElementById('m'),bar=document.querySelector('.bar'),progress=document.getElementById('progress'),dest=document.querySelector('.dest'),target=dest?dest.textContent.trim():'';if(!c||!m||!target)return;const start=Date.now(),duration=10000;let n=10;const iv=setInterval(()=>{const remaining=Math.max(0,duration-(Date.now()-start));n=Math.ceil(remaining/1000);c.textContent=n;if(progress)progress.style.width=(remaining/duration*100)+'%';if(bar)bar.setAttribute('aria-valuenow',String(Math.round(remaining/duration*100)));if(remaining<=0){clearInterval(iv);location.href=target;}},100);const go=document.getElementById('go'),no=document.getElementById('no');if(go)go.onclick=()=>{clearInterval(iv);const dest=document.querySelector('.dest');if(dest)location.href=dest.textContent.trim();};if(no)no.onclick=()=>{clearInterval(iv);if(bar)bar.remove();const buttons=document.querySelector('.two');if(buttons)buttons.remove();m.textContent='Redirection annulée. Vous pouvez fermer cet onglet.';};const nt=document.getElementById('newTab');if(nt)nt.onclick=()=>{const w=window.open(target,'_blank');if(w){w.opener=null;clearInterval(iv);m.textContent='La destination a été ouverte dans un nouvel onglet.';if(bar)bar.remove();document.getElementById('newTabWrap')?.remove();}else{m.textContent='Le navigateur a bloqué l’ouverture du nouvel onglet. Autorisez les fenêtres contextuelles pour ce site.';}};}
form.addEventListener('submit',async ev=>{ev.preventDefault();if(!field.value)return;btn.disabled=true;btn.textContent='Vérification…';msg.textContent='';field.classList.remove('pw-ok','pw-bad');try{const response=await fetch(form.action,{method:'POST',body:new FormData(form),credentials:'same-origin',redirect:'follow',headers:{'Accept':'text/html'}});const html=await response.text();if(new URL(response.url).searchParams.get('e')==='1'||html.includes('id="unlockForm"')){result(false,'Mot de passe incorrect. Veuillez réessayer.');field.select();btn.disabled=false;btn.textContent='Réessayer';return;}if(response.ok&&html.includes('id="go"')){result(true,'Mot de passe correct ! Préparation de la redirection…');await wait(700);const parsed=new DOMParser().parseFromString(html,'text/html');document.title=parsed.title;document.body.innerHTML=parsed.body.innerHTML;const th2=document.getElementById('th');if(th2)th2.addEventListener('click',async()=>{const h=document.documentElement,n=h.dataset.theme==='light'?'dark':'light';h.classList.add('tt');h.dataset.theme=n;th2.setAttribute('aria-checked',String(n==='light'));try{localStorage.setItem('links-theme',n);}catch{}setTimeout(()=>h.classList.remove('tt'),3150);});startConfirmation();return;}result(false,'Impossible de vérifier le mot de passe. Veuillez réessayer.');btn.disabled=false;btn.textContent='Réessayer';}catch(err){result(false,'Erreur de connexion. Veuillez réessayer.');btn.disabled=false;btn.textContent='Réessayer';}});
if(location.search.includes('e=1')){field.classList.add('pw-bad');field.setAttribute('aria-invalid','true');}
`;
          return htmlRes(nonce, shell(nonce, `Redirection protégée · ${slug}`, body, js));
        }
        return confirmPage(target, m);
      }
    }
    return notice("Rien ici.", "Ce lien n’existe pas ou n’existe plus.", 404);
  }
};

/* Enveloppe : applique les réglages de personnalisation à toutes les pages HTML. */
export default {
  async fetch(req, env) {
    let res;
    try { res = await router.fetch(req, env); }
    catch (err) { res = new Response("Erreur interne", { status: 500, headers: { "content-type": "text/plain; charset=utf-8" } }); }
    if (!(res.headers.get("content-type") || "").startsWith("text/html")) return res;
    const site = await loadSite(env);
    return new Response(applySite(await res.text(), site), { status: res.status, headers: res.headers });
  }
};
